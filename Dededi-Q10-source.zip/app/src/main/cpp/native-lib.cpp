#include <jni.h>
#include <algorithm>
#include <array>
#include <cctype>
#include <cstdio>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <limits>
#include <memory>
#include <mutex>
#include <string>
#include <utility>
#include <vector>
#include "lm/model.hh"
#include "lm/virtual_interface.hh"

extern "C" void dedediFillKeyPartA(uint8_t out[32]);
extern "C" void dedediFillKeyPartB(uint8_t out[32]);

namespace {
constexpr char DOMAIN[] = "DEDEDI-ASSET-V2\0";

void wipe(void* pointer, size_t length) {
    volatile unsigned char* bytes = static_cast<volatile unsigned char*>(pointer);
    while (length--) *bytes++ = 0;
}

bool tracerAttached() {
    FILE* file = fopen("/proc/self/status", "r");
    if (!file) return false;
    char line[256];
    bool attached = false;
    while (fgets(line, sizeof(line), file)) {
        if (strncmp(line, "TracerPid:", 10) == 0) {
            const char* value = line + 10;
            while (*value && std::isspace(static_cast<unsigned char>(*value))) ++value;
            attached = atoi(value) != 0;
            break;
        }
    }
    fclose(file);
    return attached;
}

bool suspiciousMappings() {
    FILE* file = fopen("/proc/self/maps", "r");
    if (!file) return false;
    char line[1024];
    bool suspicious = false;
    while (fgets(line, sizeof(line), file)) {
        std::string value(line);
        std::transform(value.begin(), value.end(), value.begin(), [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
        if (value.find("frida") != std::string::npos || value.find("gum-js-loop") != std::string::npos || value.find("libgadget") != std::string::npos) {
            suspicious = true;
            break;
        }
    }
    fclose(file);
    return suspicious;
}

bool sha256(JNIEnv* env, const std::vector<uint8_t>& input, std::array<uint8_t, 32>& output) {
    jclass cls = env->FindClass("java/security/MessageDigest");
    if (!cls) return false;
    jmethodID getInstance = env->GetStaticMethodID(cls, "getInstance", "(Ljava/lang/String;)Ljava/security/MessageDigest;");
    jmethodID digest = env->GetMethodID(cls, "digest", "([B)[B");
    if (!getInstance || !digest) { env->DeleteLocalRef(cls); return false; }
    jstring algorithm = env->NewStringUTF("SHA-256");
    jobject md = env->CallStaticObjectMethod(cls, getInstance, algorithm);
    env->DeleteLocalRef(algorithm);
    if (env->ExceptionCheck() || !md) { env->ExceptionClear(); env->DeleteLocalRef(cls); return false; }
    jbyteArray bytes = env->NewByteArray(static_cast<jsize>(input.size()));
    if (!bytes) { env->DeleteLocalRef(md); env->DeleteLocalRef(cls); return false; }
    if (!input.empty()) env->SetByteArrayRegion(bytes, 0, static_cast<jsize>(input.size()), reinterpret_cast<const jbyte*>(input.data()));
    auto result = static_cast<jbyteArray>(env->CallObjectMethod(md, digest, bytes));
    bool ok = !env->ExceptionCheck() && result && env->GetArrayLength(result) == 32;
    if (env->ExceptionCheck()) env->ExceptionClear();
    if (ok) env->GetByteArrayRegion(result, 0, 32, reinterpret_cast<jbyte*>(output.data()));
    if (result) env->DeleteLocalRef(result);
    env->DeleteLocalRef(bytes); env->DeleteLocalRef(md); env->DeleteLocalRef(cls);
    return ok;
}

bool hmacSha256(JNIEnv* env, const uint8_t key[32], const std::vector<uint8_t>& message, std::array<uint8_t, 32>& output) {
    std::array<uint8_t, 64> ipad{}, opad{};
    for (size_t i = 0; i < 64; ++i) {
        uint8_t value = i < 32 ? key[i] : 0;
        ipad[i] = static_cast<uint8_t>(value ^ 0x36U);
        opad[i] = static_cast<uint8_t>(value ^ 0x5CU);
    }
    std::vector<uint8_t> inner; inner.reserve(64 + message.size()); inner.insert(inner.end(), ipad.begin(), ipad.end()); inner.insert(inner.end(), message.begin(), message.end());
    std::array<uint8_t, 32> innerHash{};
    if (!sha256(env, inner, innerHash)) return false;
    std::vector<uint8_t> outer; outer.reserve(96); outer.insert(outer.end(), opad.begin(), opad.end()); outer.insert(outer.end(), innerHash.begin(), innerHash.end());
    bool ok = sha256(env, outer, output);
    wipe(inner.data(), inner.size()); wipe(outer.data(), outer.size()); wipe(innerHash.data(), innerHash.size()); wipe(ipad.data(), ipad.size()); wipe(opad.data(), opad.size());
    return ok;
}
}

extern "C" JNIEXPORT jbyteArray JNICALL
Java_com_app_dededi_NativeSecurity_deriveAssetKeyNative(JNIEnv* env, jclass, jbyteArray javaPart, jbyteArray buildToken, jbyteArray salt, jstring assetName) {
    if (!javaPart || !buildToken || !salt || !assetName || (tracerAttached() && suspiciousMappings())) return nullptr;
    if (env->GetArrayLength(javaPart) != 32 || env->GetArrayLength(buildToken) != 16 || env->GetArrayLength(salt) != 16) return nullptr;
    std::array<uint8_t, 32> partA{}, partB{}, partC{}, master{}, derived{};
    std::array<uint8_t, 16> token{}, saltBytes{};
    dedediFillKeyPartA(partA.data()); dedediFillKeyPartB(partB.data());
    env->GetByteArrayRegion(javaPart, 0, 32, reinterpret_cast<jbyte*>(partC.data()));
    env->GetByteArrayRegion(buildToken, 0, 16, reinterpret_cast<jbyte*>(token.data()));
    env->GetByteArrayRegion(salt, 0, 16, reinterpret_cast<jbyte*>(saltBytes.data()));
    for (size_t i = 0; i < 32; ++i) master[i] = static_cast<uint8_t>(partA[i] ^ partB[i] ^ partC[i]);
    const char* name = env->GetStringUTFChars(assetName, nullptr);
    if (!name) return nullptr;
    std::vector<uint8_t> message;
    message.insert(message.end(), DOMAIN, DOMAIN + sizeof(DOMAIN) - 1);
    message.insert(message.end(), token.begin(), token.end());
    message.insert(message.end(), saltBytes.begin(), saltBytes.end());
    message.insert(message.end(), name, name + strlen(name));
    env->ReleaseStringUTFChars(assetName, name);
    bool ok = hmacSha256(env, master.data(), message, derived);
    jbyteArray result = nullptr;
    if (ok) {
        result = env->NewByteArray(32);
        if (result) env->SetByteArrayRegion(result, 0, 32, reinterpret_cast<const jbyte*>(derived.data()));
    }
    wipe(partA.data(), partA.size()); wipe(partB.data(), partB.size()); wipe(partC.data(), partC.size()); wipe(master.data(), master.size()); wipe(derived.data(), derived.size()); wipe(token.data(), token.size()); wipe(saltBytes.data(), saltBytes.size()); wipe(message.data(), message.size());
    return result;
}

namespace {
std::unique_ptr<lm::base::Model> g_q10;
std::mutex g_q10Mutex;

struct UToken {
    std::string text;
    int utf16Start;
    int utf16End;
};

static void appendUtf8(uint32_t cp, std::string& out) {
    if (cp <= 0x7F) out.push_back(static_cast<char>(cp));
    else if (cp <= 0x7FF) {
        out.push_back(static_cast<char>(0xC0 | (cp >> 6)));
        out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
    } else if (cp <= 0xFFFF) {
        out.push_back(static_cast<char>(0xE0 | (cp >> 12)));
        out.push_back(static_cast<char>(0x80 | ((cp >> 6) & 0x3F)));
        out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
    } else {
        out.push_back(static_cast<char>(0xF0 | (cp >> 18)));
        out.push_back(static_cast<char>(0x80 | ((cp >> 12) & 0x3F)));
        out.push_back(static_cast<char>(0x80 | ((cp >> 6) & 0x3F)));
        out.push_back(static_cast<char>(0x80 | (cp & 0x3F)));
    }
}

static bool asciiWhitespace(uint32_t cp) {
    return cp == 0x20 || cp == 0x09 || cp == 0x0A || cp == 0x0D || cp == 0x0B || cp == 0x0C;
}

static std::vector<UToken> tokenize(JNIEnv* env, jstring value) {
    std::vector<UToken> out;
    if (!value) return out;
    const jsize n = env->GetStringLength(value);
    const jchar* chars = env->GetStringChars(value, nullptr);
    if (!chars) return out;
    out.reserve(static_cast<size_t>(n));
    for (int i = 0; i < n;) {
        int start = i;
        uint32_t cp = chars[i++];
        if (cp >= 0xD800 && cp <= 0xDBFF && i < n) {
            uint32_t lo = chars[i];
            if (lo >= 0xDC00 && lo <= 0xDFFF) {
                ++i;
                cp = 0x10000 + ((cp - 0xD800) << 10) + (lo - 0xDC00);
            }
        }
        if (asciiWhitespace(cp)) continue;
        std::string token; token.reserve(4); appendUtf8(cp, token);
        out.push_back({token, start, i});
    }
    env->ReleaseStringChars(value, chars);
    return out;
}

static double continuationScore(const std::vector<std::string>& context,
                                bool beginsSentence,
                                const std::vector<std::string>& continuation,
                                bool includeEos) {
    if (!g_q10) return std::numeric_limits<double>::quiet_NaN();
    const size_t bytes = g_q10->StateSize();
    const size_t words = (bytes + sizeof(uint64_t) - 1) / sizeof(uint64_t);
    std::vector<uint64_t> a(words), b(words);
    void* in = a.data(); void* out = b.data();
    if (beginsSentence) g_q10->BeginSentenceWrite(in); else g_q10->NullContextWrite(in);
    const lm::base::Vocabulary& vocab = g_q10->BaseVocabulary();
    for (const std::string& token : context) {
        g_q10->BaseScore(in, vocab.Index(token), out); std::swap(in, out);
    }
    double total = 0.0;
    for (const std::string& token : continuation) {
        total += g_q10->BaseScore(in, vocab.Index(token), out); std::swap(in, out);
    }
    if (includeEos) total += g_q10->BaseScore(in, vocab.EndSentence(), out);
    return total;
}

static int tokenAtUtf16Start(const std::vector<UToken>& tokens, int start) {
    for (size_t i = 0; i < tokens.size(); ++i) if (tokens[i].utf16Start == start) return static_cast<int>(i);
    return -1;
}

static int tokenIndexAtOrAfter(const std::vector<UToken>& tokens, int utf16Index) {
    for (size_t i = 0; i < tokens.size(); ++i) if (tokens[i].utf16Start >= utf16Index) return static_cast<int>(i);
    return static_cast<int>(tokens.size());
}
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_app_dededi_NativeNGram_loadModelNative(JNIEnv* env, jclass, jstring path) {
    if (!path) return JNI_FALSE;
    const char* raw = env->GetStringUTFChars(path, nullptr);
    if (!raw) return JNI_FALSE;
    std::string file(raw); env->ReleaseStringUTFChars(path, raw);
    std::lock_guard<std::mutex> guard(g_q10Mutex);
    try {
        g_q10.reset(lm::ngram::LoadVirtual(file.c_str()));
        return g_q10 && g_q10->Order() == 5 ? JNI_TRUE : JNI_FALSE;
    } catch (...) {
        g_q10.reset();
        return JNI_FALSE;
    }
}

extern "C" JNIEXPORT jdouble JNICALL
Java_com_app_dededi_NativeNGram_deltaSpanNative(JNIEnv* env, jclass, jstring text,
                                                 jint utf16Start, jint utf16Length,
                                                 jstring correction) {
    std::lock_guard<std::mutex> guard(g_q10Mutex);
    if (!g_q10 || !text || !correction || utf16Start < 0 || utf16Length <= 0)
        return std::numeric_limits<double>::quiet_NaN();
    try {
        std::vector<UToken> tokens = tokenize(env, text);
        std::vector<UToken> replacementTokens = tokenize(env, correction);
        const int cpStart = tokenAtUtf16Start(tokens, utf16Start);
        if (cpStart < 0) return std::numeric_limits<double>::quiet_NaN();
        const int cpEnd = tokenIndexAtOrAfter(tokens, utf16Start + utf16Length);
        if (cpEnd <= cpStart) return std::numeric_limits<double>::quiet_NaN();
        const int history = std::max(0, static_cast<int>(g_q10->Order()) - 1);
        const int contextStart = std::max(0, cpStart - history);
        const int tailEnd = std::min(static_cast<int>(tokens.size()), cpEnd + history);
        std::vector<std::string> context, original, changed;
        for (int i = contextStart; i < cpStart; ++i) context.push_back(tokens[i].text);
        for (int i = cpStart; i < cpEnd; ++i) original.push_back(tokens[i].text);
        for (const UToken& t : replacementTokens) changed.push_back(t.text);
        for (int i = cpEnd; i < tailEnd; ++i) {
            original.push_back(tokens[i].text); changed.push_back(tokens[i].text);
        }
        const bool atEnd = tailEnd == static_cast<int>(tokens.size());
        const bool begins = contextStart == 0;
        const double oldScore = continuationScore(context, begins, original, atEnd);
        const double newScore = continuationScore(context, begins, changed, atEnd);
        return newScore - oldScore;
    } catch (...) {
        return std::numeric_limits<double>::quiet_NaN();
    }
}
