package com.app.dededi;
import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayDeque;
import java.util.List;

public class FloatingService extends Service {
    private static final long MIN_LAST_ERROR_VISIBLE_MS = 1000L;
    private WindowManager windowManager;
    private View floatView, panelInput, circleSpin, statusContainer;
    private WindowManager.LayoutParams params;
    private EditText editFloatInput;
    private TextView tvStatus;
    private ProgressBar floatProgressBar;
    private Button btnFloatSwitch;
    private volatile boolean isChecking, isInterruptRequested, destroyed;
    private volatile String currentHistoryFileId;
    private String lastCorrectedText = "";
    private long lastErrorShownAt;
    private final Object errorStatusLock = new Object();
    private final ArrayDeque<String> visibleErrorLines = new ArrayDeque<>(3);
    private boolean errorStatusFlushScheduled;
    private SharedPreferences sp;
    private final Runnable hideStatusRunnable = () -> { if (!destroyed && statusContainer != null) statusContainer.setVisibility(View.INVISIBLE); };
    private final Runnable errorStatusFlushRunnable = () -> {
        StringBuilder display = new StringBuilder();
        synchronized (errorStatusLock) {
            for (String line : visibleErrorLines) { if (display.length() > 0) display.append('\n'); display.append(line); }
            errorStatusFlushScheduled = false;
        }
        if (!destroyed && !isInterruptRequested && display.length() > 0) {
            tvStatus.setText(display.toString());
            statusContainer.setVisibility(View.VISIBLE);
            statusContainer.removeCallbacks(hideStatusRunnable);
            statusContainer.postDelayed(hideStatusRunnable, 5000);
            lastErrorShownAt = android.os.SystemClock.uptimeMillis();
        }
    };
    private final Runnable syncTextRunnable = () -> {
        if (!destroyed && editFloatInput != null && !isChecking) sp.edit().putString("sync_text", editFloatInput.getText().toString()).apply();
    };

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.hasExtra("IMPORTED_TEXT")) {
            String text = intent.getStringExtra("IMPORTED_TEXT");
            if (editFloatInput != null) MainActivity.checkAndPromptCleanup(this, text, cleaned -> {
                currentHistoryFileId = null;
                editFloatInput.setText(cleaned);
                sp.edit().putString("sync_text", cleaned).apply();
                saveHistory(cleaned, null);
                Toast.makeText(this, "导入成功", Toast.LENGTH_SHORT).show();
                if (panelInput.getVisibility() != View.VISIBLE) { panelInput.setVisibility(View.VISIBLE); setFocusable(true); }
            });
        }
        return START_NOT_STICKY;
    }

    @SuppressLint("ClickableViewAccessibility")
    @Override public void onCreate() {
        super.onCreate();
        sp = getSharedPreferences("DedediConfig", Context.MODE_PRIVATE);
        AppExecutors.INFERENCE.execute(() -> MainActivity.ensureTypoMapLoaded(getApplicationContext()));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel("float_chan", "悬浮窗后台服务", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(channel);
            Notification notification = new Notification.Builder(this, "float_chan").setContentTitle("“的地得”纠错AI").setContentText("悬浮窗运行中").setSmallIcon(R.drawable.ic_dededi_fg).build();
            startForeground(1, notification);
        }
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        params = new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH, PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START; params.x = 0; params.y = 300;
        floatView = ((LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE)).inflate(R.layout.layout_floating, null);
        panelInput = floatView.findViewById(R.id.panelInput); editFloatInput = floatView.findViewById(R.id.editFloatInput);
        circleSpin = floatView.findViewById(R.id.circleSpin); tvStatus = floatView.findViewById(R.id.tvStatus);
        statusContainer = floatView.findViewById(R.id.statusContainer); floatProgressBar = floatView.findViewById(R.id.floatProgressBar);
        View btnCircle = floatView.findViewById(R.id.btnCircle), panelTopBar = floatView.findViewById(R.id.panelTopBar);
        Button btnImport = floatView.findViewById(R.id.btnFloatImport), btnPaste = floatView.findViewById(R.id.btnFloatPaste), btnClear = floatView.findViewById(R.id.btnFloatClear), btnCheck = floatView.findViewById(R.id.btnFloatCheck), btnCopy = floatView.findViewById(R.id.btnFloatCopy), btnJump = floatView.findViewById(R.id.btnFloatJump), btnClose = floatView.findViewById(R.id.btnFloatCloseAll);
        btnFloatSwitch = floatView.findViewById(R.id.btnFloatSwitch);

        editFloatInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (count > 2 && !MainActivity.isCleanDialogOpen) {
                    String chunk = s.subSequence(start, start + count).toString();
                    if (MainActivity.hasSymbolBurst(chunk)) AppExecutors.MAIN.post(() -> MainActivity.checkAndPromptCleanup(FloatingService.this, editFloatInput.getText().toString(), cleaned -> {
                        if (!cleaned.equals(editFloatInput.getText().toString())) {
                            MainActivity.isCleanDialogOpen = true; editFloatInput.setText(cleaned); editFloatInput.setSelection(cleaned.length()); sp.edit().putString("sync_text", cleaned).apply(); MainActivity.isCleanDialogOpen = false;
                        }
                    }));
                }
            }
            @Override public void afterTextChanged(Editable s) {
                if (!isChecking) currentHistoryFileId = null;
                if (s.length() > 0 && !sp.getBoolean("is_fast_mode", false)) MainActivity.warmProEngineAsync(FloatingService.this);
                AppExecutors.MAIN.removeCallbacks(syncTextRunnable);
                AppExecutors.MAIN.postDelayed(syncTextRunnable, 400);
            }
        });

        floatView.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_OUTSIDE) {
                if (MainActivity.isCleanDialogOpen) return true;
                if (panelInput.getVisibility() == View.VISIBLE) { panelInput.setVisibility(View.GONE); setFocusable(false); }
                return true;
            }
            return false;
        });

        btnImport.setOnClickListener(v -> { Intent intent = new Intent(this, FilePickerActivity.class); intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(intent); });
        btnPaste.setOnClickListener(v -> {
            ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (clipboard != null && clipboard.hasPrimaryClip() && clipboard.getPrimaryClip().getItemCount() > 0) {
                CharSequence value = clipboard.getPrimaryClip().getItemAt(0).getText();
                if (value != null) MainActivity.checkAndPromptCleanup(this, value.toString(), cleaned -> {
                    currentHistoryFileId = null; editFloatInput.setText(cleaned); sp.edit().putString("sync_text", cleaned).apply();
                    if (panelInput.getVisibility() != View.VISIBLE) { panelInput.setVisibility(View.VISIBLE); setFocusable(true); }
                });
            }
        });
        btnClear.setOnClickListener(v -> { currentHistoryFileId = null; lastCorrectedText = ""; editFloatInput.setText(""); });
        btnCheck.setOnClickListener(v -> {
            String text = editFloatInput.getText().toString();
            if (text.isEmpty()) { Toast.makeText(this, "文本为空", Toast.LENGTH_SHORT).show(); return; }
            if (currentHistoryFileId == null) currentHistoryFileId = java.util.UUID.randomUUID().toString();
            String fileId = currentHistoryFileId; saveHistory(text, fileId); setFocusable(false); panelInput.setVisibility(View.GONE); startInference(text, fileId);
        });
        btnCopy.setOnClickListener(v -> {
            String text = lastCorrectedText.isEmpty() ? editFloatInput.getText().toString() : lastCorrectedText;
            ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (clipboard != null) { clipboard.setPrimaryClip(ClipData.newPlainText("Corrected", text)); showStatus("已复制修正后的全文。", true); }
        });
        btnFloatSwitch.setOnClickListener(v -> {
            boolean fast = !sp.getBoolean("is_fast_mode", false); sp.edit().putBoolean("is_fast_mode", fast).apply(); showStatus(fast ? "已切换至极速模式（不查“的地得”）" : "已切换至专业 RoFormer", true);
            if (!fast && editFloatInput.length() > 0) MainActivity.warmProEngineAsync(FloatingService.this);
        });

        Runnable jumpToApp = () -> {
            if (MainActivity.isEditorOpen) { Toast.makeText(this, "编辑模式中无法跳转，请先保存或退出。", Toast.LENGTH_SHORT).show(); return; }
            Intent intent = new Intent(this, MainActivity.class); intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP); intent.putExtra("SYNC_TEXT", editFloatInput.getText().toString()); intent.putExtra("FROM_FLOAT_JUMP", true); startActivity(intent);
            panelInput.setVisibility(View.GONE); setFocusable(false);
        };
        btnJump.setOnClickListener(v -> jumpToApp.run()); btnClose.setOnClickListener(v -> stopSelf());

        View.OnTouchListener dragListener = new View.OnTouchListener() {
            int initialX, initialY; float initialTouchX, initialTouchY; boolean moved, longPressed;
            final Runnable longPress = () -> { longPressed = true; jumpToApp.run(); };
            @Override public boolean onTouch(View view, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x; initialY = params.y; initialTouchX = event.getRawX(); initialTouchY = event.getRawY(); moved = false; longPressed = false;
                        if (view.getId() == R.id.btnCircle) AppExecutors.MAIN.postDelayed(longPress, 500); return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx = (int) (event.getRawX() - initialTouchX), dy = (int) (event.getRawY() - initialTouchY);
                        if (!moved && (Math.abs(dx) > 10 || Math.abs(dy) > 10)) { moved = true; AppExecutors.MAIN.removeCallbacks(longPress); }
                        if (moved && !destroyed) { params.x = initialX + dx; params.y = initialY + dy; try { windowManager.updateViewLayout(floatView, params); } catch (Exception ignored) {} }
                        return true;
                    case MotionEvent.ACTION_UP: case MotionEvent.ACTION_CANCEL:
                        AppExecutors.MAIN.removeCallbacks(longPress);
                        if (!moved && !longPressed && view.getId() == R.id.btnCircle) {
                            if (isChecking) { isInterruptRequested = true; showStatus("已中断", true); }
                            else {
                                boolean visible = panelInput.getVisibility() == View.VISIBLE;
                                if (!visible) {
                                    String sync = sp.getString("sync_text", "");
                                    if (!sync.isEmpty() && !sync.equals(editFloatInput.getText().toString())) { MainActivity.isCleanDialogOpen = true; editFloatInput.setText(sync); MainActivity.isCleanDialogOpen = false; }
                                }
                                panelInput.setVisibility(visible ? View.GONE : View.VISIBLE); setFocusable(!visible);
                            }
                        }
                        return true;
                }
                return false;
            }
        };
        btnCircle.setOnTouchListener(dragListener); panelTopBar.setOnTouchListener(dragListener); panelInput.setOnTouchListener(dragListener);
        windowManager.addView(floatView, params);
    }

    private void saveHistory(String text, String fileId) {
        HistoryStore.save(this, sp, text, fileId, savedId -> currentHistoryFileId = savedId);
    }

    private void setFocusable(boolean focusable) {
        if (destroyed || floatView == null) return;
        params.flags = focusable ? WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH : WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH;
        try { windowManager.updateViewLayout(floatView, params); } catch (Exception ignored) {}
    }

    private void showStatus(String message, boolean autoHide) {
        AppExecutors.MAIN.post(() -> {
            if (destroyed) return;
            tvStatus.setText(message); statusContainer.setVisibility(View.VISIBLE); floatProgressBar.setVisibility(View.GONE); statusContainer.removeCallbacks(hideStatusRunnable);
            if (autoHide) statusContainer.postDelayed(hideStatusRunnable, 3000);
        });
    }

    private String compactErrorStatus(String message) {
        String value = message == null ? "" : message.replace("发现错误：", "").replace(" (置信度:", "（").replace(") | 共 ", "）｜共").replace(" | 共 ", "｜共");
        if (value.length() <= 24) return value;
        int suffixIndex = value.lastIndexOf("｜共");
        String suffix = suffixIndex >= 0 ? value.substring(suffixIndex) : "";
        int keep = Math.max(8, 23 - suffix.length());
        return value.substring(0, Math.min(keep, value.length())) + "…" + suffix;
    }

    private void showErrorStatus(String message) {
        synchronized (errorStatusLock) {
            visibleErrorLines.addLast(compactErrorStatus(message));
            while (visibleErrorLines.size() > 3) visibleErrorLines.removeFirst();
            if (!errorStatusFlushScheduled) {
                errorStatusFlushScheduled = true;
                AppExecutors.MAIN.postDelayed(errorStatusFlushRunnable, 40);
            }
        }
    }

    private void finishAfterLastErrorIsVisible(CorrectionCore.Result result) {
        AppExecutors.MAIN.post(new Runnable() {
            @Override public void run() {
                if (destroyed || isInterruptRequested) { finishInterrupted(); return; }
                synchronized (errorStatusLock) {
                    if (errorStatusFlushScheduled) {
                        AppExecutors.MAIN.postDelayed(this, 30);
                        return;
                    }
                }
                long visibleFor = android.os.SystemClock.uptimeMillis() - lastErrorShownAt;
                long delay = result.errorCount > 0 ? Math.max(0L, MIN_LAST_ERROR_VISIBLE_MS - visibleFor) : 0L;
                AppExecutors.MAIN.postDelayed(() -> finishSuccess(result), delay);
            }
        });
    }

    private void startInference(String text, String fileId) {
        boolean fast = sp.getBoolean("is_fast_mode", false);
        float storedTemperature = MainActivity.parseFloatSafe(sp.getString("pro_temp", "1.2"), Float.NaN);
        if (!fast && !MainActivity.isTemperatureValid(storedTemperature)) {
            storedTemperature = 1.2f;
            sp.edit().putString("pro_temp", "1.2").apply();
            Toast.makeText(this, "温度参数无效，已自动恢复为1.2（允许范围0.5～2.0）", Toast.LENGTH_LONG).show();
        }
        final float temperature = fast ? 1f : storedTemperature;
        // 极速模式不使用模型；专业模式会在输入变动时预热，纠错结束后按使用间隔自适应保留30～120秒再释放。
        float tDe = MainActivity.parseFloatSafe(sp.getString("pro_th1", "0.76"), 0.76f);
        float tDi = MainActivity.parseFloatSafe(sp.getString("pro_th2", "0.74"), 0.74f);
        float tDe3 = MainActivity.parseFloatSafe(sp.getString("pro_th3", "0.78"), 0.78f);
        if (!fast) MainActivity.noteProCorrectionStart(this);
        isChecking = true; isInterruptRequested = false; btnFloatSwitch.setEnabled(false); lastErrorShownAt = 0;
        synchronized (errorStatusLock) { visibleErrorLines.clear(); errorStatusFlushScheduled = false; }
        AppExecutors.MAIN.removeCallbacks(errorStatusFlushRunnable);
        showStatus("正在纠错……", false); floatProgressBar.setVisibility(View.VISIBLE); floatProgressBar.setProgress(0); circleSpin.setVisibility(View.VISIBLE);

        AppExecutors.INFERENCE.execute(() -> {
            boolean proAcquired = false;
            try {
                if (!fast) {
                    proAcquired = MainActivity.acquireProEngine(this);
                    if (!proAcquired) throw new IllegalStateException("专业 RoFormerV2 模型加载失败：" + SecureAsset.lastErrorSummary());
                }
                CorrectionCore.Result result = CorrectionCore.run(text, fast, temperature, tDe, tDi, tDe3, new CorrectionCore.Listener() {
                    @Override public boolean isCancelled() { return isInterruptRequested || destroyed; }
                    @Override public void onProgress(int current, int total, List<List<MainActivity.TextBlock>> completed, int errors, long elapsed) {
                        AppExecutors.MAIN.post(() -> { if (!destroyed && !isInterruptRequested) { floatProgressBar.setMax(total); floatProgressBar.setProgress(current); } });
                    }
                    @Override public void onError(String message, boolean minimumDisplay) { showErrorStatus(message); }
                });
                if (result == null || isInterruptRequested || destroyed) { finishInterrupted(); return; }
                lastCorrectedText = result.cleanText;
                MainActivity.pendingFloatBlocks = result.blocks; MainActivity.pendingFloatTimeMs = result.elapsedMs; MainActivity.pendingFloatFileId = fileId; MainActivity.hasNewFloatResult = true;
                HistoryStore.saveBlocks(this, fileId, result.blocks);
                AppExecutors.MAIN.post(() -> { if (MainActivity.instance != null && !MainActivity.instance.isFinishing()) MainActivity.instance.onFloatResultReady(); });
                finishAfterLastErrorIsVisible(result);
            } catch (Exception exception) {
                AppExecutors.MAIN.post(() -> {
                    if (destroyed) return; isChecking = false; btnFloatSwitch.setEnabled(true); circleSpin.setVisibility(View.INVISIBLE); floatProgressBar.setVisibility(View.GONE);
                    Toast.makeText(this, "纠错中断: " + exception.getMessage(), Toast.LENGTH_SHORT).show();
                });
            } finally {
                if (proAcquired) MainActivity.releaseProEngine();
            }
        });
    }

    private void finishInterrupted() {
        AppExecutors.MAIN.post(() -> { if (!destroyed) { isChecking = false; btnFloatSwitch.setEnabled(true); circleSpin.setVisibility(View.INVISIBLE); floatProgressBar.setVisibility(View.GONE); } });
    }

    private void finishSuccess(CorrectionCore.Result result) {
        if (destroyed || isInterruptRequested) { finishInterrupted(); return; }
        isChecking = false; btnFloatSwitch.setEnabled(true); circleSpin.setVisibility(View.INVISIBLE);
        showStatus(result.errorCount == 0 ? "未检测到错误" : "已完成，共修正 " + result.errorCount + " 处", true);
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (clipboard != null) clipboard.setPrimaryClip(ClipData.newPlainText("Corrected", result.cleanText));
    }

    @Override public IBinder onBind(Intent intent) { return null; }
    @Override public void onDestroy() {
        destroyed = true; isInterruptRequested = true; AppExecutors.MAIN.removeCallbacks(syncTextRunnable); AppExecutors.MAIN.removeCallbacks(hideStatusRunnable); AppExecutors.MAIN.removeCallbacks(errorStatusFlushRunnable);
        synchronized (errorStatusLock) { visibleErrorLines.clear(); errorStatusFlushScheduled = false; }
        if (statusContainer != null) statusContainer.removeCallbacks(hideStatusRunnable);
        if (floatView != null && windowManager != null) try { windowManager.removeView(floatView); } catch (Exception ignored) {}
        super.onDestroy();
    }
}
