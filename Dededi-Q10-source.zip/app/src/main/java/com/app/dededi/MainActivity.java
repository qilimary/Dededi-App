package com.app.dededi;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.SuppressLint;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.Html;
import android.text.InputFilter;
import android.text.Layout;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.TextWatcher;
import android.text.method.LinkMovementMethod;
import android.text.style.BackgroundColorSpan;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.StrikethroughSpan;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewAnimationUtils;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions;
import org.json.JSONArray;
import org.json.JSONObject;
import org.pytorch.executorch.Module;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.Stack;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {
    static { System.loadLibrary("dededi"); }

    public static MainActivity instance;
    public static volatile Module proModule;
    private static final Object PRO_MODEL_LOCK = new Object();
    private static final Handler PRO_MODEL_HANDLER = new Handler(Looper.getMainLooper());
    private static final IdlePolicy PRO_IDLE = new IdlePolicy();
    private static final AtomicBoolean proWarmQueued = new AtomicBoolean();
    private static SharedPreferences proIdlePreferences;
    private static long proIdleLastSave;
    // This lock only guards a few scalar values. No model work or disk IO runs inside it.
    // Adaptive learning is based strictly on: previous correction finished -> next correction started.
    // Typing/prewarm activity may keep the model alive, but never becomes a learning sample.
    static final class IdlePolicy {
        static final long MIN_MS = 30_000L, MAX_MS = 120_000L;
        private long timeout = 60_000L, lastActivity, lastCorrectionFinished;
        synchronized void restore(long saved) { timeout = Math.max(MIN_MS, Math.min(MAX_MS, saved)); }
        synchronized void activity(long now) { lastActivity = now; }
        synchronized boolean correctionStarted(long now) {
            long old = timeout;
            if (lastCorrectionFinished > 0L) {
                long gap = now - lastCorrectionFinished;
                if (gap >= 5_000L && gap <= 300_000L) {
                    long goal = Math.max(MIN_MS, Math.min(MAX_MS, gap + 10_000L));
                    timeout = Math.max(MIN_MS, Math.min(MAX_MS, timeout + Math.round((goal - timeout) * 0.2)));
                }
            }
            lastActivity = now;
            return old != timeout;
        }
        synchronized void correctionFinished(long now) {
            lastCorrectionFinished = now;
            lastActivity = now;
        }
        synchronized long timeout() { return timeout; }
        synchronized long remaining(long now) { return Math.max(0L, timeout - Math.max(0L, now - lastActivity)); }
    }
    private static void loadIdlePolicy(Context context) {
        if (proIdlePreferences != null) return;
        proIdlePreferences = context.getSharedPreferences("DedediModelIdle", MODE_PRIVATE);
        PRO_IDLE.restore(proIdlePreferences.getLong("timeout_ms", 60_000L));
    }
    private static void persistIdlePolicy() {
        long now = android.os.SystemClock.uptimeMillis();
        if (proIdlePreferences != null && now - proIdleLastSave >= 60_000L) {
            long value = PRO_IDLE.timeout();
            if (proIdlePreferences.getLong("timeout_ms", 60_000L) != value) proIdlePreferences.edit().putLong("timeout_ms", value).apply();
            proIdleLastSave = now;
        }
    }
    private static int proModuleUsers;
    private static File proPlainModelFile;
    private static final Runnable PRO_MODEL_RELEASE_TASK = () -> AppExecutors.INFERENCE.execute(MainActivity::releaseProEngineNowIfIdle);
    public static final int[] proCharIds = new int[Character.MAX_VALUE + 1];
    public static volatile boolean proVocabReady;
    public static long clsId = 101L, sepId = 102L, maskId = 103L, unkId = 100L;
    public static final float MIN_TEMPERATURE = 0.5f;
    public static final float MAX_TEMPERATURE = 2.0f;
    private static volatile TypoIndex typoIndex = TypoIndex.build(new HashMap<>(), new HashSet<>(), new HashMap<>());
    private static final Pattern TYPO_FIELDS = Pattern.compile("\\s+");
    public static TypoIndex currentTypoIndex() { return typoIndex; }
    public static volatile boolean typoMapLoaded, isCleanDialogOpen, isEditorOpen, isWaitingForFloatResult, hasNewFloatResult;
    public static List<List<TextBlock>> allSentencesBlocks = new ArrayList<>(), pendingFloatBlocks = new ArrayList<>();
    public static long lastTimeMs, pendingFloatTimeMs;
    public static String pendingFloatFileId;

    public interface TextCleanCallback { void onCleaned(String text); }
    public interface TextExtractCallback { void onStart(); void onProgress(int progress, int max); void onExtracted(String text); }

    public static float parseFloatSafe(String value, float fallback) {
        try { float parsed = Float.parseFloat(value); return Float.isFinite(parsed) ? parsed : fallback; } catch (Exception ignored) { return fallback; }
    }

    public static boolean isTemperatureValid(float temperature) {
        return Float.isFinite(temperature) && temperature >= MIN_TEMPERATURE && temperature <= MAX_TEMPERATURE;
    }

    public static float sanitizeTemperature(String value, float fallback) {
        float parsed = parseFloatSafe(value, fallback);
        return isTemperatureValid(parsed) ? parsed : fallback;
    }

    private static int countLettersOrDigits(CharSequence text, int start, int end) {
        if (text == null || text.length() == 0) return 0;
        int safeStart = Math.max(0, Math.min(start, text.length()));
        int safeEnd = Math.max(safeStart, Math.min(end, text.length()));
        int count = 0;
        for (int i = safeStart; i < safeEnd; i++) if (Character.isLetterOrDigit(text.charAt(i))) count++;
        return count;
    }

    private static int countWithPunctuation(CharSequence text, int start, int end) {
        if (text == null || text.length() == 0) return 0;
        int safeStart = Math.max(0, Math.min(start, text.length()));
        int safeEnd = Math.max(safeStart, Math.min(end, text.length()));
        int count = 0;
        for (int i = safeStart; i < safeEnd; ) {
            int cp = Character.codePointAt(text, i);
            if (!Character.isWhitespace(cp) && cp != 0x3000) count++;
            i += Character.charCount(cp);
        }
        return count;
    }

    public static boolean hasSymbolBurst(CharSequence text) {
        int stars = 0, hashes = 0, dashes = 0;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c == '*' && ++stars >= 4) return true;
            if (c == '#' && ++hashes >= 4) return true;
            if (c == '-' && ++dashes >= 4) return true;
        }
        return false;
    }

    public static void checkAndPromptCleanup(Context context, String text, TextCleanCallback callback) {
        if (isCleanDialogOpen || text == null || text.isEmpty()) { if (callback != null) callback.onCleaned(text); return; }
        int stars = 0, hashes = 0, dashes = 0;
        for (int i = 0; i < text.length(); i++) { char c = text.charAt(i); if (c == '*') stars++; else if (c == '#') hashes++; else if (c == '-') dashes++; }
        if (stars < 4 && hashes < 4 && dashes < 4) { if (callback != null) callback.onCleaned(text); return; }
        isCleanDialogOpen = true; SymbolCleanActivity.callback = callback;
        Intent intent = new Intent(context, SymbolCleanActivity.class); intent.putExtra("raw_text", text); intent.putExtra("star", stars >= 4); intent.putExtra("hash", hashes >= 4); intent.putExtra("dash", dashes >= 4); intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP); context.startActivity(intent);
    }

    public static class QuantifierRule {
        public final String primaryQuant, allowedQuants;
        QuantifierRule(String primary, String allowed) { primaryQuant = primary; allowedQuants = allowed; }
    }
    public static class GramRule {
        public final Pattern pattern; public final String[][] options; public final boolean professionalOnly;
        GramRule(String regex, String[][] options, boolean professionalOnly) { pattern = Pattern.compile(regex); this.options = options; this.professionalOnly = professionalOnly; }
    }
    public static final Map<Character, QuantifierRule> quantRules = new HashMap<>();
    public static final List<GramRule> gramRules = new ArrayList<>();
    public static final List<Pattern> protectedTargetPatterns = new ArrayList<>();
    private static boolean rulesAttempted;

    private static void addRule(String regex, String[][] options) { gramRules.add(new GramRule(regex, options, false)); }
    private static void addProfessionalRule(String regex, String[][] options) { gramRules.add(new GramRule(regex, options, true)); }
    private static void addProtectedTargetPattern(String regex) { protectedTargetPatterns.add(Pattern.compile(regex)); }

    public static synchronized void ensureRulesLoaded() {
        if (rulesAttempted) return;
        rulesAttempted = true;
        try {
            addRule("(给|为)([^，,。；;！？!?：:\n]{1,24}?)(让坐)(?!下|在|到|着|落|稳)", new String[][]{{null, "让座"}});
            addRule("(?:(?<=[一二两三四五六七八九十百千万这那几某0-9买换有要带借拿送租弄])|^)(个)()(电脑)(?!游戏|软件|程序|系统|应用|品牌|型号|配件|主板|屏幕|键盘|鼠标|电源|机箱|硬盘|显卡|内存|接口|文件|病毒|桌面|窗口|图标|账户|账号|网站|网络|课程|专业|公司|商店|维修|问题|高手|天才|爱好者|玩家|用户|工程师|技术|知识|操作|设置|配置|版本|模拟器|控制器)(?=$|[^\u4E00-\u9FFF]|[的了着过是在被把让给对和与同或就也都还很太真会能可要想走跑跳吃喝咬叫哭笑我看你他她它们这那买卖送坏出装用])", new String[][]{{"台", null}});
            addRule("(大概|大约)([^，。；！？、\\n]{1,15}?)(左右|上下)", new String[][]{{null, ""}, {"", null}});
            addRule("(超过|高达|多达)([^，。；！？、\\n]{1,15}?)(以上)", new String[][]{{null, ""}, {"", null}});
            addRule("(低于|少于|不足)([^，。；！？、\\n]{1,15}?)(以下)", new String[][]{{null, ""}, {"", null}});
            addRule("(截至|截止到)([^，。；！？、\\n]{1,15}?)(为止)", new String[][]{{null, ""}, {"", null}});
            addRule("(涉及|波及)( *)(到)", new String[][]{{null, ""}});
            addRule("(付诸|诉诸|见诸)( *)(于)", new String[][]{{null, ""}});
            addRule("(互相|相互)( *)(厮打|角逐|探讨|商榷)", new String[][]{{"", null}});
            addRule("(第一|最佳|首要)( *)(首选)", new String[][]{{"", null}});
            addRule("(并非)( *)(是)", new String[][]{{null, ""}, {"并不", null}});
            addRule("(无时无刻)( *)(都)", new String[][]{{null, "不"}});
            addRule("(靠的是)([^，,。；;！？!?：:\n]{1,24}?)(取得的|获得的|实现的|达成的)(?=[，,。；;！？!?：:\n]|$)", new String[][]{{null, "", "句式杂糅"}});
            addRule("(成分是|主要成分是)([^，,。；;！？!?：:\n]{1,24}?)(配制而成的)(?=[，,。；;！？!?：:\n]|$)", new String[][]{{null, "", "句式杂糅"}});
            addRule("(成分有|主要成分有)([^，,。；;！？!?：:\n]{1,24}?)(配制而成的)(?=[，,。；;！？!?：:\n]|$)", new String[][]{{null, "", "句式杂糅"}});
            addRule("(大约|大概|约|近|将近|差不多|超|超过|超出|达|高达|达到)( *)([0-9一二两三四五六七八九十百千万亿]+ *左右|[0-9一二两三四五六七八九十百千万亿]+ *上下)", new String[][]{{"有", null}, {"", null}});
            addRule("(几(?:十|百|千|万|亿)?|十几|几十|百余|千余|万余|亿余|数十|数百|数千|数万|数十万|数百万|数千万|数亿|上百|上千|上万|上亿|上百万|上千万|成百上千|成千上万|二三十|三四十|四五十|五六十|六七十|七八十|八九十)([ 　]*[^，。；！？、\\n的地得着了过在又后前上下左右]{0,4}?[ 　]*)(左右|上下)(?!划|移动|摇|摆|晃|浮|跳|走|看|张望|转|翻|起伏|震动|颠簸|滑|游|飞|跑|滚|上下班|班|文|铺|楼|车|床|台|手|脚|眼|打量|扫视|观察|攀爬|穿梭|升降|下沉|下降|上升|落|沉|坠)", new String[][]{{null, ""}});

            // 只保留需要跨词/跨字泛化的语病规则；固定短词替换交给错词库。
            // “多/余/来/几”等已经表示约数，再叠加“左右/上下”属于重复限定。
            // 中间允许跨过“个、人、岁、名、位、公里”等短数量单位，因此“20多个人左右”也能覆盖。
            addRule("([0-9一二两三四五六七八九十百千万亿]+(?:多|余|来)|[0-9]+几|[一二两三四五六七八九]十几)([ 　]*[^，。；！？、\\n的地得着了过在又后前上下左右]{0,8}?[ 　]*)(左右|上下)(?!划|移动|摇|摆|晃|浮|跳|走|看|张望|转|翻|起伏|震动|颠簸|滑|游|飞|跑|滚|上下班|班|文|铺|楼|车|床|台|手|脚|眼|打量|扫视|观察|攀爬|穿梭|升降|下沉|下降|上升|落|沉|坠)", new String[][]{{null, "", "重复啰嗦"}});
            // “约/大约/大概/将近/接近 + 数字 + 多/余/来”：双重约数，只保留一种约数标记。
            addRule("(约|大约|大概|将近|接近)([ 　]*[0-9一二两三四五六七八九十百千万亿两零〇]+[ 　]*)(多|余|来)(?=[个人名位只条头匹辆部台口尾座把本次场局件张岁年月日天小时分钟秒米公里斤公斤千克克吨亩公顷元万元亿元%％度])", new String[][]{{"", null, "重复啰嗦"}});
            // “大概/大约/约（是/有）近/接近/将近 + 数字”：两个近似标记叠加，删除后一个。
            addRule("(大概|大约|约)([ 　]*(?:是|有)?[ 　]*)(近|接近|将近)(?=[ 　]*[0-9一二两三四五六七八九十百千万亿两零〇])", new String[][]{{null, "", "重复啰嗦"}});
            // “约/近/将近/差不多 + 明确数字 + 单位 + 左右/上下”：要求中间出现数字，降低“近”的词义歧义。
            addRule("(约|将近|差不多|(?<!附)近)([ 　]*[0-9一二两三四五六七八九十百千万亿]+[ 　]*[^，。；！？、\\n]{0,8}?[ 　]*)(左右|上下)(?!划|移动|摇|摆|晃|浮|跳|走|看|张望|转|翻|起伏|震动|颠簸|滑|游|飞|跑|滚|上下班|班|文|铺|楼|车|床|台|手|脚|眼|打量|扫视|观察|攀爬|穿梭|升降|下沉|下降|上升|落|沉|坠)", new String[][]{{null, "", "重复啰嗦"}});

            // “不少于/不低于……以上”及“不超过/不高于……以内/以下”：上下限表达重复；要求中间明确出现数字。
            addRule("(不少于|不低于)([^，,。；;！？!?：:\n]{0,12}?[0-9一二两三四五六七八九十百千万亿两]+[^，,。；;！？!?：:\n]{0,8}?)(以上)(?=[，,。；;！？!?：:\n]|$)", new String[][]{{null, "", "重复啰嗦"}});
            addRule("(不超过|不高于|至多)([^，,。；;！？!?：:\n]{0,12}?[0-9一二两三四五六七八九十百千万亿两]+[^，,。；;！？!?：:\n]{0,8}?)(以内|以下)(?=[，,。；;！？!?：:\n]|$)", new String[][]{{null, "", "重复啰嗦"}});
            // “云集了……名/位/人……参加”：要求出现明确的人数/人员量词，并在“参加”处收束分句。
            addRule("(云集(?:了)?)([^，,。；;！？!?：:\n]{0,24}?[0-9一二两三四五六七八九十百千万几两]+(?:多|余|来)?(?:名|位|人)[^，,。；;！？!?：:\n]{0,8}?)(参加(?:了)?)(?=[，,。；;！？!?：:\n]|$)", new String[][]{{null, "", "句式杂糅"}});

            // “分为/分成……部分组成(构成)”：两套构成句式杂糅。
            addRule("(分为|分成)([^由，。；！？\\n]{1,30}?)(部分(?:所)?(?:组成|构成))(?=[，。；！？、\\n的]|$)", new String[][]{{null, "部分", "句式杂糅"}});
            // “包括/包含……组成(构成)”：要求中间明确出现“数量+结构单位”，并在分句末收束，避免把“蛋白质的组成”等名词结构误判。
            addRule("(包括|包含)([^，。；！？\\n]{0,30}?(?:[0-9一二两三四五六七八九十百千万几两]+|若干|数个|多个|若干个)(?:个|项|类|种)?[^，。；！？\\n]{0,10}?(?:部分|模块|方面|环节|阶段|要素|因素|成分|元素|成员|项目|类别|类型|内容))([ 　]*(?:所)?(?:组成|构成))(?=[，,。；;！？!?：:\\n]|$)", new String[][]{{null, "", "句式杂糅"}});
            // “根据/依据/据 + 信息源 + 显示/表明……”：两套引述句式杂糅；只在信息源明确且谓语收束分句时处理。
            String evidenceSource = "调查|研究|统计|数据|资料|报告|监测|测算|实验|分析|结果|图表|报道|通报|公告|问卷|普查|专家|学者|机构|实际|情况|状况|现实|现状|形势|经验|常识";
            // “根据数据显示看 / 根据调查表明来看”：统一成“从……来看”。
            addRule("(?<![\u4E00-\u9FFFA-Za-z0-9])(根据|依据|据)([^，,。；;！？!?：:\n]{0,28}?(?:" + evidenceSource + "))([ 　]*(?:显示|表明)(?:来)?看)(?=[，,。；;！？!?：:\n]|$)", new String[][]{{"从", "来看", "句式杂糅"}});
            // “根据目前情况来看 / 依据数据看”：统一成“从……来看/看”。
            addRule("(?<![\u4E00-\u9FFFA-Za-z0-9])(根据|依据|据)([^，,。；;！？!?：:\n]{0,28}?(?:" + evidenceSource + "))([ 　]*(?:来)?看)(?=[，,。；;！？!?：:\n]|$)", new String[][]{{"从", null, "句式杂糅"}});
            addRule("(?<![\u4E00-\u9FFFA-Za-z0-9])(根据|依据|据)([^，,。；;！？!?：:\n]{0,28}?(?:" + evidenceSource + "))([ 　]*(?:显示|表明))(?=[，,。；;！？!?：:\n]|$)", new String[][]{{"", null, "句式杂糅"}});
            // “通过调查/研究/数据分析……显示/表明”：句首“通过……”与“……显示”杂糅；限定到信息源并收束分句。
            addRule("(?<![\u4E00-\u9FFFA-Za-z0-9])(通过)([^，,。；;！？!?：:\\n]{0,28}?(?:" + evidenceSource + "))([ 　]*(?:显示|表明))(?=[，,。；;！？!?：:\\n]|$)", new String[][]{{"", null, "句首句式杂糅"}});
            // “是由于/是因为……导致的(造成的/引起的)”：改为“是由……导致/造成/引起的”。
            addRule("(是由于|是因为)([^，,。；;！？!?：:\n]{1,28}?)((?:所)?导致的|(?:所)?造成的|(?:所)?引起的|(?:所)?决定的)(?=[，,。；;！？!?：:\n]|$)", new String[][]{{"是由", null, "句式杂糅"}});
            // 其他跨词句式杂糅，均收紧到分句边界，优先控制误报。
            addRule("((?<!在)受)([^，,。；;！？!?：:\\n]{1,24}?影响)(下)(?=[，,。；;！？!?：:\\n]|$)", new String[][]{{null, "", "句式杂糅"}});
            addRule("(对于)([^，,。；;！？!?：:\\n]{1,16}?)(看来)(?=[，,。；;！？!?：:\\n]|$)", new String[][]{{"在", null, "“对于……看来”应改为“在……看来”或“对于……来说”"}});
            addRule("(对)([^，,。；;！？!?：:\\n]{1,20}?)(没有引起重视)(?=[，,。；;！？!?：:\\n]|$)", new String[][]{{null, "没有重视", "句式杂糅"}});
            addRule("(对)([^，,。；;！？!?：:\\n]{1,20}?)(没引起重视)(?=[，,。；;！？!?：:\\n]|$)", new String[][]{{null, "没重视", "句式杂糅"}});
            addRule("(对)([^，,。；;！？!?：:\\n]{1,20}?)(未引起重视)(?=[，,。；;！？!?：:\\n]|$)", new String[][]{{null, "未重视", "句式杂糅"}});
            addRule("(听到|听见)([^，,。；;！？!?：:\\n]{1,24}?的消息)(传来)(?=[，,。；;！？!?：:\\n]|$)", new String[][]{{null, "", "句式杂糅"}});
            // “比……相比”需要跨越比较对象；排除“比赛/比较/比例”等普通词。
            addRule("(比)(?!赛|较|例|如|方|值|率|重|特|照|喻|拟|邻|丘|翼|目|肩|及|附|索)([^，,。；;！？!?：:\\n]{1,20}?)(相比)", new String[][]{{"与", null, "句式杂糅"}, {null, "", "句式杂糅"}});

            // 更多公开病句资料中反复出现的跨词句式；都要求明确结构或分句边界。
            // “根据……实际/情况/条件出发”：可改“从……出发”或仅保留“根据……”。
            addRule("(?<![\u4E00-\u9FFFA-Za-z0-9])(根据|依据)([^，,。；;！？!?：:\n]{1,24}?(?:实际|情况|状况|条件|特点|现实|现状))([ 　]*出发)(?=[，,。；;！？!?：:\n]|$)", new String[][]{{"从", null, "句式杂糅"}, {null, "", "句式杂糅"}});
            // “来源……来自/源自”：保留“来源”作中心词，统一把后面的“来自/源自”改成“是”，避免“资金的来源来自于……”随机生成坏句。
            addRule("(来源)([ 　]*(?:主要|只能|均|都|全部|大多|一般|往往|通常)?[ 　]*)(来自于?|源自于?)", new String[][]{{null, "是", "重复啰嗦"}});
            // “来源是来自/源自……”：已有“是”时直接删除后面的“来自/源自”。
            addRule("(来源(?:主要|均|都|全部|大多|一般|往往|通常)?是)([ 　]*)(来自于?|源自于?)", new String[][]{{null, "", "“来源是……”后不再叠加“来自/源自”"}});
            // “最好……比较合适”：只在“比较合适”收束分句时处理，不碰“比较合适的方案”。
            addRule("(最好)([^，,。；;！？!?：:\n]{1,24}?)(比较合适)(?=[，,。；;！？!?：:\n]|$)", new String[][]{{null, "", "句式杂糅"}, {"", null, "句式杂糅"}});
            // “是受……影响造成/导致/引起的”：把两套因果句式统一成“是由……造成/导致/引起的”。
            addRule("(是受)([^，,。；;！？!?：:\n]{1,24}?)(?:的)?影响(?:所)?(造成的|导致的|引起的)(?=[，,。；;！？!?：:\n]|$)", new String[][]{{"是由", null, "句式杂糅"}});
            // “作者是由……写成/撰写/创作的”：限定到分句末，避免修饰后续名词时误报。
            addRule("(作者是由)([^，,。；;！？!?：:\n]{1,24}?)(写成的|撰写的|创作的)(?=[，,。；;！？!?：:\n]|$)", new String[][]{{"作者是", "", "句式杂糅"}});
            // “采用的是以……为准”：只有“为准”到达分句边界才触发。
            addRule("(采用的是)([ 　]*以[^，,。；;！？!?：:\n]{1,24}?)(为准)(?=[，,。；;！？!?：:\n]|$)", new String[][]{{"", null, "句式杂糅"}});

            // “付出/付出了……为代价”：两套代价句式杂糅；只在“为代价”收束分句时删除后缀。
            addRule("(付出(?:了)?)([^，,。；;！？!?：:\n]{1,24}?)(为代价)(?=[，,。；;！？!?：:\n]|$)", new String[][]{{null, "", "句式杂糅"}});
            // “这要看/要看……所决定的”：保留“要看……”句式，删除后面重复的“所决定的”。
            addRule("(这要看)([^，,。；;！？!?：:\n]{1,30}?)(所决定的)(?=[，,。；;！？!?：:\n]|$)", new String[][]{{null, "", "句式杂糅"}});
            // “原因是……共同/综合/相互作用的结果”：保留“原因是……作用”，去掉重复的“结果”。
            addRule("((?:主要|根本)?原因(?:主要)?是)([^，,。；;！？!?：:\n]{1,30}?(?:共同|综合|相互)?作用)(的结果)(?=[，,。；;！？!?：:\n]|$)", new String[][]{{null, "", "句式杂糅"}});
            // “高达……之巨”：要求明确数值/约数及常见计量单位，避免泛化到普通“之巨”结构。
            addRule("(高达)([ 　]*(?:[0-9]+(?:\\.[0-9]+)?|[一二两三四五六七八九十百千万亿两数几]+)(?:多|余|来)?[ 　]*(?:元|万元|亿元|人|名|位|个|件|项|例|起|次|家|户|吨|千克|公斤|克|米|公里|平方米|平方公里|亩|公顷|年|月|天|小时|分钟|秒|%|％))([ 　]*(?:之巨|之多))(?=[，,。；;！？!?：:\n]|$)", new String[][]{{null, "", "重复啰嗦"}});

            addRule("(原因是)((?!由)[^，,。；;！？!?：:\n]{1,28}?)(所?造成的|所?导致的|所?引起的|造成|导致|引起)(?=[，,。；;！？!?：:\n]|$)", new String[][]{{null, "", "句式杂糅"}});
            addRule("(由于)([^，。；！？、\\n]{1,15}?)(的结果)", new String[][]{{null, ""}, {"", null}});
            addRule("(是因为)([^，。；！？、\\n]{1,15}?)(的原因)", new String[][]{{null, ""}, {"", null}});
            addRule("(围绕(?:[ 　]*以)?)([^，,。；;！？!?：:\\n]{1,24}?)(为中心)(?=[，,。；;！？!?：:\\n]|$)", new String[][]{{"以", null, "句式杂糅"}});
            addRule("(围绕(?:[ 　]*以)?)([^，,。；;！？!?：:\\n]{1,24}?)(为主题)(?=[，,。；;！？!?：:\\n]|$)", new String[][]{{"以", null, "句式杂糅"}});
            addRule("(围绕(?:[ 　]*以)?)([^，,。；;！？!?：:\\n]{1,24}?)(为核心|为目标)(?=[，,。；;！？!?：:\\n]|$)", new String[][]{{"以", null, "句式杂糅"}});
            addRule("(从(?:[ 　]*以)?)([^，,。；;！？!?：:\\n]{1,24}?)(为出发点)(?=[，,。；;！？!?：:\\n]|$)", new String[][]{{"以", null, "句式杂糅"}});
            addRule("(打着(?:[ 　]*以)?)([^，,。；;！？!?：:\\n]{1,24}?)(为幌子)(?=[，,。；;！？!?：:\\n]|$)", new String[][]{{"以", null, "句式杂糅"}});
            addRule("(借着(?:[ 　]*以)?)([^，,。；;！？!?：:\\n]{1,24}?)(为名义)(?=[，,。；;！？!?：:\\n]|$)", new String[][]{{"以", null, "句式杂糅"}});
            addRule("(借口(?:[ 　]*以)?)([^，,。；;！？!?：:\\n]{1,24}?)(为名)(?=[，,。；;！？!?：:\\n]|$)", new String[][]{{"以", null, "句式杂糅"}});
            addRule("(为了(?:[ 　]*以)?)([^，,。；;！？!?：:\\n]{1,24}?)(为目的)(?=[，,。；;！？!?：:\\n]|$)", new String[][]{{"以", null, "句式杂糅"}});
            addRule("(旨在(?:[ 　]*以)?)([^，,。；;！？!?：:\\n]{1,24}?)(为目的)(?=[，,。；;！？!?：:\\n]|$)", new String[][]{{"以", null, "句式杂糅"}});
            addRule("(本着(?:[ 　]*以)?)([^，,。；;！？!?：:\\n]{1,24}?)(为原则)(?=[，,。；;！？!?：:\\n]|$)", new String[][]{{"以", null, "句式杂糅"}});
            // “本着……为宗旨/为目的”：两套句式杂糅，统一为“以……为宗旨/目的”。
            addRule("(本着(?:[ 　]*以)?)([^，,。；;！？!?：:\\n]{1,24}?)(为宗旨|为目的)(?=[，,。；;！？!?：:\\n]|$)", new String[][]{{"以", null, "句式杂糅"}});
            // “根据/依据……为基础”：把“根据/依据……”与“以……为基础”两套结构统一。
            addRule("(根据|依据)([^，,。；;！？!?：:\\n]{1,28}?)(为基础)(?=[，,。；;！？!?：:\\n]|$|进行|开展|建立|制定|设计|构建|分析|研究|开发|计算|判断|推导|讨论|实施|推进|工作|处理|形成|提出|调整|改进|优化|编制|规划|建设)", new String[][]{{"以", null, "句式杂糅"}});
            // “基于……（的）基础上”：前后重复表达“以……为基础”，改为“在……（的）基础上”。
            addRule("(基于)([^，,。；;！？!?：:\\n]{1,28}?)(的?基础上)", new String[][]{{"在", null, "重复啰嗦"}});
            // “归咎于……的原因”：归咎于本身已经表达原因归属，分句末删除重复“的原因”。
            addRule("(归咎于)([^，,。；;！？!?：:\\n]{1,24}?)(的原因)(?=[，,。；;！？!?：:\\n]|$)", new String[][]{{null, "", "重复啰嗦"}});
            // “在于……而造成/导致/引起的”：两套因果句式杂糅；仅在分句末触发。
            addRule("(在于)([^，,。；;！？!?：:\\n]{1,28}?)(而(?:造成|导致|引起)的)(?=[，,。；;！？!?：:\\n]|$)", new String[][]{{null, "", "句式杂糅"}});
            addRule("(对于)([^，,。；;！？!?：:\\n]{1,20}?)(问题上)(?=[，,。；;！？!?：:\\n]|$)", new String[][]{{"在", null, "句式杂糅"}, {null, "问题", "句式杂糅"}});
            addRule("(经过)([^，,。；;！？!?：:\\n]{1,24}?(?:努力|讨论|研究|调查|考虑|协商|学习|训练|治疗|处理|改革|建设|实践|尝试|试验|实验|检查|审核|审查|指导|帮助|教育|培养|锻炼|改进|调整|修改|优化|整顿|治理|管理))([ 　]*下)(?=[，,。；;！？!?：:\\n]|$)", new String[][]{{null, "", "句式杂糅"}});
            addRule("(由于)([^，,。；;！？!?：:\\n]{1,24}?(?:影响|作用|帮助|指导|领导|支持|压力|条件|环境|背景|形势|情况下))([ 　]*下)(?=[，,。；;！？!?：:\\n]|$)", new String[][]{{"在", null, "句式杂糅"}});
            addRule("(目的是)( *)(为了)", new String[][]{{"是", null}, {null, ""}});
            addRule("((?:大多|主要|大都|基本|基本上)(?:是)?以)([^，。；！？、\n]{1,20}?)(为主)", new String[][]{{"以", null, "句式杂糅"}});
            addRule("(有)([^，,。；;！？!?：:\\n]{0,24}?(?:[0-9一二两三四五六七八九十百千万几两]+|若干|数个|多个|若干个)(?:个|项|类|种)?[^，,。；;！？!?：:\\n]{0,10}?(?:部分|模块|方面|环节|阶段|要素|因素|成分|元素|成员|项目|类别|类型|内容))([ 　]*(?:组成|构成))(?=[，,。；;！？!?：:\\n]|$)", new String[][]{{"由", null, "搭配不当"}});
            addRule("(深受)([^，。；！？、\\n]{0,10}?)(所)(?=喜爱|欢迎|爱戴|好评|青睐|瞩目)", new String[][]{{null, ""}});
            addRule("(最高|最低|最多|最少)([^，。；！？、\\n]{1,15}?)(以上|以下|左右|上下)", new String[][]{{null, ""}});
            addRule("(关键在于|关键是)([^。！？\\n]{1,20}?)(是十分重要的|是很重要的|起到重要作用|决定性的)", new String[][]{{"", null}, {null, ""}});
            addRule("(切忌)([^，。；！？、\\n]{1,15}?)(不要|不可)", new String[][]{{"千万", null}, {null, ""}});
            addRule("(避免|防止|严防)([^，。；！？、\\n]{1,15}?)(不要)(?!脸|命|紧)", new String[][]{{null, ""}});
            addRule("(防止)([^，。；！？、\\n]{1,15}?)(不再)", new String[][]{{null, "再次"}});
            addRule("(防止)([^，。；！？、\\n]{1,15}?)(不被)", new String[][]{{null, "被"}});
            addRule("(令人|让人|叫人)( *)(堪忧)", new String[][]{{"", null}, {null, "担忧"}});
            addRule("(首当其冲)(的? *)(问题|任务|事情|要务|条件)", new String[][]{{"首要", null}, {"最重要", null}});
            addRule("(改善|改变|加强)([^，。；！？、\\n]{0,8}?)(水平|素养)", new String[][]{{"提高", null}});
            addRule("(加快|加速)([^，。；！？、\\n]{0,8}?)(效率)", new String[][]{{"提高", null}});
            addRule("(缓解|减缓)([^，。；！？、\\n]{0,8}?)(态度|立场)", new String[][]{{"缓和", null}});
            addRule("(悬殊)( *)(很大|极大|特别大|非常大)", new String[][]{{null, ""}, {"差距", null}});
            addRule("(?<![\u4E00-\u9FFFA-Za-z0-9])(通过)([^，,。；;！？!?：:\\n]{1,24}?)([，,][ 　]*使)(?!用|得|劲|坏|命|绊|眼|性|气|然)", new String[][]{{null, "，", "仅处理带逗号的典型“通过……，使……”主语残缺，改为“通过……，主语……”结构"}});
            addRule("(令人|让人|叫人)( *)(贻笑大方)", new String[][]{{"", null}});
            addRule("(凯旋)( *)(而归)", new String[][]{{null, ""}});
            addRule("(可以|能够)( *)(堪称)", new String[][]{{"", null}});
            addRule("(突然|顿时|一下子)( *)(恍然大悟|豁然开朗)", new String[][]{{"", null}});

            // “忍俊不禁”本身已经包含“忍不住发笑”的意思。
            // 第一层仅处理句尾/停顿前可以完整确认的重复笑语，直接连同“的地得”一起删除。
            addRule("(忍俊不禁)()([的地得]?[ 　]*(?:笑出了声音|笑出了声|笑出声音|笑出声来|笑出声|笑得前仰后合|笑得合不拢嘴|笑得直不起腰|笑得停不下来|笑到前仰后合|笑到直不起腰|笑了起来|笑起来|笑了笑|笑个不停|笑不停|发笑起来|发笑了|发笑|笑了|笑着|笑)[ 　]*)(?=[，,。；;！？!?：:、…\n]|$)", new String[][]{{null, "", "“忍俊不禁”已包含发笑之意，删除后续重复的笑语"}});
            // 第二层遇到“说、问、看、转身”等后续动作时，只删除明确重复的笑语，不吞掉后面的动作。
            // 中间的“的/地/得”保留，之后仍可交给“的地得”模型判断，避免把句法一起破坏。
            addRule("(忍俊不禁)([的地得]?[ 　]*)(笑了起来|笑起来|笑了笑|发笑起来|发笑了|发笑|笑了|笑着|笑)(?=[ 　]*(?:对着|朝着|向着|跟着|说道|问道|答道|喊道|叫道|骂道|叹道|说|道|问|答|回答|解释|补充|提醒|告诉|喊|叫|骂|叹|讲|谈|对|朝|向|跟|一边|边|又|还|看向|望向|走向|跑向|看|望|瞧|盯|转身|回头|走|跑|坐|站|起身|低头|抬头|点头|摇头|伸手|抬手|挥手|拍|拿|放|递|推|拉|抱|继续|接着|随后|开口))", new String[][]{{null, "", "“忍俊不禁”已包含发笑之意，仅删除重复笑语并保留后续动作"}});

            addRule("(难言之隐)(的? *)(苦衷|事情|原因)", new String[][]{{null, ""}});
            addRule("(责无旁贷)(的? *)(责任|义务)", new String[][]{{null, ""}});
            addRule("(真知灼见)(的? *)(意见|看法|见解)", new String[][]{{null, ""}});
            addRule("(推断)([^。；;！？!?：:\n]{0,12}?)(很有可能会|极有可能会|有可能会|大概率会|也许会|或许会|可能会|大概会|恐怕会|兴许会|应该会|很有可能|极有可能|有可能|大概率|也许|或许|可能|大概|恐怕|兴许|没准|说不定|应该(?=是|在|有|已经|正在|会|能|可以|已|将|到了|来了|去了|回来了|离开了|发生了|出现了|成为|属于|存在|结束|开始|完成|到达|返回|回到))", new String[][]{{"推测", null, "“推断”语气较确定，与后文的不确定表达重复"}, {null, "", "“推断”语气较确定，删除后文重复的不确定表达"}});
            addRule("(至少|起码|最少)([^，。；！？、\n]{1,15}?)(以上)", new String[][]{{null, "", "重复啰嗦"}, {"", null, "重复啰嗦"}});

            // pycorrector 的经典示例包含“因该→应该、让坐→让座”，但本应用不做无条件替换：
            // “因该公司/因该项目”以及“这里不让坐/让他坐下”都可能是正常表达，只在高确定性上下文触发。
            addRule("(因该)()((?=为|是|已经|正在|尽快|尽量|及时|立即|马上|首先|先(?:行|把|做|去|来|看|说|处理|解决|完成)))", new String[][]{{"应该", null, "用字不当"}});
            String seatRecipient = "(?:[^，,。；;！？!?：:\\n]{0,10}?(?:老人|老年人|长者|孕妇|孩子|小孩|儿童|病人|患者|伤员|残疾人|乘客|客人|来宾|老师|同学|学生|朋友|长辈|父母|爸爸|妈妈|爷爷|奶奶|先生|女士|军人|工人|行人|路人|陌生人|他|她|你|您|他们|她们|大家|对方|别人|人|者|员|客|生|师|童|妇|士|友|辈))";
            addRule("((?:为|给|向)" + seatRecipient + ")([ 　]*让)(坐)(?=(?:了|过)?[吧吗呢啊呀哦嘛]?(?:[，,。；;！？!?：:、…\\n]|$))", new String[][]{{null, "座", "用字不当"}});

            // 参考 LanguageTool 中文量词规则：‘俩/仨’本身已带数量义，后接量词时改为‘两/三 + 量词’。
            String pairQuantifiers = "个|位|名|组|批|队|班|户|家|对|双|只|条|件|本|辆|台|间|座|所|头|匹|口|份|张|次|场|套|种|类|项|门|部";
            addRule("(俩)([ 　]*)(" + pairQuantifiers + ")", new String[][]{{"两", null, "数量表达不规范"}});
            addRule("(仨)([ 　]*)(" + pairQuantifiers + ")", new String[][]{{"三", null, "数量表达不规范"}});
            // 鸡鸭鹅及常见鸟类用“只”计数；要求前一字符明确是数字，且鸟名后立即到语法边界，
            // 因此“三条鸡腿”“三条孔雀鱼”不会被误改。
            addRule("(?<=[0-9一二两三四五六七八九十百千万几某])([条支])([ 　]*)(鸭子|鸡|鹅|鸽子|麻雀|喜鹊|乌鸦|鹦鹉|燕子|天鹅|孔雀|蝴蝶)(?=[的了着过是在被把让给对和与同或就也都还很太真会能可要想走跑跳飞游吃喝咬叫哭笑我看你他她它们这那正将已曾又并而却才便则，,。；;！？!?：:、…\\n]|$)", new String[][]{{"只", null, "量词搭配不当"}});

            // 参考 LanguageTool 的动宾搭配思路，但只处理中心词明确且到边界的高确定性结构。
            // ‘执行义务/职责/承诺/诺言’统一为‘履行……’，不会碰‘执行义务教育政策’这类后面仍有中心词的正常表达。
            addRule("(执行)(了?[^，,。；;！？!?：:\\n]{0,12}?)(义务|职责|承诺|诺言)(?=[了着过的所，,。；;！？!?：:、…\\n]|$)", new String[][]{{"履行", null, "搭配不当"}});

            // 标点高精度规则：只处理规范边界明确的场景，宁可漏改也不误改。
            // 并列项末尾带“啊、呀、呢、啦、哇、嘛、吧、呐”等语气助词时，
            // 这些成分已不是简单词语并列，项间应用逗号而不是顿号。
            String particleListItem = "[\\u4E00-\\u9FFFA-Za-z0-9]{1,12}[啊呀呢啦哇嘛吧呐]";
            addRule("(" + particleListItem + ")([ 　]*)(、)(?=[ 　]*" + particleListItem + "(?=[、，,。；;！？!?：:\\n]|$))", new String[][]{{null, "，", "带语气助词的并列项之间应用逗号，不用顿号"}});

            // 冲突标点串优先于“重复标点”处理，保证“，，。”这类输入能在一轮内归一。
            addRule("([，、]+)()([。；：])", new String[][]{{"", null, "删除冲突的前置逗号或顿号"}});
            addRule("([。；：])()([，、]+)", new String[][]{{null, "", "删除冲突的后置逗号或顿号"}});
            // 明显重复标点：问号/叹号的修辞性叠用不在此列。
            addRule("(，)()(，+)", new String[][]{{null, "", "删除重复逗号"}});
            // 中文聊天中“。。。/。。。。…”常用于表达无语、停顿等语气，保留三连及以上；
            // 只把更像误输入的“。。”（恰好两个）收敛成一个句号。
            addRule("(?<!。)(。)()(。)(?!。)", new String[][]{{null, "", "删除误输入的双句号；三连及以上按聊天语气保留"}});
            addRule("(；)()(；+)", new String[][]{{null, "", "删除重复分号"}});
            addRule("(：)()(：+)", new String[][]{{null, "", "删除重复冒号"}});
            addRule("(、)()(、+)", new String[][]{{null, "", "删除重复顿号"}});

            // 同一外层句中连续用冒号引出转述时，把前一个冒号降为逗号。
            // 引号出现时不触发，因此“老师说：‘小王补充：……’”这类合法嵌套不会被改。
            String reportingVerb = "(?:说|表示|指出|强调|认为|解释|补充|回答|问道|写道|称|宣布|提醒|说明)";
            addRule("([^。！？\\n：]{1,30}" + reportingVerb + ")([ 　]*)(：)(?=[^。！？\\n“”‘’]{1,40}" + reportingVerb + "[ 　]*：)", new String[][]{{null, "，", "同一外层句中连续使用转述冒号，前一个改为逗号"}});

            // E3-EMA 模型已独立通过大部分旧规则专项压力测试。以下仅保留在扩大上下文
            // 回归中仍有失败的窄规则：间歇状态修饰动作、部分方式状语、质地性质结构、
            // 以及固定专名/术语修饰名词；其余旧规则交给模型判断。
            String intermittentAdverbs = "断断续续|时断时续|一阵一阵|一声一声|接连不断|连续不断|时有时无|忽高忽低|忽远忽近";
            addProfessionalRule("(" + intermittentAdverbs + ")([ 　]*)([的得])(?=[ 　]*响(?=[着了过得个起下不又还并且而但却才就仍，,。；;！？!?：:、…\\n]|$))", new String[][]{{null, "地", "状态副词修饰动作“响”，应用“地”"}});

            String mannerModifiers = "耐心|认真|仔细|专心|用心|细心|热心|诚心|虚心|诚恳|礼貌|友好|冷静|平静|从容|谨慎|小心|努力|积极|主动|自觉";
            String mannerActions = "等待|倾听|听取|解释|说明|回答|答复|劝说|安慰|指导|教导|检查|核对|阅读|观察|处理|解决|分析|研究|学习|工作|准备|完成|记录|整理|操作|练习|思考|考虑|交流|沟通";
            addProfessionalRule("(" + mannerModifiers + ")([ 　]*)(得)(?=[ 　]*(?:" + mannerActions + "))", new String[][]{{null, "地", "方式词修饰动作，应用“地”"}});
            addProfessionalRule("(请[ 　]*(?:" + mannerModifiers + "))([ 　]*)([的得])(?=[ 　]*(?:" + mannerActions + "))", new String[][]{{null, "地", "祈使句中的方式词修饰动作，应用“地”"}});
            addProfessionalRule("((?:他|她|它)[ 　]*准确)([ 　]*)([的得])(?=[ 　]*回答(?=[了着过，,。；;！？!?：:\\n]|$))", new String[][]{{null, "地", "“准确”修饰回答动作，应用“地”"}});

            String emotionActionModifiers = "高兴|开心|兴奋|激动";
            String emotionDynamicActions = "(?:跳(?:了|起|上|下)|笑(?:了|起|出|着)|喊(?:了|起|出)|说(?:道|着|了)|跑(?:了|起|出)|拍(?:起|着)|挥(?:了|起|着))";
            addProfessionalRule("(" + emotionActionModifiers + ")([ 　]*)(的)(?=[ 　]*" + emotionDynamicActions + ")", new String[][]{{null, "地", "情绪词修饰动作，应用“地”"}});

            // 保护规则只屏蔽模型对命中字的推理，不直接产生纠错记录。
            String resultVerbs = "(?:插|扎|勒|压|挤|卡|塞|夹|顶|硌|磨|裹|捆|缠|撑)";
            String resultSubjects = "(?:袜子|袜口|鞋袜|鞋面|衣服|衣料|布料|皮肤|脚底|脚背|脚腕|手腕|伤口|肌肉|绳子|带子|木头|木板|石头|管口|幼苗|瓶口|电线|棚膜|货物|地砖|他|她|它|人)";
            String resultSignals = "(?:直|都|也|已经|快|几乎|差点|深深|完全|紧紧|明显|生疼|发麻|发疼|发红|破了|陷入|陷进|陷得|起了|变得|喘不过气|动不了|鼓了|弯不过来|晃不动)";
            String textureQualities = "(?:柔软|细腻|坚硬|粗糙|轻薄|柔韧|顺滑|松散|绵密|光滑|冰凉|厚实|温润|干涩|黏腻|蓬松|紧实|均匀|致密|疏松|弹性|韧性|硬度|软硬|粗细)";
            String fixedModifiers = "(?:营地|质地|地拉那|地中海|地衣|地黄|地缘|地质|地震|彼得|圣彼得堡|的黎波里|的里雅斯特|的的喀喀湖|巴尔的摩|蒙得维的亚|塞得港|得荣县)";
            String fixedNounHeads = "(?:研究员|研究中心|资料|样本|气候|街道|港口|灯光|补给|照明|结构|触感|差异|特征|条目|叶片|覆盖率|编号|记录|论文|天气|货轮|冬夜|航线|数据|报告|土壤|价格|来源|用途)";
            addProtectedTargetPattern("[“‘\\\"]([的地得])(?=[”’\\\"])");
            // 这些旧白名单词只在引号内作为字面词条时仍有误判；用精确上下文保护，
            // 避免“心得”误伤“耐心得等待/小心得搬运”等真实错误。
            addProtectedTargetPattern("[“‘\\\"](?:厕所|懂|留|腰)(的)(?=[”’\\\"])");
            addProtectedTargetPattern("[“‘\\\"]心(得)(?=[”’\\\"])");
            addProtectedTargetPattern("[“‘\\\"](地)(?=处[”’\\\"])");
            // “开心得笑起来”等既可表示程度结果，也可能被模型当成状语；保留用户原字。
            addProtectedTargetPattern("(?:" + emotionActionModifiers + ")(得)(?=[ 　]*" + emotionDynamicActions + ")");
            addProtectedTargetPattern(resultVerbs + "(得)(?=[ 　]*" + resultSubjects + "[^，,。；;！？!?：:\\n]{0,12}" + resultSignals + ")");
            addProtectedTargetPattern("质地(的)(?=[ 　]*" + textureQualities + ")");
            addProtectedTargetPattern(fixedModifiers + "(的)(?=[ 　]*" + fixedNounHeads + ")");
            // 明确的合法状语/定语边界；只保护原字，不把相反写法强制纠正。
            addProtectedTargetPattern("快速(地)(?=[ 　]*增长)");
            addProtectedTargetPattern("反复(地)(?=[ 　]*讨论)");
            addProtectedTargetPattern("[“‘\\\"]规律(地)(?=[ 　]*变化[”’\\\"])");
            addProtectedTargetPattern("规律(的)(?=[ 　]*变化)");
            addProtectedTargetPattern("当地(的)(?=[ 　]*[\\u4E00-\\u9FFF])");
            addProtectedTargetPattern("当地(地)(?=[ 　]*(?:下|方|图|形|温|力|道|铁|质))");
            addProtectedTargetPattern("熟悉(地)(?=[ 　]*形)");
            addProtectedTargetPattern("地处[^，,。；;！？!?：:\\n]{1,8}(的)(?=[ 　]*(?:营地|村庄))");
            addProtectedTargetPattern("得主(的)(?=[ 　]*得票)");
            addProtectedTargetPattern("得当(的)(?=[ 　]*[\\u4E00-\\u9FFF])");
            // “设备挤的衣服都已打包”属于定语结构，新模型仍可能误改为“得”。
            addProtectedTargetPattern(resultVerbs + "(的)(?=[ 　]*" + resultSubjects + "[ 　]*(?:都|也)?[ 　]*(?:已经|已|早已)?[ 　]*(?:送走|入库|编号|消毒|打包|洗净|复检|拆下|收好|拍照|归档|更换))");

            addProfessionalRule("(" + fixedModifiers + ")([ 　]*)([地得])(?=[ 　]*" + fixedNounHeads + ")", new String[][]{{null, "的", "专名或固定术语修饰名词，应用“的”"}});
            addProfessionalRule("(质地)([ 　]*)([地得])(?=[ 　]*" + textureQualities + ")", new String[][]{{null, "的", "“质地”后的性质名词化结构应用“的”"}});

            String locations = "家|家里|家中|家外|卧室|卧房|厨房|客厅|卫生间|洗手间|厕所|茅房|阳台|书房|餐厅|饭厅|浴室|走廊|走道|院子|庭院|地|车|超市|商场|商店|菜市场|农贸市场|便利店|小卖部|饭店|酒店|旅馆|宾馆|招待所|餐馆|食堂|咖啡厅|咖啡馆|酒吧|网吧|电影院|戏院|剧院|银行|邮局|理发店|药店|诊所|门|商铺|店|医院|学校|幼儿园|小学|中学|初中|高中|大学|教室|图书馆|操场|宿舍|办公楼|公司|办公室|工厂|厂里|车间|会议室|派出所|警察局|公安局|消防队|法院|政府|监狱|看守所|基地|营地|阵地|车站|火车站|高铁站|地铁站|公交站|客运站|飞机场|机场|码头|港口|停车场|加油站|收费站|高速上|马路上|街上|路上|十字路口|桥上|桥下|隧道里|铁轨上|公园|动物园|植物园|游乐场|游乐园|广场|体育馆|体育场|游泳池|健身房|博物馆|展览馆|美术馆|海|沙滩|海岸|山上|山下|山顶|树林|森林|湖边|河边|江边|水里|田里|农田|地里|村|乡|农村|城里|城市|市区|郊区|景区|野外|这里|那里|哪里|这儿|那儿|哪儿|上面|下面|里面|外面|上边|下边|里边|外边|左边|右边|前面|后面|旁边|附近|远处|高处|低处|深处|内部|外部|中心|中间|顶上|底下|背后|面前";
            addRule("(再)( *)(" + locations + ")", new String[][]{{"在", null}});
            addRule("(在)( *)(次|度)(?![0-9一二两三四五六七八九十])", new String[][]{{"再", null}});
            addRule("(在)( *)(三)(?=考虑|叮嘱|强调|犹豫|确认|要求|请求|推辞|声明|警告|追问|申明)", new String[][]{{"再", null}});
            addRule("(截止)( *)(目前|今日|今天|现在|年底|月底)", new String[][]{{"截至", null}});
            addRule("(可是|但是)([^，。；！？\\n]{2,15}?， *)(可是|但是)", new String[][]{{null, ""}});
            addRule("(而且)([^，。；！？\\n]{2,15}?， *)(而且)", new String[][]{{null, ""}});
            addRule("(因此|所以)([^，。；！？\\n]{2,15}?， *)(因此|所以)", new String[][]{{null, ""}});

            String quantifiers = "个|只|条|头|匹|辆|部|台|口|尾|座|把|本|名|位|人|次|场|局|件|张";
            String[] chineseNumbers = {"", "一", "两", "三", "四", "五", "六", "七", "八", "九", "十"};
            for (int i = 1; i <= 10; i++) addRule("(?<![0-9a-zA-Z.])(" + i + ")( *)(" + quantifiers + ")", new String[][]{{chineseNumbers[i], null}});
            String[] weekdays = {"", "一", "二", "三", "四", "五", "六", "日"};
            for (int i = 1; i <= 7; i++) addRule("(星期|周|礼拜)( *)(" + i + ")(?![0-9])", new String[][]{{null, weekdays[i]}});
            String[] lunarDays = {"", "初一", "初二", "初三", "初四", "初五", "初六", "初七", "初八", "初九", "初十", "十一", "十二", "十三", "十四", "十五", "十六", "十七", "十八", "十九", "二十", "二十一", "二十二", "二十三", "二十四", "二十五", "二十六", "二十七", "二十八", "二十九", "三十"};
            for (int i = 1; i <= 30; i++) addRule("(正月|腊月|冬月)( *)(" + i + ")(?![0-9])", new String[][]{{null, lunarDays[i]}});
            String[] simple = {"", "一", "二", "三", "四", "五", "六", "七", "八", "九", "十"};
            for (int i = 1; i <= 10; i++) addRule("(初)( *)(" + i + ")(?![0-9])", new String[][]{{null, simple[i]}});
            for (int i = 1; i <= 9; i++) addRule("(?<![0-9])(" + i + ")()(点|点钟)(?![0-9分秒])", new String[][]{{simple[i], null}});
            for (int i = 1; i <= 9; i++) addRule("(?<![0-9])(" + i + ")()(楼|层)(?![0-9])", new String[][]{{simple[i], null}});
            for (int i = 1; i <= 9; i++) addRule("(?<![0-9])(" + i + ")()(班)(?![0-9])", new String[][]{{simple[i], null}});

            addRule("(达|多达|高达|达到)( *)(十几|几十|二三十|三四十|四五十|五六十|六七十|七八十|八九十|一二百|两三百|三四百|四五百|五六百|七八百|八九百|[0-9]+多|[0-9]+余|[0-9]+几|[一二两三四五六七八九十百千万亿]+多|[一二两三四五六七八九十百千万亿]+余|[一二两三四五六七八九十百千万亿]+几)", new String[][]{{"有", null}, {"约有", null}});
            addRule("(达|多达|高达|达到)( *)(大约|大概|将近|差不多|近|不下|不下于)", new String[][]{{"有", null}, {"约有", null}});
            addRule("(?:(?<=数万|几万|上万)|(?<=数十万|数百万))(名)([^，。；！？、\\n]{0,8}?)(人群)", new String[][]{{"人的", ""}});
            addRule("(减少|降低|缩短|下降|减小|缩小)([^，。；！？、\\n]{0,15}?[0-9十百千万亿两半])(倍)", new String[][]{{null, "倍", "下降/减小等不能用倍数表示"}});
            addRule("(随便|随意)( *)(苟同)", new String[][]{{"", null}});
            addRule("(非常|十分|极其|特别|尤其)( *)(酷爱|惨重|硕大|嗜好|痛恨|严禁)", new String[][]{{"", null}});
            addRule("(发自内心的?|从内心里的?|打心眼里的?)( *)(由衷)", new String[][]{{"", null}});
            addRule("(?<!一张|打出|胡了)(?<![李王张赵刘陈杨黄])(?<![0-9一二三四五六七八九十百千万亿第])(二)()(万|千|亿)(?!五|两|响|五千里长征)", new String[][]{{"两", null}});
            addRule("(?<=[0-9一二三四五六七八九十两零〇]{1,4}月[0-9一二三四五六七八九十两零〇]{1,4}[日号]?)(前)()(去|往|来|报到|汇报|报名|登记|申请|找)", new String[][]{{"之前", null}});
            addRule("(几个)([^的，。；！？、\\n]{0,8}?)(校长|老师|领导|教授|医生|警察|党员|干部)", new String[][]{{"几位", null}});
            addRule("(出于)([^，。；！？、\\n]{1,15}?)(的决定)", new String[][]{{"", "决定"}});
            addRule("(具有)([^的，。！？；…\\n]{0,20}?(?:消食|化积|润肠|通便|清热|解毒|活血|化瘀|消肿|止痛|健脾|养胃|安神|补血|益气|滋阴|补肾|祛风|除湿|润肺|化痰|止咳|平喘|抗氧|抗菌|抑菌|消炎)[^的，。！？；…\\n]{0,40}?)(?<!功效|作用|效果|功能|能力|疗效|特性|价值|意义)()(?=[，。！？；…\\n]|$)", new String[][]{{null, "的功效", "成分残缺，补充宾语"}});
            quantRules.put('牛', new QuantifierRule("头", "头")); quantRules.put('马', new QuantifierRule("匹", "匹")); quantRules.put('狗', new QuantifierRule("只", "只条")); quantRules.put('猫', new QuantifierRule("只", "只")); quantRules.put('猪', new QuantifierRule("头", "头口")); quantRules.put('羊', new QuantifierRule("只", "只")); quantRules.put('鸡', new QuantifierRule("只", "只")); quantRules.put('鸭', new QuantifierRule("只", "只")); quantRules.put('鹅', new QuantifierRule("只", "只")); quantRules.put('鸟', new QuantifierRule("只", "只")); quantRules.put('鱼', new QuantifierRule("条", "条尾")); quantRules.put('门', new QuantifierRule("扇", "扇")); quantRules.put('车', new QuantifierRule("辆", "辆部台"));
        } catch (Throwable error) { error.printStackTrace(); }
    }

    public static final String NUMS = "一二两三四五六七八九十百千万这那几某";
    public static final String KNOWN_QUANTS = "个只条头匹辆部台口尾座把本名位";
    public static final String[] IGNORE_WORDS = {"舒的", "怎的", "能的", "您的", "当地", "营地", "质地", "地拉那", "地中海", "地衣", "地黄", "地钱", "地缘", "地漏", "地处", "地坛", "地安门", "塞得港", "得荣县", "得法", "得当", "得体", "得主", "得票", "得益", "得克萨斯", "拍立得", "彼得", "殖民地", "的士", "的确", "的黎波里", "的里雅斯特", "的的喀喀湖", "蒙得维的亚", "目的地", "似的", "打的", "出的", "出得", "有的放矢", "无的放矢", "众矢之的", "佛得角", "得梅因", "海得拉巴", "亚的斯亚贝巴", "斯堪的纳维亚", "安的列斯", "波罗的海", "地峡", "地窝堡", "地铁", "的卢", "大地", "天地", "地王", "地平线", "地素时尚", "地质", "地震", "地理", "地球", "地下", "地表", "地基", "地籍", "地形", "地势", "地标", "地名", "地幔", "地核", "地磁", "地貌", "地热", "地温", "地塞米松", "地高辛", "地西泮", "地氯雷他定", "地诺孕素", "地尔硫卓", "地奥司明", "地芬尼多", "地拉罗司", "地榆升白片", "地骨皮", "地锦", "地柏", "地生兰", "晓得", "舍得", "值得", "赢得", "博得", "免得", "显得", "使得", "变得", "难得", "应得", "既得", "得病", "得力", "得手", "得救", "得名", "得志", "得势", "得逞", "得空", "得宠", "得寸进尺", "得天独厚", "得意扬扬", "不得不", "乌得勒支", "得胜门", "得月楼", "得耳布尔", "地狱", "的场"};
    public static final String[] WHITE_LIST = {"图书管理", "图书管控", "图书管制"};

    public static boolean isSafeCharAfterNoun(char c) {
        if (c == '\0' || c < '\u4E00' || c > '\u9FFF') return true;
        return "的了着过是在被把让给对和与同或就也都还很太真会能可要想走跑跳吃喝咬叫哭笑我看你他她它们这那\n".indexOf(c) >= 0;
    }

    public static final class TypoMatch {
        public final String source, correction;
        public final boolean custom;
        TypoMatch(String source, String correction, boolean custom) { this.source = source; this.correction = correction; this.custom = custom; }
    }

    // Immutable packed trie: publish once, retain one snapshot throughout a correction job.
    public static final class TypoIndex {
        final int[] roots, first, edges, terminal;
        final char[] labels;
        final String[] sources, corrections;
        final boolean[] customs;
        final Map<String, String[]> exclusions;
        final int maxLength;
        private TypoIndex(int[] roots, int[] first, int[] edges, int[] terminal, char[] labels,
                          String[] sources, String[] corrections, boolean[] customs, Map<String, String[]> exclusions, int maxLength) {
            this.roots = roots; this.first = first; this.edges = edges; this.terminal = terminal; this.labels = labels;
            this.sources = sources; this.corrections = corrections; this.customs = customs; this.exclusions = exclusions; this.maxLength = maxLength;
        }
        static TypoIndex build(Map<String, String> words, Set<String> custom, Map<String, String[]> exceptions) {
            String[] sources = words.keySet().toArray(new String[0]); Arrays.sort(sources);
            int capacity = 1, maxLength = 0;
            for (String word : sources) { capacity += word.length(); maxLength = Math.max(maxLength, word.length()); }
            int[] parents = new int[capacity], counts = new int[capacity], terminals = new int[capacity], path = new int[maxLength + 1];
            char[] chars = new char[capacity]; String previous = ""; int size = 1;
            String[] corrections = new String[sources.length]; boolean[] customs = new boolean[sources.length];
            for (int entry = 0; entry < sources.length; entry++) {
                String word = sources[entry]; int common = 0;
                while (common < previous.length() && common < word.length() && previous.charAt(common) == word.charAt(common)) common++;
                for (int i = common; i < word.length(); i++) {
                    int node = size++, parent = path[i]; parents[node] = parent; counts[parent]++; chars[node] = word.charAt(i); path[i + 1] = node;
                }
                terminals[path[word.length()]] = entry + 1;
                corrections[entry] = words.get(word); customs[entry] = custom.contains(word); previous = word;
            }
            int[] first = new int[size + 1], edges = new int[size - 1], roots = new int[65536];
            for (int i = 0; i < size; i++) first[i + 1] = first[i] + counts[i];
            int[] next = first.clone();
            for (int node = 1; node < size; node++) { edges[next[parents[node]]++] = node; if (parents[node] == 0) roots[chars[node]] = node; }
            return new TypoIndex(roots, first, edges, Arrays.copyOf(terminals, size), Arrays.copyOf(chars, size),
                    sources, corrections, customs, Collections.unmodifiableMap(new HashMap<>(exceptions)), maxLength);
        }
        int child(int node, char c) {
            if (node == 0) return roots[c];
            int lo = first[node], hi = first[node + 1] - 1;
            while (lo <= hi) { int mid = (lo + hi) >>> 1, child = edges[mid]; char key = labels[child];
                if (key < c) lo = mid + 1; else if (key > c) hi = mid - 1; else return child; }
            return 0;
        }
        boolean excluded(String text, int index, int entry) {
            String[] words = exclusions.get(sources[entry]);
            if (words == null) return false;
            int end = index + sources[entry].length();
            for (String word : words) {
                int found = text.indexOf(word, Math.max(0, end - word.length()));
                if (found >= 0 && found <= index && found + word.length() >= end) return true;
            }
            return false;
        }
        public TypoMatch find(String text, int index) {
            if (index < 0 || index >= text.length()) return null;
            return findLongest(text, index, index, 0);
        }
        private TypoMatch findLongest(String text, int start, int cursor, int node) {
            if (cursor < text.length()) {
                int next = child(node, text.charAt(cursor));
                if (next != 0) { TypoMatch longer = findLongest(text, start, cursor + 1, next); if (longer != null) return longer; }
            }
            int entry = terminal[node] - 1;
            if (entry < 0 || isFalsePositiveTypo(text, start, sources[entry])) return null;
            if (excluded(text, start, entry)) return new TypoMatch(sources[entry], sources[entry], customs[entry]);
            if (!sources[entry].equals(corrections[entry]) && conflicts(text, start, sources[entry], corrections[entry])) return null;
            return new TypoMatch(sources[entry], corrections[entry], customs[entry]);
        }
        boolean conflicts(String sentence, int index, String source, String correction) {
            if (source.equals(correction) || sources.length == 0) return false;
            String simulated = sentence.substring(0, index) + correction + sentence.substring(index + source.length());
            int end = index + correction.length();
            for (int cursor = Math.max(0, index - maxLength + 1); cursor < end; cursor++) {
                int node = 0;
                for (int pos = cursor; pos < simulated.length(); pos++) {
                    node = child(node, simulated.charAt(pos)); if (node == 0) break;
                    int entry = terminal[node] - 1;
                    if (entry >= 0 && ((cursor < index && pos + 1 > index) || pos + 1 > end)
                            && !sources[entry].equals(corrections[entry]) && !excluded(simulated, cursor, entry)) return true;
                }
            }
            return false;
        }
    }
    public static TypoMatch findTypoMatch(String sentence, int index) { return typoIndex.find(sentence, index); }

    public static boolean isFalsePositiveTypo(String sentence, int index, String source) {
        for (String white : WHITE_LIST) {
            int searchStart = Math.max(0, index - white.length()), searchEnd = Math.min(sentence.length(), index + source.length() + white.length());
            int found = sentence.indexOf(white, searchStart);
            while (found >= 0 && found + white.length() <= searchEnd) {
                int start = found, end = start + white.length();
                if (start < index + source.length() && end > index) return true;
                found = sentence.indexOf(white, found + 1);
            }
        }
        if ("作事".equals(source) && index > 0 && sentence.charAt(index - 1) == '下') return true;
        if ("导至".equals(source) && index > 0 && sentence.charAt(index - 1) == '传') return true;
        if (source.charAt(0) == '做' || source.charAt(0) == '作') {
            if (index > 0 && "创去要在该想会能可来把给多没不曾刚才将正就爱肯敢配帮替让叫使令".indexOf(sentence.charAt(index - 1)) >= 0) return true;
            if (index + source.length() < sentence.length() && "扇筝联山发牙眼肢手脚衣裤帽鞋饭菜汤了".indexOf(sentence.charAt(index + source.length())) >= 0) return true;
        }
        return false;
    }

    public static class TextBlock {
        String original, current, modelCorrected, exp = "";
        boolean isMutable, userModified;
        float conf;
        int type;
        public TextBlock(String original, String current, boolean mutable, float confidence, int type) {
            this.original = original; this.current = original != null && original.equals(current) ? original : current; this.modelCorrected = this.current; this.isMutable = mutable; this.conf = confidence; this.type = type;
        }
    }
    public static class TargetSpan { String expected; TargetSpan(String expected) { this.expected = expected; } }
    public static class ListMarkerSpan {}
    public static class ClauseLink { ListMarkerSpan listMarkerSpan; List<TargetSpan> targetSpans = new ArrayList<>(); int targetOffset = -1; boolean isDead; }
    public abstract static class JumpSpan extends ClickableSpan { public int getTargetOffset(Spanned text) { return -1; } }
    public abstract static class EditSpan extends ClickableSpan {}
    public static class IgnoredInCopySpan extends android.text.style.CharacterStyle { @Override public void updateDrawState(TextPaint paint) {} }

    public static class MyLinkMovementMethod extends LinkMovementMethod {
        private static final MyLinkMovementMethod INSTANCE = new MyLinkMovementMethod();
        public static MyLinkMovementMethod getInstance() { return INSTANCE; }
        @Override public boolean onTouchEvent(TextView widget, Spannable buffer, MotionEvent event) {
            int action = event.getActionMasked();
            if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_DOWN) {
                int x = (int) event.getX() - widget.getTotalPaddingLeft() + widget.getScrollX();
                int y = (int) event.getY() - widget.getTotalPaddingTop() + widget.getScrollY();
                Layout layout = widget.getLayout();
                if (layout != null) {
                    int line = layout.getLineForVertical(y), offset = layout.getOffsetForHorizontal(line, x);
                    ClickableSpan[] links = buffer.getSpans(offset, offset, ClickableSpan.class);
                    if (links.length > 0) { if (action == MotionEvent.ACTION_UP) links[0].onClick(widget); return true; }
                }
            }
            return super.onTouchEvent(widget, buffer, event);
        }
    }

    public static class WavyUnderlineSpan extends android.text.style.ReplacementSpan {
        public final int color;
        private final android.graphics.Paint wavePaint = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        private final android.graphics.Path wavePath = new android.graphics.Path();
        private float cachedWidth = -1f, textWidth = -1f;
        WavyUnderlineSpan(int color) { this.color = color; wavePaint.setColor(color); wavePaint.setStyle(android.graphics.Paint.Style.STROKE); wavePaint.setStrokeWidth(3.5f); }
        @Override public int getSize(android.graphics.Paint paint, CharSequence text, int start, int end, android.graphics.Paint.FontMetricsInt fm) { textWidth = paint.measureText(text, start, end); return (int) textWidth; }
        @Override public void draw(android.graphics.Canvas canvas, CharSequence text, int start, int end, float x, int top, int y, int bottom, android.graphics.Paint paint) {
            canvas.drawText(text, start, end, x, y, paint);
            float width = textWidth > 0 ? textWidth : paint.measureText(text, start, end);
            if (cachedWidth != width) {
                cachedWidth = width; wavePath.reset(); float waveLength = 12f, amplitude = 2.5f, currentY = paint.getFontMetrics().descent + 3; wavePath.moveTo(0, currentY);
                for (float i = 0; i < width; i += waveLength) {
                    float next = Math.min(i + waveLength, width); wavePath.quadTo(i + waveLength / 4, currentY - amplitude, i + waveLength / 2, currentY); wavePath.quadTo(i + waveLength * 3 / 4, currentY + amplitude, next, currentY);
                }
            }
            int save = canvas.save(); canvas.translate(x, y); canvas.drawPath(wavePath, wavePaint); canvas.restoreToCount(save);
        }
    }

    public static class ColoredStrikethroughSpan extends android.text.style.ReplacementSpan {
        public final int textColor, lineColor; private float cachedWidth = -1f;
        ColoredStrikethroughSpan(int textColor, int lineColor) { this.textColor = textColor; this.lineColor = lineColor; }
        @Override public int getSize(android.graphics.Paint paint, CharSequence text, int start, int end, android.graphics.Paint.FontMetricsInt fm) { cachedWidth = paint.measureText(text, start, end); return (int) cachedWidth; }
        @Override public void draw(android.graphics.Canvas canvas, CharSequence text, int start, int end, float x, int top, int y, int bottom, android.graphics.Paint paint) {
            int oldColor = paint.getColor(); float oldStroke = paint.getStrokeWidth(); android.graphics.Paint.Style oldStyle = paint.getStyle();
            paint.setColor(textColor); canvas.drawText(text, start, end, x, y, paint);
            paint.setColor(lineColor); paint.setStyle(android.graphics.Paint.Style.STROKE); paint.setStrokeWidth(paint.getTextSize() / 14f);
            float width = cachedWidth > 0 ? cachedWidth : paint.measureText(text, start, end); canvas.drawLine(x, y - paint.getTextSize() * 0.3f, x + width, y - paint.getTextSize() * 0.3f, paint);
            paint.setColor(oldColor); paint.setStrokeWidth(oldStroke); paint.setStyle(oldStyle);
        }
    }

    public static class EditorState {
        SpannableStringBuilder text; int selectionStart;
        EditorState(SpannableStringBuilder text, int selectionStart) { this.text = text; this.selectionStart = selectionStart; }
    }

    public static List<TextBlock> mergeNormalBlocks(List<TextBlock> blocks) {
        List<TextBlock> result = new ArrayList<>(); StringBuilder original = new StringBuilder(), current = new StringBuilder();
        for (TextBlock block : blocks) {
            if (block.type == 0 && !block.isMutable) { original.append(block.original); current.append(block.current); }
            else {
                if (original.length() > 0) { result.add(new TextBlock(original.toString(), current.toString(), false, 0f, 0)); original.setLength(0); current.setLength(0); }
                result.add(block);
            }
        }
        if (original.length() > 0) result.add(new TextBlock(original.toString(), current.toString(), false, 0f, 0));
        return result;
    }

    public static String escapeHtmlQuick(String text) {
        if (text == null) return "";
        StringBuilder result = new StringBuilder(text.length() + 16);
        for (int i = 0; i < text.length(); i++) { char c = text.charAt(i); if (c == '&') result.append("&amp;"); else if (c == '<') result.append("&lt;"); else if (c == '>') result.append("&gt;"); else result.append(c); }
        return result.toString();
    }

    private static void appendLiveHtmlText(StringBuilder result, String text) {
        for (int i = 0; i < text.length(); i++) { char c = text.charAt(i); if (c == '&') result.append("&amp;"); else if (c == '<') result.append("&lt;"); else if (c == '>') result.append("&gt;"); else if (c == '\n') result.append("<br>"); else result.append(c); }
    }

    public static String getCleanTextStatic() {
        StringBuilder result = new StringBuilder();
        for (List<TextBlock> sentence : allSentencesBlocks) for (TextBlock block : sentence) result.append(block.current);
        return result.toString();
    }

    public static String extractCleanTextFromSpanned(Spanned text) {
        if (text == null) return "";
        IgnoredInCopySpan[] spans = text.getSpans(0, text.length(), IgnoredInCopySpan.class);
        if (spans.length == 0) return text.toString();
        List<int[]> ranges = new ArrayList<>(spans.length);
        for (IgnoredInCopySpan span : spans) {
            int start = text.getSpanStart(span), end = text.getSpanEnd(span);
            if (start >= 0 && end > start) ranges.add(new int[]{start, end});
        }
        ranges.sort(Comparator.comparingInt(a -> a[0]));
        StringBuilder result = new StringBuilder(text.length()); int cursor = 0;
        for (int[] range : ranges) {
            if (range[0] > cursor) result.append(text, cursor, range[0]); cursor = Math.max(cursor, range[1]);
        }
        if (cursor < text.length()) result.append(text, cursor, text.length());
        return result.toString();
    }

    public static String serializeBlocks(List<List<TextBlock>> blocks) {
        JSONArray outer = new JSONArray();
        try {
            for (List<TextBlock> sentence : blocks) {
                JSONArray inner = new JSONArray();
                for (TextBlock block : sentence) {
                    JSONObject object = new JSONObject(); object.put("o", block.original); object.put("c", block.current); object.put("mc", block.modelCorrected); object.put("m", block.isMutable); object.put("f", block.conf); object.put("t", block.type); object.put("u", block.userModified); if (block.exp != null && !block.exp.isEmpty()) object.put("exp", block.exp); inner.put(object);
                }
                outer.put(inner);
            }
        } catch (Exception ignored) {}
        return outer.toString();
    }

    public static List<List<TextBlock>> deserializeBlocks(String json) {
        List<List<TextBlock>> result = new ArrayList<>();
        try {
            JSONArray outer = new JSONArray(json);
            for (int i = 0; i < outer.length(); i++) {
                JSONArray inner = outer.getJSONArray(i); List<TextBlock> sentence = new ArrayList<>();
                for (int j = 0; j < inner.length(); j++) {
                    JSONObject object = inner.getJSONObject(j); TextBlock block = new TextBlock(object.getString("o"), object.getString("c"), object.getBoolean("m"), (float) object.getDouble("f"), object.getInt("t")); block.modelCorrected = object.getString("mc"); block.userModified = object.getBoolean("u"); block.exp = object.optString("exp", ""); sentence.add(block);
                }
                result.add(sentence);
            }
        } catch (Exception ignored) {}
        return result;
    }

    public static String serializeSpannable(Spannable text) {
        if (text == null) return "";
        try {
            JSONObject root = new JSONObject(); root.put("text", text.toString()); JSONArray array = new JSONArray();
            for (Object span : text.getSpans(0, text.length(), Object.class)) {
                JSONObject object = new JSONObject(); object.put("start", text.getSpanStart(span)); object.put("end", text.getSpanEnd(span)); object.put("flags", text.getSpanFlags(span));
                if (span instanceof ForegroundColorSpan) { object.put("type", "ForegroundColorSpan"); object.put("color", ((ForegroundColorSpan) span).getForegroundColor()); }
                else if (span instanceof android.text.style.StyleSpan) { object.put("type", "StyleSpan"); object.put("style", ((android.text.style.StyleSpan) span).getStyle()); }
                else if (span instanceof WavyUnderlineSpan) { object.put("type", "WavyUnderlineSpan"); object.put("color", ((WavyUnderlineSpan) span).color); }
                else if (span instanceof ColoredStrikethroughSpan) { object.put("type", "ColoredStrikethroughSpan"); object.put("textColor", ((ColoredStrikethroughSpan) span).textColor); object.put("lineColor", ((ColoredStrikethroughSpan) span).lineColor); }
                else if (span instanceof StrikethroughSpan) object.put("type", "StrikethroughSpan");
                else if (span instanceof android.text.style.RelativeSizeSpan) { object.put("type", "RelativeSizeSpan"); object.put("size", ((android.text.style.RelativeSizeSpan) span).getSizeChange()); }
                else if (span instanceof JumpSpan) { int target = ((JumpSpan) span).getTargetOffset(text); if (target < 0) continue; object.put("type", "JumpSpan"); object.put("target", target); }
                else if (span instanceof IgnoredInCopySpan) object.put("type", "IgnoredInCopySpan"); else continue;
                array.put(object);
            }
            root.put("spans", array); return root.toString();
        } catch (Exception ignored) { return ""; }
    }

    public static SpannableStringBuilder deserializeSpannable(String json) {
        if (json == null || json.isEmpty()) return null;
        try {
            JSONObject root = new JSONObject(json); String value = root.getString("text"); SpannableStringBuilder result = new SpannableStringBuilder(value); JSONArray array = root.getJSONArray("spans");
            for (int i = 0; i < array.length(); i++) {
                JSONObject object = array.getJSONObject(i); int start = object.getInt("start"), end = object.getInt("end"), flags = object.getInt("flags"); String type = object.getString("type"); Object span = null;
                if ("ForegroundColorSpan".equals(type)) span = new ForegroundColorSpan(object.getInt("color"));
                else if ("StyleSpan".equals(type)) span = new android.text.style.StyleSpan(object.getInt("style"));
                else if ("WavyUnderlineSpan".equals(type)) span = new WavyUnderlineSpan(object.getInt("color"));
                else if ("ColoredStrikethroughSpan".equals(type)) span = new ColoredStrikethroughSpan(object.getInt("textColor"), object.getInt("lineColor"));
                else if ("StrikethroughSpan".equals(type)) span = new StrikethroughSpan();
                else if ("RelativeSizeSpan".equals(type)) span = new android.text.style.RelativeSizeSpan((float) object.getDouble("size"));
                else if ("IgnoredInCopySpan".equals(type)) span = new IgnoredInCopySpan();
                else if ("JumpSpan".equals(type)) {
                    int target = object.getInt("target");
                    span = new JumpSpan() {
                        @Override public int getTargetOffset(Spanned text) { return target; }
                        @Override public void onClick(View view) { jumpAndFlash((TextView) view, target, null); }
                        @Override public void updateDrawState(TextPaint paint) { paint.setColor(0xFF2196F3); paint.setUnderlineText(true); paint.setFakeBoldText(true); }
                    };
                }
                if (span != null && start >= 0 && start <= end && end <= value.length()) result.setSpan(span, start, end, flags);
            }
            return result;
        } catch (Exception ignored) { return null; }
    }

    private static void jumpAndFlash(TextView textView, int offset, ScrollView preferred) {
        try {
            Spannable text = (Spannable) textView.getText(); if (offset < 0 || offset > text.length()) return; Layout layout = textView.getLayout(); if (layout == null) return;
            int line = layout.getLineForOffset(offset), lineStart = layout.getLineStart(line), lineEnd = layout.getLineEnd(line), y = layout.getLineTop(line);
            ScrollView scroll = preferred;
            if (scroll == null && textView.getContext() instanceof android.app.Activity) scroll = ((android.app.Activity) textView.getContext()).findViewById(R.id.scrollView);
            if (scroll != null) scroll.scrollTo(0, Math.max(0, y - scroll.getHeight() / 3));
            BackgroundColorSpan flash = new BackgroundColorSpan(0x609E9E9E); Handler handler = AppExecutors.MAIN;
            Runnable add = () -> { if (lineStart >= 0 && lineEnd <= text.length()) { text.setSpan(flash, lineStart, lineEnd, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE); textView.invalidate(); } };
            Runnable remove = () -> { text.removeSpan(flash); textView.invalidate(); };
            add.run(); handler.postDelayed(remove, 500); handler.postDelayed(add, 800); handler.postDelayed(remove, 1300);
        } catch (Exception ignored) {}
    }

    public static void ensureTypoMapLoaded(Context context) {
        if (typoMapLoaded) return;
        synchronized (MainActivity.class) {
            if (!typoMapLoaded) loadTypoMap(context);
        }
    }

    public static synchronized void loadTypoMap(Context context) {
        Map<String, String> words = new HashMap<>(); Set<String> customs = new HashSet<>();
        Map<String, String[]> exclusions = new HashMap<>();
        try (BufferedReader reader = new BufferedReader(new java.io.StringReader(SecureAsset.readUtf8(context, "sys_typo.dat")))) {
            String line;
            while ((line = reader.readLine()) != null) parseTypoLine(line, words, exclusions);
        } catch (Exception ignored) {}
        for (String word : new String[]{"舒的", "怎的", "能的", "您的"}) { words.put(word, word); exclusions.remove(word); }
        try {
            JSONObject custom = new JSONObject(context.getSharedPreferences("DedediConfig", MODE_PRIVATE).getString("custom_typos", "{}")); Iterator<String> keys = custom.keys();
            while (keys.hasNext()) { String source = keys.next(); if (source.isEmpty()) continue;
                words.put(source, custom.getString(source)); customs.add(source); exclusions.remove(source); }
        } catch (Exception ignored) {}
        typoIndex = TypoIndex.build(words, customs, exclusions);
        typoMapLoaded = true;
    }

    static void parseTypoLine(String line, Map<String, String> words, Map<String, String[]> exclusions) {
        line = line.trim(); if (line.startsWith("\uFEFF")) line = line.substring(1).trim();
        if (line.isEmpty()) return;
        String[] fields = TYPO_FIELDS.split(line, 3);
        if (fields.length < 2 || fields[0].equals(fields[1])) return;
        words.put(fields[0], fields[1]); exclusions.remove(fields[0]);
        if (fields.length == 3 && fields[2].startsWith("n=")) {
            String tail = fields[2].substring(2).trim();
            if (!tail.isEmpty()) exclusions.put(fields[0], TYPO_FIELDS.split(tail));
        }
    }
    private static void reloadTypoMapAsync(Context context) {
        Context app = context.getApplicationContext(); AppExecutors.INFERENCE.execute(() -> loadTypoMap(app));
    }

    private static volatile TextRecognizer textRecognizer;
    private static final Object OCR_LOCK = new Object();
    private static final Pattern PUNCT_PATTERN_1 = Pattern.compile("(?<=[\\u4e00-\\u9fa5])\\.{2,6}(?=[\\u4e00-\\u9fa5]?)");
    private static final Pattern PUNCT_PATTERN_2 = Pattern.compile("(?<=[\\u4e00-\\u9fa5]?)\\.{2,6}(?=[\\u4e00-\\u9fa5])");
    private static final Pattern WORD_TEXT_PATTERN = Pattern.compile("<w:t[^>]*>(.*?)</w:t>", Pattern.DOTALL);
    private static final Pattern PPT_TEXT_PATTERN = Pattern.compile("<a:t[^>]*>(.*?)</a:t>", Pattern.DOTALL);

    private static volatile String lastExtractError = "";
    private static final long OCR_TIMEOUT_SECONDS = 120L;
    private static final long MAX_OCR_PIXELS = 20_000_000L;
    private static final int OCR_SINGLE_PASS_MAX_HEIGHT = 4200;
    private static final long OCR_SINGLE_PASS_MAX_PIXELS = 12_000_000L;
    private static final int OCR_TARGET_CORE_HEIGHT = 2800;
    private static final int OCR_MIN_CORE_HEIGHT = 1200;
    private static final int OCR_CHUNK_OVERLAP = 320;
    private static final int OCR_SPLIT_SEARCH_RADIUS = 420;
    private static final long MAX_PDF_RENDER_PIXELS = 12_000_000L;

    private static final class OcrLineResult {
        final String text;
        final int left;
        final int top;
        final int right;
        final int bottom;

        OcrLineResult(String text, int left, int top, int right, int bottom) {
            this.text = text;
            this.left = left;
            this.top = top;
            this.right = right;
            this.bottom = bottom;
        }

        int centerY() {
            return top + Math.max(0, bottom - top) / 2;
        }
    }

    private static TextRecognizer getTextRecognizer() {
        TextRecognizer local = textRecognizer;
        if (local == null) synchronized (OCR_LOCK) {
            local = textRecognizer;
            if (local == null) textRecognizer = local = TextRecognition.getClient(new ChineseTextRecognizerOptions.Builder().build());
        }
        return local;
    }

    public static String getLastExtractError() { return lastExtractError == null ? "" : lastExtractError; }

    private static String describeExtractError(Throwable throwable) {
        Throwable root = throwable;
        while (root.getCause() != null && root.getCause() != root) root = root.getCause();
        String message = root.getMessage();
        String name = root.getClass().getSimpleName();
        if (message == null || message.trim().isEmpty()) return name;
        message = message.replace('\n', ' ').replace('\r', ' ').trim();
        return name + "：" + (message.length() > 120 ? message.substring(0, 120) + "…" : message);
    }

    private static String recognizeInputImage(InputImage image) throws Exception {
        synchronized (OCR_LOCK) {
            try {
                Text result = Tasks.await(getTextRecognizer().process(image), OCR_TIMEOUT_SECONDS, java.util.concurrent.TimeUnit.SECONDS);
                return result == null ? "" : result.getText();
            } catch (java.util.concurrent.ExecutionException exception) {
                Throwable cause = exception.getCause() == null ? exception : exception.getCause();
                throw new Exception("ML Kit识别失败：" + describeExtractError(cause), cause);
            } catch (java.util.concurrent.TimeoutException exception) {
                throw new Exception("OCR识别超时，请尝试较小的图片或PDF", exception);
            }
        }
    }

    private static List<OcrLineResult> recognizeInputImageLines(InputImage image, int globalOffsetY, int fallbackCenterY) throws Exception {
        synchronized (OCR_LOCK) {
            try {
                Text result = Tasks.await(getTextRecognizer().process(image), OCR_TIMEOUT_SECONDS, java.util.concurrent.TimeUnit.SECONDS);
                List<OcrLineResult> lines = new ArrayList<>();
                if (result == null) return lines;

                for (Text.TextBlock block : result.getTextBlocks()) {
                    android.graphics.Rect blockBox = block.getBoundingBox();
                    for (Text.Line line : block.getLines()) {
                        String value = line.getText();
                        if (value == null || value.trim().isEmpty()) continue;
                        android.graphics.Rect box = line.getBoundingBox();
                        if (box == null) box = blockBox;
                        if (box == null) {
                            lines.add(new OcrLineResult(value, 0, fallbackCenterY, 0, fallbackCenterY + 1));
                        } else {
                            lines.add(new OcrLineResult(
                                    value,
                                    box.left,
                                    globalOffsetY + box.top,
                                    box.right,
                                    globalOffsetY + box.bottom
                            ));
                        }
                    }
                }
                return lines;
            } catch (java.util.concurrent.ExecutionException exception) {
                Throwable cause = exception.getCause() == null ? exception : exception.getCause();
                throw new Exception("ML Kit识别失败：" + describeExtractError(cause), cause);
            } catch (java.util.concurrent.TimeoutException exception) {
                throw new Exception("OCR识别超时，请尝试较小的图片或PDF", exception);
            }
        }
    }

    private static Bitmap decodeBitmapFromUri(Context context, android.net.Uri uri) throws Exception {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) {
            android.graphics.ImageDecoder.Source source = android.graphics.ImageDecoder.createSource(context.getContentResolver(), uri);
            Bitmap bitmap = android.graphics.ImageDecoder.decodeBitmap(source, (decoder, info, src) -> {
                decoder.setAllocator(android.graphics.ImageDecoder.ALLOCATOR_SOFTWARE);
                int width = info.getSize().getWidth(), height = info.getSize().getHeight();
                long pixels = (long) width * height;
                if (pixels > MAX_OCR_PIXELS) {
                    double scale = Math.sqrt((double) MAX_OCR_PIXELS / pixels);
                    decoder.setTargetSize(Math.max(1, (int) Math.round(width * scale)), Math.max(1, (int) Math.round(height * scale)));
                }
            });
            if (bitmap == null) throw new IOException("图片解码结果为空");
            return bitmap;
        }

        android.graphics.BitmapFactory.Options bounds = new android.graphics.BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        try (InputStream input = context.getContentResolver().openInputStream(uri)) {
            if (input == null) throw new IOException("无法打开图片文件");
            android.graphics.BitmapFactory.decodeStream(input, null, bounds);
        }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw new IOException("无法读取图片尺寸");
        int sample = 1;
        while ((long) Math.max(1, bounds.outWidth / sample) * Math.max(1, bounds.outHeight / sample) > MAX_OCR_PIXELS) sample <<= 1;
        android.graphics.BitmapFactory.Options options = new android.graphics.BitmapFactory.Options();
        options.inSampleSize = sample;
        options.inPreferredConfig = Bitmap.Config.ARGB_8888;
        try (InputStream input = context.getContentResolver().openInputStream(uri)) {
            if (input == null) throw new IOException("无法重新打开图片文件");
            Bitmap bitmap = android.graphics.BitmapFactory.decodeStream(input, null, options);
            if (bitmap == null) throw new IOException("图片格式不受支持或文件已损坏");
            return bitmap;
        }
    }

    public static void extractTextFromUriAsync(Context context, android.net.Uri uri, TextExtractCallback callback) {
        AppExecutors.MAIN.post(() -> { if (callback != null) callback.onStart(); });
        AppExecutors.IO.execute(() -> {
            String result = extractTextFromUriSync(context, uri, callback);
            AppExecutors.MAIN.post(() -> { if (callback != null) callback.onExtracted(result); });
        });
    }

    public static String extractTextFromUriSync(Context context, android.net.Uri uri, TextExtractCallback callback) {
        Bitmap bitmap = null;
        lastExtractError = "";
        try {
            if (uri == null) throw new IOException("文件地址为空");
            String mime = context.getContentResolver().getType(uri), name = getFileName(context, uri); if (name != null) name = name.toLowerCase(Locale.ROOT);
            if ((name != null && (name.endsWith(".jpg") || name.endsWith(".jpeg") || name.endsWith(".png") || name.endsWith(".bmp") || name.endsWith(".webp") || name.endsWith(".heic") || name.endsWith(".heif"))) || (mime != null && mime.startsWith("image/"))) {
                bitmap = decodeBitmapFromUri(context, uri);
                String result = performOcrOnBitmap(bitmap, context, callback);
                if (result == null || result.trim().isEmpty()) lastExtractError = "图片读取成功，但没有识别到文字";
                return result == null ? "" : result;
            }
            if ((name != null && name.endsWith(".pdf")) || "application/pdf".equals(mime)) {
                String result = performOcrOnPdf(uri, context, callback);
                if (result == null || result.trim().isEmpty()) lastExtractError = "PDF读取成功，但没有识别到文字";
                return result == null ? "" : result;
            }
            String result = extractTextFromUri(context, uri);
            if (result == null || result.trim().isEmpty()) lastExtractError = "文件内容为空或格式不受支持";
            return result == null ? "" : result;
        } catch (Throwable throwable) {
            if (throwable instanceof ThreadDeath) throw (ThreadDeath) throwable;
            lastExtractError = describeExtractError(throwable);
            android.util.Log.e("DedediOCR", "文件识别失败: " + uri, throwable);
            return "";
        } finally { if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle(); }
    }

    public static String cleanOcrText(String text) {
        if (text == null) return "";
        String[] lines = text.split("\n", -1); StringBuilder result = new StringBuilder(text.length()); boolean first = true;
        for (String line : lines) {
            String trimmed = line.trim();
            if (trimmed.length() == 1 && "个口日目一丨丶卜丿〇回凸凹卐卍了的地得".contains(trimmed)) continue;
            if (!first) result.append('\n'); result.append(line); first = false;
        }
        return result.toString();
    }

    private static int countDarkSamples(Bitmap bitmap, int y, int[] row) {
        int width = bitmap.getWidth();
        bitmap.getPixels(row, 0, width, 0, y, width, 1);
        int step = Math.max(1, width / 96);
        int darkCount = 0;
        for (int x = 0; x < width; x += step) {
            int color = row[x];
            if (Color.alpha(color) < 32) continue;
            int luminance = (Color.red(color) * 299 + Color.green(color) * 587 + Color.blue(color) * 114) / 1000;
            if (luminance < 215) darkCount++;
        }
        return darkCount;
    }

    private static int findBestOcrSplit(Bitmap bitmap, int coreStart, int idealEnd) {
        int imageHeight = bitmap.getHeight();
        int searchStart = Math.max(coreStart + OCR_MIN_CORE_HEIGHT, idealEnd - OCR_SPLIT_SEARCH_RADIUS);
        int searchEnd = Math.min(imageHeight - OCR_MIN_CORE_HEIGHT, idealEnd + OCR_SPLIT_SEARCH_RADIUS);
        if (searchStart >= searchEnd) return idealEnd;

        int width = bitmap.getWidth();
        int[] row = new int[width];
        int step = Math.max(1, width / 96);
        int sampleCount = Math.max(1, (width + step - 1) / step);
        int blankThreshold = Math.max(1, sampleCount / 40);
        int bestLowDensityRow = idealEnd;
        long bestLowDensityScore = Long.MAX_VALUE;
        int blankRunStart = -1;
        int bestBlankStart = -1;
        int bestBlankEnd = -1;

        for (int y = searchStart; y <= searchEnd; y += 2) {
            int dark = countDarkSamples(bitmap, y, row);
            long score = dark * 10_000L + Math.abs(y - idealEnd);
            if (score < bestLowDensityScore) {
                bestLowDensityScore = score;
                bestLowDensityRow = y;
            }
            if (dark <= blankThreshold) {
                if (blankRunStart < 0) blankRunStart = y;
            } else if (blankRunStart >= 0) {
                int blankRunEnd = y - 2;
                if (bestBlankStart < 0 || blankRunEnd - blankRunStart > bestBlankEnd - bestBlankStart) {
                    bestBlankStart = blankRunStart;
                    bestBlankEnd = blankRunEnd;
                }
                blankRunStart = -1;
            }
        }

        if (blankRunStart >= 0 && (bestBlankStart < 0 || searchEnd - blankRunStart > bestBlankEnd - bestBlankStart)) {
            bestBlankStart = blankRunStart;
            bestBlankEnd = searchEnd;
        }
        if (bestBlankStart >= 0 && bestBlankEnd - bestBlankStart >= 8) return (bestBlankStart + bestBlankEnd) / 2;
        return bestLowDensityRow;
    }

    private static List<Integer> buildOcrCoreBoundaries(Bitmap bitmap) {
        int imageHeight = bitmap.getHeight();
        List<Integer> boundaries = new ArrayList<>();
        boundaries.add(0);
        int coreStart = 0;

        while (imageHeight - coreStart > OCR_TARGET_CORE_HEIGHT) {
            int idealEnd = Math.min(imageHeight, coreStart + OCR_TARGET_CORE_HEIGHT);
            if (imageHeight - idealEnd < OCR_MIN_CORE_HEIGHT) break;
            int split = findBestOcrSplit(bitmap, coreStart, idealEnd);
            if (split <= coreStart + OCR_MIN_CORE_HEIGHT || split >= imageHeight) split = idealEnd;
            boundaries.add(split);
            coreStart = split;
        }

        if (boundaries.get(boundaries.size() - 1) != imageHeight) boundaries.add(imageHeight);
        return boundaries;
    }

    private static String joinOcrLines(List<OcrLineResult> lines) {
        StringBuilder result = new StringBuilder();
        for (OcrLineResult line : lines) {
            if (line.text == null || line.text.trim().isEmpty()) continue;
            if (result.length() > 0) result.append('\n');
            result.append(line.text);
        }
        return result.toString();
    }

    public static String performOcrOnBitmap(Bitmap fullBitmap, Context context, TextExtractCallback callback) throws Exception {
        if (fullBitmap == null || fullBitmap.isRecycled()) throw new IOException("图片位图不可用");
        long pixels = (long) fullBitmap.getWidth() * fullBitmap.getHeight();

        if (fullBitmap.getHeight() <= OCR_SINGLE_PASS_MAX_HEIGHT && pixels <= OCR_SINGLE_PASS_MAX_PIXELS) {
            if (callback != null) AppExecutors.MAIN.post(() -> callback.onProgress(1, 1));
            String value = recognizeInputImage(InputImage.fromBitmap(fullBitmap, 0));
            return cleanOcrText(fixPunctuation(value));
        }

        List<Integer> boundaries = buildOcrCoreBoundaries(fullBitmap);
        int total = boundaries.size() - 1;
        List<OcrLineResult> acceptedLines = new ArrayList<>();

        for (int i = 0; i < total; i++) {
            int progress = i + 1;
            if (callback != null) AppExecutors.MAIN.post(() -> callback.onProgress(progress, total));

            int coreStart = boundaries.get(i);
            int coreEnd = boundaries.get(i + 1);
            int cropStart = Math.max(0, coreStart - OCR_CHUNK_OVERLAP);
            int cropEnd = Math.min(fullBitmap.getHeight(), coreEnd + OCR_CHUNK_OVERLAP);
            int cropHeight = cropEnd - cropStart;
            if (cropHeight <= 0) continue;

            Bitmap chunk = Bitmap.createBitmap(fullBitmap, 0, cropStart, fullBitmap.getWidth(), cropHeight);
            try {
                List<OcrLineResult> chunkLines = recognizeInputImageLines(
                        InputImage.fromBitmap(chunk, 0),
                        cropStart,
                        coreStart + Math.max(0, coreEnd - coreStart) / 2
                );
                boolean firstChunk = i == 0;
                boolean lastChunk = i == total - 1;
                for (OcrLineResult line : chunkLines) {
                    int centerY = line.centerY();
                    boolean belongs = (firstChunk || centerY >= coreStart) && (lastChunk || centerY < coreEnd);
                    if (belongs) acceptedLines.add(line);
                }
            } finally {
                chunk.recycle();
            }
        }

        return cleanOcrText(fixPunctuation(joinOcrLines(acceptedLines)));
    }

    public static String performOcrOnPdf(android.net.Uri uri, Context context, TextExtractCallback callback) throws Exception {
        StringBuilder fullText = new StringBuilder();
        try (android.os.ParcelFileDescriptor descriptor = context.getContentResolver().openFileDescriptor(uri, "r")) {
            if (descriptor == null) return "";
            try (android.graphics.pdf.PdfRenderer renderer = new android.graphics.pdf.PdfRenderer(descriptor)) {
                int pages = renderer.getPageCount();
                for (int i = 0; i < pages; i++) {
                    int progress = i + 1;
                    if (callback != null) AppExecutors.MAIN.post(() -> callback.onProgress(progress, pages));
                    try (android.graphics.pdf.PdfRenderer.Page page = renderer.openPage(i)) {
                        long sourcePixels = Math.max(1L, (long) page.getWidth() * page.getHeight());
                        double scale = Math.min(2.0d, Math.sqrt((double) MAX_PDF_RENDER_PIXELS / sourcePixels));
                        if (!Double.isFinite(scale) || scale <= 0d) scale = 1d;
                        int renderWidth = Math.max(1, (int) Math.round(page.getWidth() * scale));
                        int renderHeight = Math.max(1, (int) Math.round(page.getHeight() * scale));
                        Bitmap bitmap = Bitmap.createBitmap(renderWidth, renderHeight, Bitmap.Config.ARGB_8888);
                        try {
                            bitmap.eraseColor(Color.WHITE);
                            android.graphics.Matrix matrix = new android.graphics.Matrix();
                            matrix.setScale(
                                    renderWidth / (float) Math.max(1, page.getWidth()),
                                    renderHeight / (float) Math.max(1, page.getHeight())
                            );
                            page.render(bitmap, null, matrix, android.graphics.pdf.PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                            String pageText = performOcrOnBitmap(bitmap, context, null);
                            if (pageText != null && !pageText.isEmpty()) {
                                if (fullText.length() > 0) fullText.append("\n\n");
                                fullText.append(pageText);
                            }
                        } finally {
                            bitmap.recycle();
                        }
                    }
                }
            }
        }
        return cleanOcrText(fixPunctuation(fullText.toString()));
    }

    public static String fixPunctuation(String text) {
        if (text == null) return "";
        text = PUNCT_PATTERN_2.matcher(PUNCT_PATTERN_1.matcher(text).replaceAll("……")).replaceAll("……");
        StringBuilder result = new StringBuilder(text.length()); boolean inQuote = false;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i); boolean punctuation = c == ',' || c == '.' || c == ':' || c == ';' || c == '?' || c == '!' || c == '"' || c == '(' || c == ')' || c == '\'';
            if (punctuation) {
                boolean previousChinese = false, nextChinese = false;
                for (int j = i - 1; j >= Math.max(0, i - 3); j--) { if (isChinese(text.charAt(j))) { previousChinese = true; break; } if (!Character.isWhitespace(text.charAt(j))) break; }
                for (int j = i + 1; j < Math.min(text.length(), i + 4); j++) { if (isChinese(text.charAt(j))) { nextChinese = true; break; } if (!Character.isWhitespace(text.charAt(j))) break; }
                if (previousChinese || nextChinese) {
                    if (c == ',') c = '，'; else if (c == '.') c = '。'; else if (c == ':') c = '：'; else if (c == ';') c = '；'; else if (c == '?') c = '？'; else if (c == '!') c = '！'; else if (c == '(') c = '（'; else if (c == ')') c = '）'; else if (c == '"') { c = inQuote ? '”' : '“'; inQuote = !inQuote; } else if (c == '\'') c = '’';
                }
            }
            result.append(c);
        }
        return result.toString();
    }

    public static boolean isChinese(char c) { return c >= '\u4e00' && c <= '\u9fa5'; }

    public static String extractTextFromUri(Context context, android.net.Uri uri) {
        String name = getFileName(context, uri), mime = context.getContentResolver().getType(uri); String lower = name == null ? "" : name.toLowerCase(Locale.ROOT);
        try {
            if (lower.endsWith(".docx") || "application/vnd.openxmlformats-officedocument.wordprocessingml.document".equals(mime)) return extractDocx(context, uri);
            if (lower.endsWith(".pptx") || "application/vnd.openxmlformats-officedocument.presentationml.presentation".equals(mime)) return extractPptx(context, uri);
            try (InputStream input = context.getContentResolver().openInputStream(uri); BufferedReader reader = new BufferedReader(new InputStreamReader(input, StandardCharsets.UTF_8))) {
                StringBuilder result = new StringBuilder(); String line; while ((line = reader.readLine()) != null) result.append(line).append('\n'); return result.toString();
            }
        } catch (Exception exception) { exception.printStackTrace(); return ""; }
    }

    private static String extractDocx(Context context, android.net.Uri uri) throws Exception {
        String xml = null;
        try (java.util.zip.ZipInputStream zip = new java.util.zip.ZipInputStream(context.getContentResolver().openInputStream(uri))) {
            java.util.zip.ZipEntry entry; byte[] buffer = new byte[8192];
            while ((entry = zip.getNextEntry()) != null) if ("word/document.xml".equals(entry.getName())) {
                ByteArrayOutputStream output = new ByteArrayOutputStream(); int read; while ((read = zip.read(buffer)) != -1) output.write(buffer, 0, read); xml = output.toString(StandardCharsets.UTF_8.name()); break;
            }
        }
        if (xml == null) return ""; StringBuilder result = new StringBuilder();
        try {
            org.xmlpull.v1.XmlPullParser parser = org.xmlpull.v1.XmlPullParserFactory.newInstance().newPullParser(); parser.setInput(new java.io.StringReader(xml)); boolean inText = false;
            for (int event = parser.getEventType(); event != org.xmlpull.v1.XmlPullParser.END_DOCUMENT; event = parser.next()) {
                String tag = parser.getName();
                if (event == org.xmlpull.v1.XmlPullParser.START_TAG && ("t".equals(tag) || "w:t".equals(tag))) inText = true;
                else if (event == org.xmlpull.v1.XmlPullParser.TEXT && inText) result.append(parser.getText());
                else if (event == org.xmlpull.v1.XmlPullParser.END_TAG) { if ("t".equals(tag) || "w:t".equals(tag)) inText = false; else if ("p".equals(tag) || "w:p".equals(tag)) result.append('\n'); }
            }
        } catch (Exception ignored) { Matcher matcher = WORD_TEXT_PATTERN.matcher(xml); while (matcher.find()) result.append(matcher.group(1)); }
        return decodeXmlEntities(result.toString());
    }

    private static String extractPptx(Context context, android.net.Uri uri) throws Exception {
        StringBuilder result = new StringBuilder();
        try (java.util.zip.ZipInputStream zip = new java.util.zip.ZipInputStream(context.getContentResolver().openInputStream(uri))) {
            java.util.zip.ZipEntry entry; byte[] buffer = new byte[8192];
            while ((entry = zip.getNextEntry()) != null) if (entry.getName().startsWith("ppt/slides/slide") && entry.getName().endsWith(".xml")) {
                ByteArrayOutputStream output = new ByteArrayOutputStream(); int read; while ((read = zip.read(buffer)) != -1) output.write(buffer, 0, read);
                Matcher matcher = PPT_TEXT_PATTERN.matcher(output.toString(StandardCharsets.UTF_8.name())); while (matcher.find()) result.append(matcher.group(1)); result.append("\n\n");
            }
        }
        return decodeXmlEntities(result.toString()).trim();
    }

    private static String decodeXmlEntities(String text) {
        if (text.indexOf('&') < 0) return text;
        return text.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&apos;", "'").replace("&amp;", "&");
    }

    public static String getFileName(Context context, android.net.Uri uri) {
        String result = null;
        if (uri != null && "content".equals(uri.getScheme())) {
            try (android.database.Cursor cursor = context.getContentResolver().query(uri, null, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) { int index = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME); if (index >= 0) result = cursor.getString(index); }
            } catch (Exception ignored) {}
        }
        if (result == null && uri != null) { String path = uri.getPath(); if (path != null) { int cut = path.lastIndexOf('/'); result = cut >= 0 ? path.substring(cut + 1) : path; } }
        return result;
    }

    private EditText inputText, editTemp, editThreshDe1, editThreshDe2, editThreshDe3, expandedEditText, expandedInputEditText;
    private TextView outputText, tvWordCount, tvInputEditorWordCount;
    private ScrollView scrollView, editorScrollView;
    private ProgressBar progressBar;
    private Button btnCheck, btnCopy, btnSaveTxt, btnPaste, btnClear, btnImport;
    private RadioButton rbFast, rbPro;
    private RadioGroup rgMode;
    private DrawerLayout drawerLayout;
    private SharedPreferences sp;
    private boolean currentIsFast, hasStartedChecking, autoScrollEnabled = true, isTouchingScrollView, isTyposExpanded, isRestoringHistory, isManuallyEditedOut, originalIsManuallyEdited, isEditorSelfModifying, firstEditorCursorTapPending, isInputEditorOpen, isInputEditorSelfModifying;
    private volatile boolean isCheckingMain, modelsLoading;
    private volatile long inferenceGeneration;
    private int saveFormat;
    private String pendingSaveText = "", lastSavedHistoryFileId, editingTypoKey, originalEditorText = "", originalInputEditorText = "";
    private SpannableStringBuilder lastEditorSpannable;
    private final Stack<EditorState> editorUndoStack = new Stack<>(), editorRedoStack = new Stack<>();
    private final Stack<InputEdit> inputUndoStack = new Stack<>(), inputRedoStack = new Stack<>();
    private final InputCounts inputCounts = new InputCounts();
    private final Handler inputSyncHandler = new Handler(Looper.getMainLooper());
    private boolean mainSyncDirty, inputEditorSyncDirty;
    private final Runnable inputEditorSync = () -> {
        if (!inputEditorSyncDirty || expandedInputEditText == null) return;
        sp.edit().putString("sync_text", expandedInputEditText.getText().toString()).apply(); inputEditorSyncDirty = false;
    };
    private void flushInputSync() {
        inputSyncHandler.removeCallbacksAndMessages(null);
        if (sp != null && inputText != null && (mainSyncDirty || inputEditorSyncDirty)) {
            CharSequence text = isInputEditorOpen && expandedInputEditText != null ? expandedInputEditText.getText() : inputText.getText();
            sp.edit().putString("sync_text", text.toString()).apply();
        }
        mainSyncDirty = false; inputEditorSyncDirty = false;
    }
    static final class InputEdit {
        final int start, insertedLength, selectionStart, snapshotLength;
        final CharSequence removed;
        InputEdit(CharSequence text, int start, int count, int inserted, int selection) {
            this.start = start; insertedLength = inserted; selectionStart = selection; snapshotLength = text.length();
            removed = new SpannableString(text.subSequence(start, start + count));
        }
    }
    private void pushInputEdit(Stack<InputEdit> stack, InputEdit edit) {
        stack.push(edit); int totalCharacters = 0;
        for (int i = stack.size() - 1; i >= 0; i--) {
            totalCharacters += stack.get(i).snapshotLength;
            if (stack.size() > 50 || totalCharacters > 2_000_000) stack.remove(0);
        }
    }
    static final class InputCounts {
        int with, without, left, right, removedWith, removedWithout;
        void reset(CharSequence text) { with = countWithPunctuation(text, 0, text.length()); without = countLettersOrDigits(text, 0, text.length()); }
        void before(CharSequence text, int start, int count) {
            left = Math.max(0, start - 1); right = Math.min(text.length(), start + count + 1);
            if (left > 0 && Character.isLowSurrogate(text.charAt(left)) && Character.isHighSurrogate(text.charAt(left - 1))) left--;
            if (right < text.length() && right > 0 && Character.isHighSurrogate(text.charAt(right - 1)) && Character.isLowSurrogate(text.charAt(right))) right++;
            removedWith = countWithPunctuation(text, left, right); removedWithout = countLettersOrDigits(text, left, right);
        }
        void after(CharSequence text, int before, int count) {
            int end = right - before + count;
            with += countWithPunctuation(text, left, end) - removedWith;
            without += countLettersOrDigits(text, left, end) - removedWithout;
        }
    }
    private final List<ClauseLink> currentClauseLinks = new ArrayList<>();
    private View expandedEditorOverlay, inputEditorOverlay;

    private void pushState(Stack<EditorState> stack, EditorState state) {
        stack.push(state);
        int totalCharacters = 0;
        for (int i = stack.size() - 1; i >= 0; i--) {
            totalCharacters += stack.get(i).text.length();
            if (stack.size() > 50 || totalCharacters > 2_000_000) stack.remove(0);
        }
    }

    private void setupSystemBarInsets() {
        View mainContent = findViewById(R.id.mainContentFrame);
        View drawerContent = findViewById(R.id.drawerContent);
        androidx.core.view.OnApplyWindowInsetsListener listener = (view, insets) -> {
            androidx.core.graphics.Insets bars = insets.getInsets(
                    androidx.core.view.WindowInsetsCompat.Type.systemBars() | androidx.core.view.WindowInsetsCompat.Type.displayCutout());
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        };
        if (mainContent != null) { androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(mainContent, listener); androidx.core.view.ViewCompat.requestApplyInsets(mainContent); }
        if (drawerContent != null) { androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(drawerContent, listener); androidx.core.view.ViewCompat.requestApplyInsets(drawerContent); }
        boolean night = (getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK) == android.content.res.Configuration.UI_MODE_NIGHT_YES;
        androidx.core.view.WindowInsetsControllerCompat controller = androidx.core.view.WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        controller.setAppearanceLightStatusBars(!night);
        controller.setAppearanceLightNavigationBars(!night);
    }

    private void updateFontSize(int textOffset, int systemOffset) {
        float inputSize = 15f + textOffset, outputSize = 15.5f + textOffset; int ui = Math.max(-2, Math.min(2, systemOffset));
        if (inputText != null) inputText.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, inputSize);
        if (outputText != null) outputText.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, outputSize);
        if (expandedEditText != null) expandedEditText.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, outputSize);
        if (expandedInputEditText != null) expandedInputEditText.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, inputSize);
        TextView title = findViewById(R.id.tvTitle); if (title != null) title.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 20 + ui);
        if (rbFast != null) rbFast.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 14 + ui); if (rbPro != null) rbPro.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 14 + ui);
        if (btnCheck != null) btnCheck.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 16 + ui);
        for (Button button : new Button[]{btnImport, btnPaste, btnClear, btnCopy, btnSaveTxt}) if (button != null) button.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 13 + ui);
        if (tvWordCount != null) tvWordCount.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 11 + ui);
        for (int id : new int[]{R.id.btnEditorIndent, R.id.btnEditorUndo, R.id.btnEditorRedo, R.id.btnEditorSave}) { Button button = findViewById(id); if (button != null) button.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 13.5f + ui); }
        for (int id : new int[]{R.id.btnInputEditorIndent, R.id.btnInputEditorUndo, R.id.btnInputEditorRedo, R.id.btnInputEditorDone}) { Button button = findViewById(id); if (button != null) button.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 13f + ui); }
        if (tvInputEditorWordCount != null) tvInputEditorWordCount.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 15 + ui);
    }

    private android.graphics.drawable.GradientDrawable solidSkinDrawable(int color, float radiusDp) {
        android.graphics.drawable.GradientDrawable drawable = new android.graphics.drawable.GradientDrawable();
        drawable.setColor(color); drawable.setCornerRadius(radiusDp * getResources().getDisplayMetrics().density); return drawable;
    }

    private android.graphics.drawable.GradientDrawable gradientSkinDrawable(int[] colors) {
        android.graphics.drawable.GradientDrawable drawable = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TL_BR, colors);
        drawable.setGradientType(android.graphics.drawable.GradientDrawable.LINEAR_GRADIENT); drawable.setDither(true); return drawable;
    }

    private int skinAccent(String skin) {
        if ("egg".equals(skin)) return Color.parseColor("#E1A62E");
        if ("green".equals(skin)) return Color.parseColor("#58A66A");
        if ("blue".equals(skin)) return Color.parseColor("#63A7D8");
        if ("gradient".equals(skin)) return Color.parseColor("#6C9B84");
        return Color.parseColor("#90A4AE");
    }

    private int blendColor(int from, int to, float ratio) {
        float t = Math.max(0f, Math.min(1f, ratio));
        int a = Math.round(Color.alpha(from) * (1f - t) + Color.alpha(to) * t);
        int r = Math.round(Color.red(from) * (1f - t) + Color.red(to) * t);
        int g = Math.round(Color.green(from) * (1f - t) + Color.green(to) * t);
        int b = Math.round(Color.blue(from) * (1f - t) + Color.blue(to) * t);
        return Color.argb(a, r, g, b);
    }

    private int applyDepthToColor(int color, int depth) {
        if (depth == 0) return color;
        float[] hsv = new float[3];
        Color.colorToHSV(color, hsv);
        float amount = Math.min(1f, Math.abs(depth) / 50f);
        if (depth > 0) {
            hsv[1] = Math.min(1f, hsv[1] + 0.42f * amount);
            hsv[2] = Math.max(0.28f, hsv[2] - 0.10f * amount);
        } else {
            hsv[1] = Math.max(0f, hsv[1] - 0.18f * amount);
            hsv[2] = Math.min(1f, hsv[2] + 0.12f * amount);
        }
        return Color.HSVToColor(Color.alpha(color), hsv);
    }

    private int[][] gradientPresetPalettes() {
        return new int[][]{
                new int[]{Color.parseColor("#FFF4D8"), Color.parseColor("#FFE7CF"), Color.parseColor("#F9E8D9"), Color.parseColor("#F6F2E8")},
                new int[]{Color.parseColor("#EAF7E8"), Color.parseColor("#DDF4E4"), Color.parseColor("#D8F0EC"), Color.parseColor("#EAF6F8")},
                new int[]{Color.parseColor("#EAF2FF"), Color.parseColor("#DCEBFF"), Color.parseColor("#D8F4FF"), Color.parseColor("#E9FBFF")},
                new int[]{Color.parseColor("#FFE9E7"), Color.parseColor("#FFE2EF"), Color.parseColor("#F7E3FF"), Color.parseColor("#EEF0FF")},
                new int[]{Color.parseColor("#FDF0D8"), Color.parseColor("#F8EDCA"), Color.parseColor("#E6F0C9"), Color.parseColor("#D8F0D5"), Color.parseColor("#DDEFFF")},
                new int[]{Color.parseColor("#FFE1C7"), Color.parseColor("#FFCDB8"), Color.parseColor("#FFB8BF"), Color.parseColor("#DDBBFF")},
                new int[]{Color.parseColor("#D9F2FF"), Color.parseColor("#CBE9FF"), Color.parseColor("#C7E1FF"), Color.parseColor("#D7DAFF"), Color.parseColor("#ECE1FF")},
                new int[]{Color.parseColor("#E2F7EF"), Color.parseColor("#D2F5E1"), Color.parseColor("#C6EFDA"), Color.parseColor("#DDF8F1")},
                new int[]{Color.parseColor("#FFF1DF"), Color.parseColor("#FFF6E6"), Color.parseColor("#F2F5E9"), Color.parseColor("#E9F6F0"), Color.parseColor("#E9F1FB")},
                new int[]{Color.parseColor("#FCE6EE"), Color.parseColor("#F6E4F7"), Color.parseColor("#EDE6FF"), Color.parseColor("#E3EEFF")},
                new int[]{Color.parseColor("#FFF2CC"), Color.parseColor("#FBEAB0"), Color.parseColor("#E6F1BA"), Color.parseColor("#CFEFCF"), Color.parseColor("#CFE6FF")},
                new int[]{Color.parseColor("#E7F5FF"), Color.parseColor("#D8F1FF"), Color.parseColor("#D7F7F5"), Color.parseColor("#E7F8E8"), Color.parseColor("#F6F9EA")},
                new int[]{Color.parseColor("#FFE3D5"), Color.parseColor("#FFE9D0"), Color.parseColor("#FFF0DA"), Color.parseColor("#F6F0E8")},
                new int[]{Color.parseColor("#E7ECFF"), Color.parseColor("#DDE7FF"), Color.parseColor("#DDEFFF"), Color.parseColor("#E4F5FF"), Color.parseColor("#EEF8FF")}
        };
    }

    private void randomizeGradientSkinPalette() {
        int[][] presets = gradientPresetPalettes();
        int[] picked = presets[new java.util.Random().nextInt(presets.length)];
        android.content.SharedPreferences.Editor editor = sp.edit();
        editor.putInt("skin_gradient_count", picked.length);
        for (int i = 0; i < 5; i++) {
            if (i < picked.length) editor.putInt("skin_gradient_" + (i + 1), picked[i]);
            else editor.remove("skin_gradient_" + (i + 1));
        }
        editor.apply();
    }

    private int[] getGradientSkinPalette(boolean night) {
        int count = sp.getInt("skin_gradient_count", 0);
        if (count < 4 || !sp.contains("skin_gradient_1") || !sp.contains("skin_gradient_2") || !sp.contains("skin_gradient_3")) {
            randomizeGradientSkinPalette();
            count = sp.getInt("skin_gradient_count", 4);
        }
        count = Math.max(4, Math.min(5, count));
        int[] fallbacks = new int[]{Color.parseColor("#FFF0CF"), Color.parseColor("#E9F7E9"), Color.parseColor("#ECEBFF"), Color.parseColor("#D9F4FF"), Color.parseColor("#FFF7E5")};
        int[] colors = new int[count];
        for (int i = 0; i < count; i++) colors[i] = sp.getInt("skin_gradient_" + (i + 1), fallbacks[i]);
        if (night) for (int i = 0; i < colors.length; i++) colors[i] = blendColor(colors[i], Color.BLACK, 0.78f);
        return colors;
    }

    private void applySkin(String skin) {
        boolean night = (getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK) == android.content.res.Configuration.UI_MODE_NIGHT_YES;
        int bg, card;
        int[] gradient = null;
        if ("egg".equals(skin)) { bg = Color.parseColor(night ? "#292417" : "#FFF3C9"); card = Color.parseColor(night ? "#342D1B" : "#FFF9E6"); }
        else if ("green".equals(skin)) { bg = Color.parseColor(night ? "#17271B" : "#E6F5E7"); card = Color.parseColor(night ? "#203423" : "#F5FFF4"); }
        else if ("blue".equals(skin)) { bg = Color.parseColor(night ? "#17232D" : "#E8F4FB"); card = Color.parseColor(night ? "#1F303C" : "#F5FBFF"); }
        else if ("gradient".equals(skin)) { bg = Color.parseColor(night ? "#23242C" : "#F7F1E8"); card = Color.parseColor(night ? "#2B2D36" : "#FFFDF8"); gradient = getGradientSkinPalette(night); }
        else { bg = androidx.core.content.ContextCompat.getColor(this, R.color.bg_color); card = androidx.core.content.ContextCompat.getColor(this, R.color.card_bg); }
        int depth = "default".equals(skin) ? 0 : sp.getInt("skin_depth", 50) - 50;
        bg = applyDepthToColor(bg, depth); card = applyDepthToColor(card, depth);
        if (gradient != null) for (int i = 0; i < gradient.length; i++) gradient[i] = applyDepthToColor(gradient[i], depth);

        View mainContentFrame = findViewById(R.id.mainContentFrame), mainBody = findViewById(R.id.mainBody), drawerContent = findViewById(R.id.drawerContent), inputOverlay = findViewById(R.id.inputEditorOverlay), expandedOverlay = findViewById(R.id.expandedEditorOverlay);
        if (gradient != null) {
            if (drawerLayout != null) drawerLayout.setBackground(gradientSkinDrawable(gradient.clone()));
            if (mainContentFrame != null) mainContentFrame.setBackgroundColor(Color.TRANSPARENT);
            if (mainBody != null) mainBody.setBackgroundColor(Color.TRANSPARENT);
            if (drawerContent != null) drawerContent.setBackground(gradientSkinDrawable(gradient.clone()));
            if (inputOverlay != null) inputOverlay.setBackground(gradientSkinDrawable(gradient.clone()));
            if (expandedOverlay != null) expandedOverlay.setBackground(gradientSkinDrawable(gradient.clone()));
        } else {
            if (drawerLayout != null) drawerLayout.setBackground(solidSkinDrawable(bg, 0));
            if (mainContentFrame != null) mainContentFrame.setBackgroundColor(Color.TRANSPARENT);
            if (mainBody != null) mainBody.setBackgroundColor(Color.TRANSPARENT);
            for (int id : new int[]{R.id.drawerContent, R.id.inputEditorOverlay, R.id.expandedEditorOverlay}) { View view = findViewById(id); if (view != null) view.setBackground(solidSkinDrawable(bg, 0)); }
        }
        int[] cardIds = new int[]{R.id.paramsCard, R.id.inputText, R.id.outputText, R.id.inputEditorToolbar, R.id.outputEditorToolbar};
        int[] cardGradient = gradient == null ? null : gradient.clone();
        if (cardGradient != null) for (int i = 0; i < cardGradient.length; i++) cardGradient[i] = blendColor(cardGradient[i], Color.WHITE, night ? .06f : .22f);
        for (int id : cardIds) {
            View view = findViewById(id); if (view == null) continue;
            float radius = (id == R.id.inputText || id == R.id.outputText || id == R.id.paramsCard) ? 8 : 0;
            android.graphics.drawable.GradientDrawable drawable = cardGradient == null ? solidSkinDrawable(card, radius) : gradientSkinDrawable(cardGradient.clone());
            if (cardGradient != null) drawable.setCornerRadius(radius * getResources().getDisplayMetrics().density);
            view.setBackground(drawable);
        }

        androidx.core.view.WindowInsetsControllerCompat controller = androidx.core.view.WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        boolean lightBars = !night || !"default".equals(skin);
        controller.setAppearanceLightStatusBars(lightBars); controller.setAppearanceLightNavigationBars(lightBars);
        if (android.os.Build.VERSION.SDK_INT < 35) {
            if (gradient != null) {
                getWindow().setStatusBarColor(Color.TRANSPARENT);
                getWindow().setNavigationBarColor(Color.TRANSPARENT);
            } else {
                getWindow().setStatusBarColor(bg);
                getWindow().setNavigationBarColor(bg);
            }
        }
    }

    private void showFontSizeDialog() {
        int textOffset = sp.getInt("font_offset_text", 0), systemOffset = sp.getInt("font_offset_sys", 0), skinDepth = sp.getInt("skin_depth", 50);
        float density = getResources().getDisplayMetrics().density;
        LinearLayout layout = new LinearLayout(this); layout.setOrientation(LinearLayout.VERTICAL); layout.setPadding((int) (24 * density), (int) (20 * density), (int) (24 * density), (int) (12 * density));
        TextView title = new TextView(this); title.setText("调节字体大小"); title.setTextSize(18f); title.setTextColor(Color.BLACK); title.setTypeface(android.graphics.Typeface.create("sans-serif-medium", 0));
        TextView textLabel = new TextView(this); textLabel.setText("正文字号 (输入/输出/便签): " + (15 + textOffset)); textLabel.setTextSize(14f); textLabel.setTextColor(0xFF666666); textLabel.setPadding(0, (int) (18 * density), 0, (int) (4 * density));
        android.widget.SeekBar textSeek = new android.widget.SeekBar(this); textSeek.setMax(14); textSeek.setProgress(textOffset + 4); textSeek.setPadding((int) (8 * density), 0, (int) (8 * density), (int) (10 * density));
        TextView systemLabel = new TextView(this); systemLabel.setText("系统字号 (按钮/标题等): " + (systemOffset > 0 ? "+" + systemOffset : systemOffset)); systemLabel.setTextSize(14f); systemLabel.setTextColor(0xFF666666); systemLabel.setPadding(0, (int) (6 * density), 0, (int) (4 * density));
        android.widget.SeekBar systemSeek = new android.widget.SeekBar(this); systemSeek.setMax(4); systemSeek.setProgress(systemOffset + 2); systemSeek.setPadding((int) (8 * density), 0, (int) (8 * density), (int) (10 * density));
        textSeek.setOnSeekBarChangeListener(new SimpleSeekListener() { @Override public void onProgressChanged(android.widget.SeekBar seekBar, int progress, boolean fromUser) { int offset = progress - 4; textLabel.setText("正文字号 (输入/输出等): " + (15 + offset)); updateFontSize(offset, systemSeek.getProgress() - 2); } });
        systemSeek.setOnSeekBarChangeListener(new SimpleSeekListener() { @Override public void onProgressChanged(android.widget.SeekBar seekBar, int progress, boolean fromUser) { int offset = progress - 2; systemLabel.setText("系统字号 (按钮/标题等): " + (offset > 0 ? "+" + offset : offset)); updateFontSize(textSeek.getProgress() - 4, offset); } });

        LinearLayout skinRow = new LinearLayout(this); skinRow.setOrientation(LinearLayout.HORIZONTAL); skinRow.setGravity(android.view.Gravity.CENTER); skinRow.setPadding(0, (int) (6 * density), 0, (int) (2 * density));
        TextView depthLabel = new TextView(this); depthLabel.setText("界面深浅"); depthLabel.setTextSize(13f); depthLabel.setTextColor(0xFF777777); depthLabel.setPadding(0, (int) (8 * density), 0, 0);
        android.widget.SeekBar depthSeek = new android.widget.SeekBar(this); depthSeek.setMax(100); depthSeek.setProgress(skinDepth); depthSeek.setPadding((int) (8 * density), 0, (int) (8 * density), (int) (6 * density));
        Runnable refreshDepthVisibility = () -> {
            boolean showDepth = !"default".equals(sp.getString("ui_skin", "default"));
            depthLabel.setVisibility(showDepth ? View.VISIBLE : View.GONE);
            depthSeek.setVisibility(showDepth ? View.VISIBLE : View.GONE);
        };
        final String[] skinKeys = new String[]{"default", "egg", "green", "blue", "gradient"};
        final android.widget.ImageButton[] skinButtons = new android.widget.ImageButton[skinKeys.length];
        Runnable refreshSkinSelection = () -> {
            String selected = sp.getString("ui_skin", "default");
            for (int i = 0; i < skinButtons.length; i++) {
                android.widget.ImageButton button = skinButtons[i]; if (button == null) continue;
                boolean active = skinKeys[i].equals(selected);
                android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable(); bg.setShape(android.graphics.drawable.GradientDrawable.OVAL);
                bg.setColor(active ? 0x143F51B5 : Color.TRANSPARENT); bg.setStroke((int) ((active ? 2 : 1) * density), active ? skinAccent(skinKeys[i]) : 0x22000000); button.setBackground(bg);
            }
        };
        for (int i = 0; i < skinKeys.length; i++) {
            final String key = skinKeys[i];
            android.widget.ImageButton choice = new android.widget.ImageButton(this); skinButtons[i] = choice;
            choice.setImageResource("gradient".equals(key) ? R.drawable.ic_skin_shirt_gradient : R.drawable.ic_skin_shirt);
            if (!"gradient".equals(key)) choice.setColorFilter(skinAccent(key)); else choice.clearColorFilter();
            choice.setScaleType(android.widget.ImageView.ScaleType.FIT_CENTER); choice.setPadding((int) (5 * density), (int) (8 * density), (int) (5 * density), (int) (8 * density)); choice.setContentDescription("界面皮肤");
            LinearLayout.LayoutParams choiceParams = new LinearLayout.LayoutParams((int) (39 * density), (int) (39 * density)); choiceParams.setMargins((int) (3 * density), 0, (int) (3 * density), 0); skinRow.addView(choice, choiceParams);
            choice.setOnClickListener(v -> { if ("gradient".equals(key)) randomizeGradientSkinPalette(); sp.edit().putString("ui_skin", key).apply(); applySkin(key); refreshSkinSelection.run(); refreshDepthVisibility.run(); });
        }
        refreshSkinSelection.run();
        depthSeek.setOnSeekBarChangeListener(new SimpleSeekListener() {
            @Override public void onProgressChanged(android.widget.SeekBar seekBar, int progress, boolean fromUser) {
                sp.edit().putInt("skin_depth", progress).apply();
                applySkin(sp.getString("ui_skin", "default"));
            }
        });

        Button done = new Button(this); done.setText("完成"); done.setTextColor(0xFF2196F3); done.setBackgroundColor(Color.TRANSPARENT); LinearLayout.LayoutParams doneParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT); doneParams.gravity = android.view.Gravity.END; doneParams.rightMargin = (int) (1 * density); done.setLayoutParams(doneParams);
        layout.addView(title); layout.addView(textLabel); layout.addView(textSeek); layout.addView(systemLabel); layout.addView(systemSeek); layout.addView(skinRow); layout.addView(depthLabel); layout.addView(depthSeek); layout.addView(done); refreshDepthVisibility.run();
        android.app.AlertDialog dialog = new android.app.AlertDialog.Builder(this).setView(layout).create();
        Runnable persist = () -> sp.edit().putInt("font_offset_text", textSeek.getProgress() - 4).putInt("font_offset_sys", systemSeek.getProgress() - 2).putInt("skin_depth", depthSeek.getProgress()).apply();
        done.setOnClickListener(v -> { persist.run(); dialog.dismiss(); }); dialog.setOnCancelListener(d -> persist.run()); dialog.show();
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(); params.copyFrom(dialog.getWindow().getAttributes()); params.dimAmount = Math.max(0f, Math.min(1f, params.dimAmount * .9f)); params.width = (int) (getResources().getDisplayMetrics().widthPixels * 0.86f); params.gravity = android.view.Gravity.TOP | android.view.Gravity.CENTER_HORIZONTAL; params.y = (int) (getResources().getDisplayMetrics().heightPixels * 0.12f); dialog.getWindow().setAttributes(params);
        android.graphics.drawable.GradientDrawable background = new android.graphics.drawable.GradientDrawable(); background.setColor(Color.WHITE); background.setCornerRadius(16f); dialog.getWindow().setBackgroundDrawable(background);
    }

    private abstract static class SimpleSeekListener implements android.widget.SeekBar.OnSeekBarChangeListener {
        @Override public void onStartTrackingTouch(android.widget.SeekBar seekBar) {}
        @Override public void onStopTrackingTouch(android.widget.SeekBar seekBar) {}
    }

    private void loadSettings(boolean fast) {
        String temperature = sp.getString("pro_temp", "1.2");
        if (!isTemperatureValid(parseFloatSafe(temperature, Float.NaN))) {
            temperature = "1.2";
            sp.edit().putString("pro_temp", temperature).apply();
            Toast.makeText(this, "温度参数无效，已自动恢复为1.2（允许范围0.5～2.0）", Toast.LENGTH_LONG).show();
        }
        // 两种模式显示同一组专业参数；极速模式只禁用并置灰，不再换成另一套数字。
        editTemp.setText(temperature);
        editThreshDe1.setText(sp.getString("pro_th1", "0.76"));
        editThreshDe2.setText(sp.getString("pro_th2", "0.74"));
        editThreshDe3.setText(sp.getString("pro_th3", "0.78"));
        boolean professional = !fast;
        for (EditText field : new EditText[]{editTemp, editThreshDe1, editThreshDe2, editThreshDe3}) {
            field.setEnabled(professional);
            field.setAlpha(professional ? 1f : 0.45f);
        }
    }

    private void saveSettings(boolean fast) {
        if (fast) return;
        SharedPreferences.Editor editor = sp.edit()
                .putString("pro_th1", editThreshDe1.getText().toString())
                .putString("pro_th2", editThreshDe2.getText().toString())
                .putString("pro_th3", editThreshDe3.getText().toString());
        float temperature = parseFloatSafe(editTemp.getText().toString(), Float.NaN);
        if (isTemperatureValid(temperature)) editor.putString("pro_temp", editTemp.getText().toString());
        editor.apply();
    }

    private void saveHistory(String text, String fileId) {
        HistoryStore.save(this, sp, text, fileId, savedId -> { lastSavedHistoryFileId = savedId; renderHistoryUI(); });
    }

    private void openFilePicker() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT); intent.setType("*/*"); intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true); intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"text/plain", "text/markdown", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application/vnd.openxmlformats-officedocument.presentationml.presentation", "application/pdf", "image/*"}); startActivityForResult(intent, 102);
    }

    private void startFloatingService() {
        flushInputSync();
        Intent intent = new Intent(this, FloatingService.class);
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) startForegroundService(intent); else startService(intent);
        Toast.makeText(this, "悬浮窗已开启", Toast.LENGTH_SHORT).show(); moveTaskToBack(true);
    }

    private static void loadCharVocab(Context context, int[] charIds, String asset) throws Exception {
        String json = SecureAsset.readUtf8(context, asset);
        if (json == null || json.isEmpty()) throw new IllegalStateException("词表资源为空：" + asset);
        JSONObject object = new JSONObject(json);
        if (object.length() == 0) throw new IllegalStateException("词表内容为空：" + asset);

        long unknownId = object.optLong("[UNK]", 100L);
        if (unknownId < 0L || unknownId > Integer.MAX_VALUE) throw new IllegalStateException("词表 UNK 编号异常：" + asset);
        Arrays.fill(charIds, (int) unknownId);

        Iterator<String> keys = object.keys();
        while (keys.hasNext()) {
            String token = keys.next();
            int tokenId = object.getInt(token);
            if (token.length() == 1) charIds[token.charAt(0)] = tokenId;
        }

        clsId = object.optLong("[CLS]", -1L);
        sepId = object.optLong("[SEP]", -1L);
        maskId = object.optLong("[MASK]", -1L);
        unkId = unknownId;
        if (clsId != 101L || sepId != 102L || maskId != 103L || unkId != 100L) {
            throw new IllegalStateException("RoFormerV2 特殊 token 编号异常");
        }
        proVocabReady = true;
    }

    private static File createRuntimePlainModelFile(Context context, String cacheKey) throws IOException {
        File directory = new File(context.getCacheDir(), "dededi_runtime_models");
        if (!directory.exists() && !directory.mkdirs()) throw new IOException("无法创建临时模型目录");
        File[] stale = directory.listFiles((dir, name) -> name.endsWith(".pte"));
        if (stale != null) for (File file : stale) if (!file.equals(proPlainModelFile) && !file.delete()) file.deleteOnExit();
        String safe = cacheKey.replaceAll("[^a-zA-Z0-9._-]", "_");
        return new File(directory, "runtime_" + safe + "_" + System.nanoTime() + ".pte");
    }

    private static Module loadDecryptedModule(Context context, String assetName, String cacheKey, Object modelLock) throws Exception {
        synchronized (modelLock) {
            File plainModel = createRuntimePlainModelFile(context, cacheKey);
            long decryptStart = System.currentTimeMillis();
            if (!SecureAsset.decryptToFile(context, assetName, plainModel)) {
                plainModel.delete();
                throw new Exception("模型完整性校验或解密失败：" + SecureAsset.lastErrorSummary());
            }
            if (!plainModel.isFile() || plainModel.length() <= 4096L) {
                plainModel.delete();
                throw new IOException("生成的临时模型文件异常");
            }
            android.util.Log.i("DedediModel", "模型临时解密完成：" + assetName + "，耗时 " + (System.currentTimeMillis() - decryptStart) + "ms");
            try {
                long loadStart = System.currentTimeMillis();
                Module module = Module.load(plainModel.getAbsolutePath());
                proPlainModelFile = plainModel;
                android.util.Log.i("DedediModel", "ExecuTorch 模型载入完成，耗时 " + (System.currentTimeMillis() - loadStart) + "ms");
                return module;
            } catch (Throwable error) {
                plainModel.delete();
                if (error instanceof Exception) throw (Exception) error;
                if (error instanceof Error) throw (Error) error;
                throw new Exception("模型加载失败", error);
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        androidx.core.view.WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        setContentView(R.layout.activity_main);
        setupSystemBarInsets();
        instance = this; sp = getSharedPreferences("DedediConfig", MODE_PRIVATE);
        drawerLayout = findViewById(R.id.drawerLayout); inputText = findViewById(R.id.inputText); outputText = findViewById(R.id.outputText); tvWordCount = findViewById(R.id.tvWordCount); scrollView = findViewById(R.id.scrollView); progressBar = findViewById(R.id.progressBar);
        editTemp = findViewById(R.id.editTemp); editThreshDe1 = findViewById(R.id.editThreshDe1); editThreshDe2 = findViewById(R.id.editThreshDe2); editThreshDe3 = findViewById(R.id.editThreshDe3);
        btnCheck = findViewById(R.id.btnCheck); btnImport = findViewById(R.id.btnImport); btnPaste = findViewById(R.id.btnPaste); btnClear = findViewById(R.id.btnClear); btnCopy = findViewById(R.id.btnCopy); btnSaveTxt = findViewById(R.id.btnSaveTxt);
        rbFast = findViewById(R.id.rbFast); rbPro = findViewById(R.id.rbPro); rgMode = findViewById(R.id.rgMode); expandedEditorOverlay = findViewById(R.id.expandedEditorOverlay); expandedEditText = findViewById(R.id.expandedEditText); editorScrollView = findViewById(R.id.editorScrollView);
        inputEditorOverlay = findViewById(R.id.inputEditorOverlay); expandedInputEditText = findViewById(R.id.expandedInputEditText); tvInputEditorWordCount = findViewById(R.id.tvInputEditorWordCount);
        TextView title = findViewById(R.id.tvTitle); Button menu = findViewById(R.id.btnMenu), font = findViewById(R.id.btnFont), inputExpand = findViewById(R.id.btnInputExpand); View floatButton = findViewById(R.id.btnFloat);
        font.setOnClickListener(v -> showFontSizeDialog()); inputExpand.setOnClickListener(v -> openInputEditor()); updateFontSize(sp.getInt("font_offset_text", 0), sp.getInt("font_offset_sys", 0)); applySkin(sp.getString("ui_skin", "default"));
        setupScrollControls(); setupEditor(); setupInputEditor(); setupInputWatcher();
        currentIsFast = sp.getBoolean("is_fast_mode", false); rbFast.setChecked(currentIsFast); rbPro.setChecked(!currentIsFast); loadSettings(currentIsFast);
        rgMode.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == -1) return;
            saveSettings(currentIsFast);
            currentIsFast = checkedId == R.id.rbFast;
            sp.edit().putBoolean("is_fast_mode", currentIsFast).apply();
            loadSettings(currentIsFast);
            if (!currentIsFast && inputText.length() > 0) warmProEngineAsync(this);
        });
        handleIntent(getIntent());
        title.setOnClickListener(v -> showHelp());
        menu.setOnClickListener(v -> { editingTypoKey = null; ((Button) findViewById(R.id.btnAddTypo)).setText("添加"); ((EditText) findViewById(R.id.etOriginal)).setText(""); ((EditText) findViewById(R.id.etCorrected)).setText(""); drawerLayout.openDrawer(GravityCompat.END); renderCustomTyposUI(); renderHistoryUI(); });
        floatButton.setOnClickListener(v -> {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M && !android.provider.Settings.canDrawOverlays(this)) startActivityForResult(new Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:" + getPackageName())), 201); else startFloatingService();
        });
        setupMainButtons(); setupDrawerButtons(); btnSaveTxt.setEnabled(inputText.length() > 0);
    }

    @SuppressLint("ClickableViewAccessibility")
    private void setupScrollControls() {
        View touchArea = findViewById(R.id.scrollTouchArea);
        touchArea.setOnTouchListener((v, event) -> {
            View child = scrollView.getChildAt(0); int max = child == null ? 0 : child.getHeight() - scrollView.getHeight();
            if (max > 0 && v.getHeight() > 0) scrollView.scrollTo(0, (int) (Math.max(0, Math.min(event.getY(), v.getHeight())) / v.getHeight() * max));
            int action = event.getActionMasked(); if (action == MotionEvent.ACTION_DOWN) { isTouchingScrollView = true; autoScrollEnabled = false; } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) { isTouchingScrollView = false; if (!scrollView.canScrollVertically(1)) autoScrollEnabled = true; }
            return true;
        });
        scrollView.setOnTouchListener((v, event) -> { int action = event.getActionMasked(); if (action == MotionEvent.ACTION_DOWN) { isTouchingScrollView = true; autoScrollEnabled = false; } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) { isTouchingScrollView = false; if (!scrollView.canScrollVertically(1)) autoScrollEnabled = true; } return false; });
        scrollView.setOnScrollChangeListener((v, x, y, oldX, oldY) -> { if (y < oldY) autoScrollEnabled = false; if (!isTouchingScrollView && !v.canScrollVertically(1)) autoScrollEnabled = true; });
        View editorTouch = findViewById(R.id.editorScrollTouchArea);
        editorTouch.setOnTouchListener((v, event) -> { View child = editorScrollView.getChildAt(0); int max = child == null ? 0 : child.getHeight() - editorScrollView.getHeight(); if (max > 0 && v.getHeight() > 0) editorScrollView.scrollTo(0, (int) (Math.max(0, Math.min(event.getY(), v.getHeight())) / v.getHeight() * max)); return true; });
    }

    @SuppressLint("ClickableViewAccessibility")
    private void setupEditor() {
        Button collapse = findViewById(R.id.btnEditorCollapse), indent = findViewById(R.id.btnEditorIndent), save = findViewById(R.id.btnEditorSave), close = findViewById(R.id.btnEditorClose), undo = findViewById(R.id.btnEditorUndo), redo = findViewById(R.id.btnEditorRedo);
        expandedEditText.setOnTouchListener(new View.OnTouchListener() {
            int scrollBeforeTouch;
            boolean protectInitialCursorTap;
            JumpSpan pressedJumpSpan;

            private JumpSpan findJumpSpan(EditText widget, MotionEvent event) {
                Layout layout = widget.getLayout();
                if (layout == null) return null;
                int x = (int) event.getX() - widget.getTotalPaddingLeft() + widget.getScrollX();
                int y = (int) event.getY() - widget.getTotalPaddingTop() + widget.getScrollY();
                if (y < 0 || y > layout.getHeight()) return null;
                int line = layout.getLineForVertical(y);
                if (x < layout.getLineLeft(line) || x > layout.getLineRight(line)) return null;
                int offset = layout.getOffsetForHorizontal(line, x);
                JumpSpan[] links = widget.getText().getSpans(offset, offset, JumpSpan.class);
                return links.length > 0 ? links[0] : null;
            }

            @Override public boolean onTouch(View v, MotionEvent event) {
                EditText widget = (EditText) v;
                int action = event.getActionMasked();
                if (action == MotionEvent.ACTION_DOWN) {
                    scrollBeforeTouch = editorScrollView.getScrollY();
                    protectInitialCursorTap = firstEditorCursorTapPending || !widget.hasFocus();
                    pressedJumpSpan = findJumpSpan(widget, event);
                    // 从按下开始就拦截序号，避免 EditText 把光标/选区放到序号上，随后又自动滚回顶部。
                    return pressedJumpSpan != null;
                }
                if (pressedJumpSpan != null) {
                    if (action == MotionEvent.ACTION_UP) {
                        JumpSpan span = pressedJumpSpan;
                        pressedJumpSpan = null;
                        span.onClick(widget);
                        return true;
                    }
                    if (action == MotionEvent.ACTION_CANCEL) pressedJumpSpan = null;
                    return true;
                }
                if (action != MotionEvent.ACTION_UP) return false;
                Layout layout = widget.getLayout();
                if (layout == null) return false;
                int x = (int) event.getX() - widget.getTotalPaddingLeft() + widget.getScrollX();
                int y = (int) event.getY() - widget.getTotalPaddingTop() + widget.getScrollY();
                int line = layout.getLineForVertical(y);
                int offset = layout.getOffsetForHorizontal(line, x);
                int lockedEnd = 0; for (IgnoredInCopySpan span : widget.getText().getSpans(0, widget.length(), IgnoredInCopySpan.class)) lockedEnd = Math.max(lockedEnd, widget.getText().getSpanEnd(span));
                if (offset < lockedEnd) { int end = lockedEnd; widget.post(() -> widget.setSelection(Math.min(end, widget.length()))); }
                boolean extendedProtection = protectInitialCursorTap;
                firstEditorCursorTapPending = false;
                stabilizeEditorScrollAfterTap(scrollBeforeTouch, extendedProtection);
                return false;
            }
        });
        expandedEditText.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                if (isEditorSelfModifying || isCheckingMain || currentClauseLinks == null) return;
                pushState(editorUndoStack, new EditorState(new SpannableStringBuilder(s), expandedEditText.getSelectionStart())); editorRedoStack.clear();
            }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override public void afterTextChanged(Editable editable) {
                if (isCheckingMain || isEditorSelfModifying) return; boolean purge = false;
                for (ClauseLink link : currentClauseLinks) {
                    if (link.isDead) continue; boolean altered = false;
                    for (TargetSpan target : link.targetSpans) {
                        int start = editable.getSpanStart(target), end = editable.getSpanEnd(target);
                        if (start < 0 || end < 0 || !editable.subSequence(start, end).toString().equals(target.expected)) { altered = true; break; }
                    }
                    if (altered) { link.isDead = true; purge = true; }
                }
                if (purge) expandedEditText.post(() -> purgeDeadClauseMarkers(expandedEditText.getText()));
            }
        });
        expandedEditText.setFilters(new InputFilter[]{(source, start, end, dest, dstart, dend) -> {
            if (isEditorSelfModifying) return null; Editable editable = expandedEditText.getText(); if (editable == null) return null;
            for (IgnoredInCopySpan span : editable.getSpans(Math.max(0, dstart - 1), Math.min(editable.length(), dend + 1), IgnoredInCopySpan.class)) {
                int spanStart = editable.getSpanStart(span), spanEnd = editable.getSpanEnd(span);
                if (Math.max(dstart, spanStart) < Math.min(dend, spanEnd) || (dstart > spanStart && dstart < spanEnd)) return dest.subSequence(dstart, dend);
            }
            return null;
        }});
        setupOutputLongPress();
        Runnable apply = () -> applyEditorChanges();
        collapse.setOnClickListener(v -> apply.run());
        close.setOnClickListener(v -> {
            if (!expandedEditText.getText().toString().equals(originalEditorText)) new AlertDialog.Builder(this).setMessage("保留此次更改吗？").setPositiveButton("是", (d, w) -> apply.run()).setNegativeButton("否", (d, w) -> closeEditor()).show(); else closeEditor();
        });
        indent.setOnClickListener(v -> applyIndent());
        undo.setOnClickListener(v -> restoreEditorState(editorUndoStack, editorRedoStack, true));
        redo.setOnClickListener(v -> { if (editorRedoStack.isEmpty()) Toast.makeText(this, "上一步非撤销操作，无法还原", Toast.LENGTH_SHORT).show(); else restoreEditorState(editorRedoStack, editorUndoStack, false); });
        save.setOnClickListener(v -> { isManuallyEditedOut = true; outputText.setText(expandedEditText.getText()); btnSaveTxt.performClick(); });
    }

    private void stabilizeEditorScrollAfterTap(int expectedScrollY, boolean extendedProtection) {
        if (editorScrollView == null) return;
        Runnable restoreIfJumped = () -> {
            if (!isEditorOpen || editorScrollView == null) return;
            View child = editorScrollView.getChildAt(0);
            int maxScrollY = child == null ? 0 : Math.max(0, child.getHeight() - editorScrollView.getHeight());
            int targetScrollY = Math.max(0, Math.min(expectedScrollY, maxScrollY));
            int currentScrollY = editorScrollView.getScrollY();
            int threshold = Math.max(96, Math.max((int) (48f * getResources().getDisplayMetrics().density), editorScrollView.getHeight() / 6));
            // 只修复系统首次聚焦/键盘重排造成的“掉到顶部附近”，不干预正常的小幅自动调整或手动滚动。
            if (targetScrollY > threshold * 2 && currentScrollY <= threshold * 2 && targetScrollY - currentScrollY > threshold * 2) {
                editorScrollView.scrollTo(0, targetScrollY);
            }
        };
        editorScrollView.post(restoreIfJumped);
        editorScrollView.postDelayed(restoreIfJumped, 48);
        editorScrollView.postDelayed(restoreIfJumped, 120);
        editorScrollView.postDelayed(restoreIfJumped, 260);
        if (extendedProtection) {
            // 首次获得焦点时，软键盘与 250ms 入场动画可能在更晚的布局帧再次触发滚动。
            editorScrollView.postDelayed(restoreIfJumped, 420);
            editorScrollView.postDelayed(restoreIfJumped, 700);
        }
    }

    private void jumpEditorToOffset(TextView textView, int target) {
        if (target < 0 || target > textView.length()) return;
        // 序号只负责导航，不移动 EditText 光标；否则系统会再次执行 bringPointIntoView，
        // 把外层 ScrollView 拉回序号所在的顶部区域，并让序号呈现被选中的状态。
        jumpAndFlash(textView, target, editorScrollView);
        Runnable keepTargetVisible = () -> {
            Layout layout = textView.getLayout();
            if (layout == null || editorScrollView == null) return;
            int safeTarget = Math.max(0, Math.min(target, textView.length()));
            int line = layout.getLineForOffset(safeTarget);
            int y = layout.getLineTop(line);
            editorScrollView.scrollTo(0, Math.max(0, y - editorScrollView.getHeight() / 3));
        };
        editorScrollView.post(keepTargetVisible);
        editorScrollView.postDelayed(keepTargetVisible, 120);
        editorScrollView.postDelayed(keepTargetVisible, 260);
    }

    private void purgeDeadClauseMarkers(Editable editable) {
        isEditorSelfModifying = true;
        try {
            List<ListMarkerSpan> delete = new ArrayList<>(); for (ClauseLink link : currentClauseLinks) if (link.isDead && editable.getSpanStart(link.listMarkerSpan) >= 0) delete.add(link.listMarkerSpan);
            delete.sort((a, b) -> Integer.compare(editable.getSpanStart(b), editable.getSpanStart(a)));
            for (ListMarkerSpan span : delete) {
                int start = editable.getSpanStart(span), end = editable.getSpanEnd(span); if (start < 0 || end < 0) continue;
                while (start > 0 && editable.charAt(start - 1) != '\n') start--; while (end < editable.length() && editable.charAt(end) != '\n') end++; if (end < editable.length()) end++; editable.delete(start, end);
            }
        } finally { isEditorSelfModifying = false; }
    }

    @SuppressLint("ClickableViewAccessibility")
    private void setupOutputLongPress() {
        outputText.setOnTouchListener(new View.OnTouchListener() {
            boolean triggered; float startX, startY, rawX, rawY;
            final Runnable longPress = () -> {
                String current = outputText.getText().toString(); if (current.isEmpty() || "正在加载...".equals(current) || "已加载。".equals(current) || isCheckingMain || lastEditorSpannable == null) return;
                triggered = true; outputText.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);
                ViewGroup parent = (ViewGroup) scrollView.getParent(); int[] location = new int[2]; parent.getLocationOnScreen(location); int centerX = (int) (rawX - location[0]), centerY = (int) (rawY - location[1]);
                View ripple = new View(MainActivity.this); ripple.setBackgroundColor(Color.parseColor("#20000000")); ripple.setVisibility(View.INVISIBLE); parent.addView(ripple, new ViewGroup.LayoutParams(-1, -1));
                float radius = (float) Math.hypot(Math.max(centerX, parent.getWidth() - centerX), Math.max(centerY, parent.getHeight() - centerY)); Animator reveal = ViewAnimationUtils.createCircularReveal(ripple, centerX, centerY, 0, radius); reveal.setDuration(350); ripple.setVisibility(View.VISIBLE); reveal.start();
                reveal.addListener(new AnimatorListenerAdapter() { @Override public void onAnimationEnd(Animator animation) { parent.removeView(ripple); openEditor(); } });
            };
            @Override public boolean onTouch(View v, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN: triggered = false; startX = event.getX(); startY = event.getY(); rawX = event.getRawX(); rawY = event.getRawY(); AppExecutors.MAIN.removeCallbacks(longPress); AppExecutors.MAIN.postDelayed(longPress, 600); break;
                    case MotionEvent.ACTION_MOVE: if (!triggered && (Math.abs(event.getX() - startX) > 20 || Math.abs(event.getY() - startY) > 20)) AppExecutors.MAIN.removeCallbacks(longPress); break;
                    case MotionEvent.ACTION_UP: case MotionEvent.ACTION_CANCEL: AppExecutors.MAIN.removeCallbacks(longPress); if (triggered) return true;
                }
                return false;
            }
        });
    }

    private void openEditor() {
        originalIsManuallyEdited = isManuallyEditedOut; if (isManuallyEditedOut) lastEditorSpannable = new SpannableStringBuilder(outputText.getText()); if (lastEditorSpannable == null) return;
        originalEditorText = lastEditorSpannable.toString(); isEditorSelfModifying = true; expandedEditText.setText(lastEditorSpannable); isEditorSelfModifying = false; editorUndoStack.clear(); editorRedoStack.clear(); firstEditorCursorTapPending = true; drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED);
        expandedEditorOverlay.setAlpha(0); expandedEditorOverlay.setTranslationY(150); expandedEditorOverlay.setVisibility(View.VISIBLE); expandedEditorOverlay.animate().alpha(1).translationY(0).setDuration(250).start(); Toast.makeText(this, "进入编辑模式：波浪线为系统或你修改过的文字。", Toast.LENGTH_SHORT).show(); isEditorOpen = true;
    }

    private void applyEditorChanges() {
        if (!expandedEditText.getText().toString().equals(originalEditorText)) {
            isManuallyEditedOut = true; SpannableStringBuilder snapshot = new SpannableStringBuilder(expandedEditText.getText()); outputText.setText(snapshot);
            if (lastSavedHistoryFileId != null) { HistoryStore.saveManual(this, lastSavedHistoryFileId, snapshot); saveHistory(extractCleanTextFromSpanned(snapshot), lastSavedHistoryFileId); }
        }
        closeEditor();
    }

    private void closeEditor() {
        firstEditorCursorTapPending = false;
        expandedEditorOverlay.animate().alpha(0).translationY(150).setDuration(250).withEndAction(() -> { expandedEditorOverlay.setVisibility(View.GONE); drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED); isEditorOpen = false; }).start();
    }

    private void applyIndent() {
        Editable editable = expandedEditText.getText(); if (editable == null || editable.length() == 0) return;
        pushState(editorUndoStack, new EditorState(new SpannableStringBuilder(editable), expandedEditText.getSelectionStart())); String text = editable.toString(); List<int[]> replacements = new ArrayList<>();
        int contentStart = 0, index = text.indexOf("【修正后的全文】\n"); if (index >= 0) contentStart = index + 9; else { index = text.indexOf("【原文】\n"); if (index >= 0) contentStart = index + 5; }
        int lineStart = contentStart;
        while (lineStart < text.length()) {
            int lineEnd = text.indexOf('\n', lineStart); if (lineEnd < 0) lineEnd = text.length(); String line = text.substring(lineStart, lineEnd).trim();
            if (!(line.startsWith("［文档") && line.endsWith("］"))) { int first = lineStart; while (first < lineEnd && (text.charAt(first) == ' ' || text.charAt(first) == '\t' || text.charAt(first) == '\u3000')) first++; if (first <= lineEnd) replacements.add(new int[]{lineStart, first}); }
            lineStart = lineEnd + 1;
        }
        isEditorSelfModifying = true;
        for (int i = replacements.size() - 1; i >= 0; i--) { int[] range = replacements.get(i); if (range[0] == range[1] && range[0] < editable.length() && editable.charAt(range[0]) == '\n') continue; editable.replace(range[0], range[1], range[0] == range[1] && range[0] >= editable.length() ? "" : "　　"); }
        isEditorSelfModifying = false; Toast.makeText(this, "已添加首行缩进", Toast.LENGTH_SHORT).show();
    }

    private void restoreEditorState(Stack<EditorState> source, Stack<EditorState> destination, boolean undo) {
        if (source.isEmpty()) return; int scrollY = editorScrollView.getScrollY(); pushState(destination, new EditorState(new SpannableStringBuilder(expandedEditText.getText()), expandedEditText.getSelectionStart())); EditorState state = source.pop();
        isEditorSelfModifying = true; expandedEditText.setText(state.text); isEditorSelfModifying = false; expandedEditText.setSelection(Math.max(0, Math.min(state.selectionStart, expandedEditText.length()))); editorScrollView.post(() -> editorScrollView.scrollTo(0, Math.max(0, scrollY)));
        if (undo && state.text.toString().equals(originalEditorText)) { isManuallyEditedOut = originalIsManuallyEdited; if (!isManuallyEditedOut) { renderFinalBlocks(); isEditorSelfModifying = true; expandedEditText.setText(lastEditorSpannable); isEditorSelfModifying = false; } }
    }

    private void updateInputEditorWordCount() {
        if (tvInputEditorWordCount == null || expandedInputEditText == null) return;
        int withPunctuation = inputCounts.with;
        int withoutPunctuation = inputCounts.without;
        tvInputEditorWordCount.setText(withPunctuation + " ｜ " + withoutPunctuation + " 字");
    }

    private void setupInputEditor() {
        Button indent = findViewById(R.id.btnInputEditorIndent), undo = findViewById(R.id.btnInputEditorUndo), redo = findViewById(R.id.btnInputEditorRedo), done = findViewById(R.id.btnInputEditorDone);
        View inputTouch = findViewById(R.id.inputEditorScrollTouchArea);
        if (inputTouch != null) inputTouch.setOnTouchListener((v, event) -> {
            android.text.Layout layout = expandedInputEditText.getLayout();
            int contentHeight = layout == null ? expandedInputEditText.getHeight() : layout.getHeight() + expandedInputEditText.getTotalPaddingTop() + expandedInputEditText.getTotalPaddingBottom();
            int max = Math.max(0, contentHeight - expandedInputEditText.getHeight());
            if (max > 0 && v.getHeight() > 0) {
                float y = Math.max(0f, Math.min(event.getY(), v.getHeight()));
                expandedInputEditText.scrollTo(0, (int) (y / v.getHeight() * max));
            }
            return true;
        });
        inputCounts.reset(expandedInputEditText.getText());
        expandedInputEditText.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                inputCounts.before(s, start, count);
                if (isInputEditorSelfModifying) return;
                pushInputEdit(inputUndoStack, new InputEdit(s, start, count, after, expandedInputEditText.getSelectionStart())); inputRedoStack.clear();
            }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { inputCounts.after(s, before, count); }
            @Override public void afterTextChanged(Editable editable) {
                if (isInputEditorSelfModifying) return;
                updateInputEditorWordCount();
                inputEditorSyncDirty = true;
                inputSyncHandler.removeCallbacks(inputEditorSync); inputSyncHandler.postDelayed(inputEditorSync, 400);
                if (editable.length() > 0 && !currentIsFast) warmProEngineAsync(MainActivity.this);
            }
        });
        done.setOnClickListener(v -> closeInputEditor(true));
        indent.setOnClickListener(v -> applyInputIndent());
        undo.setOnClickListener(v -> restoreInputEditorState(inputUndoStack, inputRedoStack));
        redo.setOnClickListener(v -> { if (inputRedoStack.isEmpty()) Toast.makeText(this, "没有可还原的操作", Toast.LENGTH_SHORT).show(); else restoreInputEditorState(inputRedoStack, inputUndoStack); });
    }

    private void openInputEditor() {
        if (inputEditorOverlay == null || expandedInputEditText == null) return;
        inputSyncHandler.removeCallbacksAndMessages(null);
        originalInputEditorText = inputText.getText().toString();
        int selection = Math.max(0, Math.min(inputText.getSelectionStart(), originalInputEditorText.length()));
        isInputEditorSelfModifying = true; expandedInputEditText.setText(originalInputEditorText); expandedInputEditText.setSelection(selection); isInputEditorSelfModifying = false;
        inputUndoStack.clear(); inputRedoStack.clear(); updateInputEditorWordCount();
        drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED); inputEditorOverlay.setAlpha(0f); inputEditorOverlay.setTranslationY(100f); inputEditorOverlay.setVisibility(View.VISIBLE); inputEditorOverlay.animate().alpha(1f).translationY(0f).setDuration(180).start(); isInputEditorOpen = true;
        expandedInputEditText.requestFocus(); expandedInputEditText.post(() -> { android.view.inputmethod.InputMethodManager imm = (android.view.inputmethod.InputMethodManager) getSystemService(INPUT_METHOD_SERVICE); if (imm != null) imm.showSoftInput(expandedInputEditText, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT); });
    }

    private void closeInputEditor(boolean keepChanges) {
        if (!isInputEditorOpen || inputEditorOverlay == null) return;
        inputSyncHandler.removeCallbacksAndMessages(null); inputEditorSyncDirty = false; mainSyncDirty = false;
        if (keepChanges) {
            String value = expandedInputEditText.getText().toString(); int selection = Math.max(0, Math.min(expandedInputEditText.getSelectionStart(), value.length()));
            boolean old = isRestoringHistory; isRestoringHistory = true; inputText.setText(value); inputText.setSelection(Math.max(0, Math.min(selection, inputText.length()))); isRestoringHistory = old; sp.edit().putString("sync_text", value).apply();
        } else {
            sp.edit().putString("sync_text", originalInputEditorText).apply();
        }
        android.view.inputmethod.InputMethodManager imm = (android.view.inputmethod.InputMethodManager) getSystemService(INPUT_METHOD_SERVICE); if (imm != null) imm.hideSoftInputFromWindow(expandedInputEditText.getWindowToken(), 0);
        isInputEditorOpen = false;
        inputSyncHandler.removeCallbacksAndMessages(null); mainSyncDirty = false;
        inputEditorOverlay.animate().alpha(0f).translationY(100f).setDuration(160).withEndAction(() -> {
            inputEditorOverlay.setVisibility(View.GONE); drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED);
            inputUndoStack.clear(); inputRedoStack.clear(); originalInputEditorText = "";
            isInputEditorSelfModifying = true; expandedInputEditText.setText(""); isInputEditorSelfModifying = false;
        }).start();
    }

    private void confirmCloseInputEditor() {
        if (!isInputEditorOpen) return;
        String current = expandedInputEditText == null ? "" : expandedInputEditText.getText().toString();
        String original = originalInputEditorText == null ? "" : originalInputEditorText;
        // 原输入框为空时，没有旧内容需要保护：返回键直接保存当前输入，不再弹确认。
        if (original.isEmpty()) { closeInputEditor(true); return; }
        if (current.equals(original)) { closeInputEditor(false); return; }
        new android.app.AlertDialog.Builder(this)
                .setMessage("是否保存刚才的编辑操作？")
                .setPositiveButton("是", (dialog, which) -> closeInputEditor(true))
                .setNegativeButton("否", (dialog, which) -> closeInputEditor(false))
                .show();
    }

    private void applyInputIndent() {
        Editable editable = expandedInputEditText.getText(); if (editable == null || editable.length() == 0) return;
        String text = editable.toString(); String[] lines = text.split("\\n", -1); StringBuilder out = new StringBuilder(text.length() + lines.length * 2);
        for (int i = 0; i < lines.length; i++) { String line = lines[i]; int first = 0; while (first < line.length() && (line.charAt(first) == ' ' || line.charAt(first) == '\t' || line.charAt(first) == '\u3000')) first++; if (first < line.length()) out.append("　　").append(line.substring(first)); if (i + 1 < lines.length) out.append('\n'); }
        pushInputEdit(inputUndoStack, new InputEdit(editable, 0, editable.length(), out.length(), expandedInputEditText.getSelectionStart())); inputRedoStack.clear();
        inputSyncHandler.removeCallbacks(inputEditorSync); inputEditorSyncDirty = false;
        isInputEditorSelfModifying = true; expandedInputEditText.setText(out.toString()); expandedInputEditText.setSelection(expandedInputEditText.length()); isInputEditorSelfModifying = false; updateInputEditorWordCount(); sp.edit().putString("sync_text", out.toString()).apply();
    }

    private void restoreInputEditorState(Stack<InputEdit> source, Stack<InputEdit> destination) {
        if (source.isEmpty()) return;
        Editable text = expandedInputEditText.getText(); InputEdit edit = source.pop();
        pushInputEdit(destination, new InputEdit(text, edit.start, edit.insertedLength, edit.removed.length(), expandedInputEditText.getSelectionStart()));
        isInputEditorSelfModifying = true;
        text.replace(edit.start, edit.start + edit.insertedLength, edit.removed);
        expandedInputEditText.setSelection(Math.max(0, Math.min(edit.selectionStart, expandedInputEditText.length())));
        isInputEditorSelfModifying = false; updateInputEditorWordCount();
        inputSyncHandler.removeCallbacks(inputEditorSync); inputEditorSyncDirty = true; inputEditorSync.run();
    }

    private void setupInputWatcher() {
        inputText.addTextChangedListener(new TextWatcher() {
            int visibleCount = countLettersOrDigits(inputText.getText(), 0, inputText.length());
            int removedCount;
            final Runnable update = () -> {
                String value = inputText.getText().toString();
                sp.edit().putString("sync_text", value).apply(); mainSyncDirty = false;
            };

            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                removedCount = countLettersOrDigits(s, start, start + count);
            }

            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                int addedCount = countLettersOrDigits(s, start, start + count);
                visibleCount = Math.max(0, visibleCount - removedCount + addedCount);
                if (count > 2 && !isRestoringHistory && !isCleanDialogOpen) {
                    String chunk = s.subSequence(start, start + count).toString();
                    if (hasSymbolBurst(chunk)) AppExecutors.MAIN.post(() -> checkAndPromptCleanup(MainActivity.this, inputText.getText().toString(), cleaned -> {
                        if (!cleaned.equals(inputText.getText().toString())) { boolean old = isRestoringHistory; isRestoringHistory = true; inputText.setText(cleaned); inputText.setSelection(cleaned.length()); sp.edit().putString("sync_text", cleaned).apply(); isRestoringHistory = old; }
                    }));
                }
            }

            @Override public void afterTextChanged(Editable editable) {
                btnSaveTxt.setEnabled(editable.length() > 0);
                if (!isRestoringHistory && "继续纠错".contentEquals(btnCheck.getText())) {
                    btnCheck.setText("开始纠错");
                    allSentencesBlocks.clear();
                    outputText.setText("");
                    btnCopy.setEnabled(false);
                    lastSavedHistoryFileId = null;
                    isManuallyEditedOut = false;
                    lastEditorSpannable = null;
                    currentClauseLinks.clear();
                }
                if (editable.length() > 0 && !currentIsFast) warmProEngineAsync(MainActivity.this);
                tvWordCount.setText(visibleCount + " 字"); mainSyncDirty = true;
                inputSyncHandler.removeCallbacks(update); inputSyncHandler.postDelayed(update, 400);
            }
        });
    }

    private static boolean ensureProEngineLoadedLocked(Context context) {
        try {
            Context appContext = context.getApplicationContext();
            loadIdlePolicy(appContext);
            if (!proVocabReady) loadCharVocab(appContext, proCharIds, "sys_vocab_p.dat");
            if (proModule == null) proModule = loadDecryptedModule(appContext, "sys_core_p.dat", "roformer_v2_executorch_xnnpack_v1", PRO_MODEL_LOCK);
            return proModule != null;
        } catch (Throwable error) {
            SecureAsset.recordError("RoFormerV2 ExecuTorch 专业模型加载失败", error);
            return false;
        }
    }

    private static void scheduleProEngineReleaseLocked() {
        PRO_MODEL_HANDLER.removeCallbacks(PRO_MODEL_RELEASE_TASK);
        if (proModuleUsers == 0 && proModule != null) PRO_MODEL_HANDLER.postDelayed(PRO_MODEL_RELEASE_TASK, PRO_IDLE.remaining(android.os.SystemClock.uptimeMillis()));
    }

    public static void warmProEngineAsync(Context context) {
        if (context == null) return;
        PRO_IDLE.activity(android.os.SystemClock.uptimeMillis());
        if (proModule != null) return;
        if (!proWarmQueued.compareAndSet(false, true)) return;
        Context appContext = context.getApplicationContext();
        AppExecutors.INFERENCE.execute(() -> {
            try { synchronized (PRO_MODEL_LOCK) { ensureProEngineLoadedLocked(appContext); scheduleProEngineReleaseLocked(); } }
            finally { proWarmQueued.set(false); }
        });
    }

    public static void noteProCorrectionStart(Context context) {
        if (context == null) return;
        loadIdlePolicy(context.getApplicationContext());
        boolean adjusted = PRO_IDLE.correctionStarted(android.os.SystemClock.uptimeMillis());
        if (adjusted) persistIdlePolicy();
    }

    public static boolean acquireProEngine(Context context) {
        loadIdlePolicy(context.getApplicationContext());
        PRO_IDLE.activity(android.os.SystemClock.uptimeMillis());
        synchronized (PRO_MODEL_LOCK) {
            PRO_MODEL_HANDLER.removeCallbacks(PRO_MODEL_RELEASE_TASK);
            if (!ensureProEngineLoadedLocked(context)) return false;
            proModuleUsers++;
            return true;
        }
    }

    public static void releaseProEngine() {
        synchronized (PRO_MODEL_LOCK) {
            if (proModuleUsers > 0) proModuleUsers--;
            PRO_IDLE.correctionFinished(android.os.SystemClock.uptimeMillis());
            persistIdlePolicy();
            scheduleProEngineReleaseLocked();
        }
    }

    private static void releaseProEngineNowIfIdle() {
        synchronized (PRO_MODEL_LOCK) {
            if (proModuleUsers != 0 || proModule == null) return;
            persistIdlePolicy();
            long remaining = PRO_IDLE.remaining(android.os.SystemClock.uptimeMillis());
            if (remaining > 0) { PRO_MODEL_HANDLER.postDelayed(PRO_MODEL_RELEASE_TASK, remaining); return; }
            Module module = proModule;
            proModule = null;
            try {
                module.close();
                android.util.Log.i("DedediModel", "专业模型空闲，已释放 Native Module 内存；当前等待 " + (PRO_IDLE.timeout() / 1000) + " 秒");
            } catch (Throwable error) {
                SecureAsset.recordError("RoFormerV2 ExecuTorch 专业模型释放失败", error);
            } finally {
                File plain = proPlainModelFile;
                proPlainModelFile = null;
                if (plain != null && plain.exists() && !plain.delete()) {
                    android.util.Log.w("DedediModel", "临时明文模型删除失败，将在后续启动时再次清理：" + plain);
                }
            }
        }
    }

    private void showHelp() {
        String text = "【模式介绍】\n极速：纠错时不调用神经网络推理，因此不检查“的/地/得”；仅运行系统内置的错词库和规则。速度最快（毫秒级），适合只想快速检查其他错别字与语病的场景。\n\n专业（RoFormerV2）：专门纠错“的地得”，推理速度依然很快，只是相比极速会慢一点（秒级）。\n两种模式都支持系统内置的所有纠错规则。\n注：不同手机的速度会有差异；模型也可能出现极少量误判，这是神经网络的通病，在所难免。\n\n一般建议始终使用专业模式，除非你对“的地得”运用得如火纯青。\n\n【温度参数（仅专业模式）】\n控制AI判断的自信（果断）程度。\n举例：温度调到0.8时，AI通常更敢改；调到1.5时，AI通常会更保守。\n• 允许范围：0.5～2.0；默认1.2。\n• 值越低（如0.5）：概率分布越尖锐，模型更激进，修改量可能上升。\n• 值越高（如2.0）：概率分布越平缓，模型更保守，修改量可能下降。\n• 温度低于0.5或高于2.0时系统会禁止纠错。\n\n【置信度拦截阈值（仅专业模式）】\n只有AI的置信度 ≥ 阈值时才修改，否则保留原字，防止过度纠错。\n• 默认值：的0.76、地0.74、得0.78。\n举例：设置为0.9时，模型修改的置信度超过0.9才会被保留，否则忽略。\n\n【交互与拓展功能】\n• 手动修改：检查完毕后，点击任意带下划线的字或词组，即可手动修改或还原回原字。\n• 输入框展开：点击输入框右上角的展开按钮，可进入全屏输入编辑，支持可拖动滚动条、撤销、还原和首行缩进；完成后内容会自动同步回主输入框。\n• 便签模式：长按底部纠错结果区域，即可展开便签编辑器进行全局修改，完成后支持直接导出。绿色的波浪线为系统或你修改过的文本（原在输出框中呈现红色）。\n• 界面皮肤：点击标题栏“A”进入字体设置，底部彩色衣服可直接切换界面皮肤。\n• 快速跳转：点击纠错清单中的序号 [1]，可以自动滚动定位至全文对应段落。\n• 一键粘贴：点击按钮快速读取剪贴板内容。（不建议一次性粘贴超过20万字，可能会导致闪退）\n• 导入文件：支持txt、md、docx、pdf及图片格式(支持直接OCR识图)。\n  不建议一次导入多个过大的文件，这可能会导致使用卡顿。也不建议导入带有特定格式（如表格类）的文件，会破坏原有排版。\n\n• 系统分享：在其他App中选中文本，点击分享并选择本App，即可自动带入进行纠错。\n• 历史记录：最多保存近50条。\n\n 【错词库】\n  手动定义规则，这些规则会在纠错中自动应用。\n  使用方法：1.在“原始文本”框输入例如“慢慢地”，直接提交。等效于白名单，系统在遇到该词后不会再修改。\n  2.在“修改后”里再添加文本（如：慢慢的），纠错时原始文本就会被自动修改。\n• 自定义规则优先级高于内置规则和专业模型。\n\n【悬浮窗】\n开启后支持后台随时随地纠错。长按悬浮球或点击面板右上角可同步至应用内继续操作。点击面板外可自动收起。\n\n【标点清理：】\n  当检测到包含复制残留的垃圾标点时会触发弹窗，允许自由清理提纯文本。\n\n• 其他：本App和模型均由 奇 制作与训练。免费使用。想与作者私聊？公众号搜索：Li的信箱";
        int ui = Math.max(-2, Math.min(2, sp.getInt("font_offset_sys", 0))); TextView view = new TextView(this); view.setText(text); view.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 14 + ui); view.setTextColor(0xFF333333); view.setLineSpacing(0, 1.2f); int padding = (int) (20 * getResources().getDisplayMetrics().density); view.setPadding(padding, padding / 2, padding, 0); ScrollView scroll = new ScrollView(this); scroll.addView(view); new AlertDialog.Builder(this).setTitle("使用说明").setView(scroll).setPositiveButton("知道了", null).show();
    }

    private void setupMainButtons() {
        btnImport.setOnClickListener(v -> { Toast.makeText(this, "支持 txt、md、docx、pptx、pdf 及各种图片格式。（最多上传20个）", Toast.LENGTH_SHORT).show(); openFilePicker(); });
        btnPaste.setOnClickListener(v -> {
            ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (clipboard != null && clipboard.hasPrimaryClip() && clipboard.getPrimaryClip().getItemCount() > 0) { CharSequence value = clipboard.getPrimaryClip().getItemAt(0).getText(); if (value != null) checkAndPromptCleanup(this, value.toString(), cleaned -> { lastSavedHistoryFileId = null; inputText.setText(cleaned); sp.edit().putString("sync_text", cleaned).apply(); }); }
        });
        btnClear.setOnClickListener(v -> { cancelMainCheck(); lastSavedHistoryFileId = null; inputText.setText(""); allSentencesBlocks.clear(); outputText.setText(""); isManuallyEditedOut = false; btnCopy.setEnabled(false); btnSaveTxt.setEnabled(false); isCheckingMain = false; });
        btnCheck.setOnClickListener(v -> {
            InputMethodManager manager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE); if (manager != null) manager.hideSoftInputFromWindow(v.getWindowToken(), 0);
            if (isCheckingMain) { cancelMainCheck(); return; }
            Runnable execute = () -> beginCheck();
            if (isManuallyEditedOut) {
                CharSequence displayed = outputText.getText();
                String editedText = displayed instanceof Spanned ? extractCleanTextFromSpanned((Spanned) displayed) : displayed.toString();
                if (editedText.trim().isEmpty()) {
                    isManuallyEditedOut = false;
                    execute.run();
                } else {
                    new AlertDialog.Builder(this).setMessage("是否使用编辑后的文本继续纠错？\n（否则用原始文本）")
                            .setPositiveButton("是", (d, w) -> { inputText.setText(editedText); execute.run(); })
                            .setNegativeButton("否", (d, w) -> execute.run())
                            .show();
                }
            } else execute.run();
        });
        btnCopy.setOnClickListener(v -> {
            String value = isManuallyEditedOut ? extractCleanTextFromSpanned((Spanned) outputText.getText()) : getCleanTextStatic(); if (value.isEmpty()) return;
            ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE); if (clipboard != null) clipboard.setPrimaryClip(ClipData.newPlainText("Corrected Article", value)); Toast.makeText(this, "已复制修正后的全文。", Toast.LENGTH_SHORT).show();
        });
        btnSaveTxt.setOnClickListener(v -> chooseSaveFormat());
    }

    private void beginCheck() {
        autoScrollEnabled = true;
        isManuallyEditedOut = false;

        boolean fast = rbFast.isChecked();
        float temperature = 1f;
        if (!fast) {
            temperature = parseFloatSafe(editTemp.getText().toString(), Float.NaN);
            if (!isTemperatureValid(temperature)) {
                temperature = 1.2f;
                editTemp.setText("1.2");
                sp.edit().putString("pro_temp", "1.2").apply();
                Toast.makeText(this, "温度参数无效，已自动恢复为1.2（允许范围0.5～2.0）", Toast.LENGTH_LONG).show();
            }
        }
        saveSettings(currentIsFast);

        String raw = inputText.getText().toString();
        if (raw.isEmpty()) return;

        hasStartedChecking = true;
        if (lastSavedHistoryFileId == null) lastSavedHistoryFileId = java.util.UUID.randomUUID().toString();
        saveHistory(raw, lastSavedHistoryFileId);
        isCheckingMain = true;
        btnCheck.setText("取消");
        doInference(fast, temperature);
    }

    private void chooseSaveFormat() {
        String raw = inputText.getText().toString(); if (raw.isEmpty()) return;
        String[] options = {"TXT 纯文本", "MD 文档", "PDF 文档", "DOCX 文档", "JPG 图片", "PNG 图片"};
        new AlertDialog.Builder(this).setTitle("选择保存格式").setItems(options, (dialog, which) -> {
            saveFormat = which; String text = isManuallyEditedOut ? extractCleanTextFromSpanned((Spanned) outputText.getText()) : getCleanTextStatic(); boolean corrected = false;
            if (text.isEmpty()) { text = raw; Toast.makeText(this, "未开始纠错，将保存原始文本为" + options[which].split(" ")[0] + "格式", Toast.LENGTH_LONG).show(); }
            else if (isManuallyEditedOut) corrected = true; else outer: for (List<TextBlock> sentence : allSentencesBlocks) for (TextBlock block : sentence) if (block.isMutable && !block.current.equals(block.original)) { corrected = true; break outer; }
            pendingSaveText = text; Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT); intent.addCategory(Intent.CATEGORY_OPENABLE); String name = corrected ? "纠错结果" : "原始文本";
            if (which == 0) { intent.setType("text/plain"); intent.putExtra(Intent.EXTRA_TITLE, name + ".txt"); } else if (which == 1) { intent.setType("text/markdown"); intent.putExtra(Intent.EXTRA_TITLE, name + ".md"); } else if (which == 2) { intent.setType("application/pdf"); intent.putExtra(Intent.EXTRA_TITLE, name + ".pdf"); } else if (which == 3) { intent.setType("application/vnd.openxmlformats-officedocument.wordprocessingml.document"); intent.putExtra(Intent.EXTRA_TITLE, name + ".docx"); } else if (which == 4) { intent.setType("image/jpeg"); intent.putExtra(Intent.EXTRA_TITLE, name + ".jpg"); } else { intent.setType("image/png"); intent.putExtra(Intent.EXTRA_TITLE, name + ".png"); }
            try { startActivityForResult(intent, 101); } catch (Exception exception) { Toast.makeText(this, "调起失败: " + exception.getMessage(), Toast.LENGTH_SHORT).show(); }
        }).show();
    }

    private void setupDrawerButtons() {
        Button add = findViewById(R.id.btnAddTypo); EditText original = findViewById(R.id.etOriginal), corrected = findViewById(R.id.etCorrected);
        add.setOnClickListener(v -> {
            String source = original.getText().toString().trim(), target = corrected.getText().toString().trim(); if (source.isEmpty()) { Toast.makeText(this, "原始文本不能为空", Toast.LENGTH_SHORT).show(); return; } if (target.isEmpty()) target = source;
            try {
                JSONObject object = new JSONObject(sp.getString("custom_typos", "{}")); if (editingTypoKey != null && !editingTypoKey.equals(source)) object.remove(editingTypoKey); object.put(source, target); sp.edit().putString("custom_typos", object.toString()).apply(); reloadTypoMapAsync(this); renderCustomTyposUI(); original.setText(""); corrected.setText(""); editingTypoKey = null; add.setText("添加"); Toast.makeText(this, "保存成功", Toast.LENGTH_SHORT).show();
            } catch (Exception ignored) {}
        });
        findViewById(R.id.btnClearHistory).setOnClickListener(v -> new AlertDialog.Builder(this).setMessage("是否清空全部历史记录？").setPositiveButton("是", (d, w) -> {
            HistoryStore.clear(this); sp.edit().putString("history_records", "[]").apply(); lastSavedHistoryFileId = null; isManuallyEditedOut = false; boolean old = isRestoringHistory; isRestoringHistory = true; inputText.setText(""); isRestoringHistory = old; allSentencesBlocks.clear(); outputText.setText(""); btnCheck.setText("开始纠错"); btnCopy.setEnabled(false); btnSaveTxt.setEnabled(false); renderHistoryUI(); Toast.makeText(this, "历史记录已全部清空", Toast.LENGTH_SHORT).show();
        }).setNegativeButton("否", null).show());
    }

    private void renderCustomTyposUI() {
        FlowLayout container = findViewById(R.id.llCustomTypos); Button expand = findViewById(R.id.btnExpandTypos), add = findViewById(R.id.btnAddTypo); EditText original = findViewById(R.id.etOriginal), corrected = findViewById(R.id.etCorrected); container.removeAllViews();
        try {
            JSONObject object = new JSONObject(sp.getString("custom_typos", "{}")); Iterator<String> keys = object.keys(); List<String[]> items = new ArrayList<>(); while (keys.hasNext()) { String key = keys.next(); items.add(new String[]{key, object.getString(key)}); }
            int count = isTyposExpanded ? items.size() : Math.min(items.size(), 15);
            for (int i = 0; i < count; i++) {
                String[] item = items.get(i); TextView view = new TextView(this); view.setText(item[0].equals(item[1]) ? item[0] : item[0] + " → " + item[1]); view.setPadding(16, 16, 16, 16); view.setTextSize(14f); view.setTextColor(0xFF4CAF50); view.setBackgroundResource(R.drawable.item_bg_selector); view.setClickable(true);
                view.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("操作错词").setMessage("原始：" + item[0] + "\n修改后：" + (item[0].equals(item[1]) ? "（保持不变）" : item[1])).setPositiveButton("删除", (d, w) -> { object.remove(item[0]); sp.edit().putString("custom_typos", object.toString()).apply(); reloadTypoMapAsync(this); renderCustomTyposUI(); }).setNeutralButton("编辑", (d, w) -> { editingTypoKey = item[0]; original.setText(item[0]); corrected.setText(item[0].equals(item[1]) ? "" : item[1]); add.setText("完成"); }).setNegativeButton("取消", null).show());
                container.addView(view);
            }
            if (items.size() > 15) { expand.setVisibility(View.VISIBLE); expand.setText(isTyposExpanded ? "折叠" : "展开全部"); expand.setOnClickListener(v -> { isTyposExpanded = !isTyposExpanded; renderCustomTyposUI(); }); } else expand.setVisibility(View.GONE);
        } catch (Exception ignored) {}
    }

    private void renderHistoryUI() {
        LinearLayout container = findViewById(R.id.llHistory); if (container == null) return; container.removeAllViews();
        try {
            JSONArray records = new JSONArray(sp.getString("history_records", "[]"));
            for (int i = 0; i < records.length(); i++) {
                JSONObject record = records.getJSONObject(i); String time = record.optString("time", ""), preview = record.optString("preview", ""), fileId = record.optString("file", record.optString("fileName", ""));
                if (preview.isEmpty() && record.has("text")) { String raw = record.optString("text", ""); preview = raw.length() > 16 ? raw.substring(0, 16).replace("\n", " ") + "..." : raw.replace("\n", " "); }
                if (preview.length() > 16) preview = preview.substring(0, 16) + "...";
                LinearLayout item = new LinearLayout(this); item.setOrientation(LinearLayout.VERTICAL); item.setPadding(0, 24, 0, 24); item.setBackgroundResource(R.drawable.item_bg_selector); item.setClickable(true);
                TextView timeView = new TextView(this); timeView.setText(time); timeView.setTextSize(12f); timeView.setTextColor(0xFF9E9E9E); TextView previewView = new TextView(this); previewView.setText(preview); previewView.setTextSize(14f); item.addView(timeView); item.addView(previewView);
                item.setOnClickListener(v -> restoreHistory(record, fileId)); int index = i;
                item.setOnLongClickListener(v -> { new AlertDialog.Builder(this).setMessage("确认删除这条历史记录吗？").setPositiveButton("删除", (d, w) -> deleteHistoryRecord(records, index, fileId)).setNegativeButton("取消", null).show(); return true; });
                container.addView(item);
                if (i < records.length() - 1) { View line = new View(this); line.setLayoutParams(new LinearLayout.LayoutParams(-1, 1)); line.setBackgroundColor(0xFFE0E0E0); container.addView(line); }
            }
        } catch (Exception ignored) {}
    }

    private void restoreHistory(JSONObject record, String fileId) {
        drawerLayout.closeDrawer(GravityCompat.END); progressBar.setVisibility(View.VISIBLE); progressBar.setIndeterminate(true);
        AppExecutors.IO.execute(() -> {
            File directory = new File(getFilesDir(), "history"); String full = fileId.isEmpty() ? record.optString("text", "") : HistoryStore.readUtf8(new File(directory, fileId + ".txt")); String blocks = fileId.isEmpty() ? "" : HistoryStore.readUtf8(new File(directory, fileId + "_blocks.json")); String manual = fileId.isEmpty() ? "" : HistoryStore.readUtf8(new File(directory, fileId + "_manual.json"));
            SpannableStringBuilder restored = manual.isEmpty() ? null : deserializeSpannable(manual);
            List<List<TextBlock>> restoredBlocks = blocks.isEmpty() ? null : deserializeBlocks(blocks);
            AppExecutors.MAIN.post(() -> {
                if (isFinishing() || isDestroyed()) return;
                isRestoringHistory = true; inputText.setText(full); isRestoringHistory = false; lastSavedHistoryFileId = fileId;
                if (!manual.isEmpty()) {
                    if (restored != null) { isManuallyEditedOut = true; outputText.setText(restored); outputText.setMovementMethod(MyLinkMovementMethod.getInstance()); outputText.setHighlightColor(Color.TRANSPARENT); btnCheck.setText("继续纠错"); btnCopy.setEnabled(true); btnSaveTxt.setEnabled(true); }
                } else if (!blocks.isEmpty()) {
                    isManuallyEditedOut = false; allSentencesBlocks = restoredBlocks; lastTimeMs = 0; renderFinalBlocks(); btnCheck.setText("继续纠错"); btnCopy.setEnabled(true); btnSaveTxt.setEnabled(true);
                } else { isManuallyEditedOut = false; allSentencesBlocks.clear(); outputText.setText(""); btnCheck.setText("开始纠错"); }
                progressBar.setVisibility(View.INVISIBLE); progressBar.setIndeterminate(false);
            });
        });
    }

    private void deleteHistoryRecord(JSONArray records, int index, String fileId) {
        HistoryStore.deleteRecord(this, fileId);
        if (fileId.equals(lastSavedHistoryFileId)) { lastSavedHistoryFileId = null; isManuallyEditedOut = false; boolean old = isRestoringHistory; isRestoringHistory = true; inputText.setText(""); isRestoringHistory = old; allSentencesBlocks.clear(); outputText.setText(""); btnCheck.setText("开始纠错"); btnCopy.setEnabled(false); btnSaveTxt.setEnabled(false); Toast.makeText(this, "当前显示的历史记录已被删除", Toast.LENGTH_SHORT).show(); }
        records.remove(index); sp.edit().putString("history_records", records.toString()).apply(); renderHistoryUI();
    }

    @Override public void onBackPressed() {
        if (isInputEditorOpen && inputEditorOverlay != null && inputEditorOverlay.getVisibility() == View.VISIBLE) { confirmCloseInputEditor(); return; }
        if (isEditorOpen && expandedEditorOverlay != null
                && expandedEditorOverlay.getVisibility() == View.VISIBLE) {
            View closeButton = findViewById(R.id.btnEditorClose);
            if (closeButton != null) {
                closeButton.performClick();
                return;
            }
        }
        super.onBackPressed();
    }

    @Override protected void onPause() { flushInputSync(); super.onPause(); }

    @Override protected void onDestroy() {
        inputSyncHandler.removeCallbacksAndMessages(null);
        isCheckingMain = false; inferenceGeneration++;
        if (instance == this) instance = null;
        isEditorOpen = false; isInputEditorOpen = false;
        super.onDestroy();
    }

    public void onFloatResultReady() {
        if (!hasNewFloatResult || !isWaitingForFloatResult) return;
        hasNewFloatResult = false; isWaitingForFloatResult = false; isManuallyEditedOut = false; if (pendingFloatFileId != null) lastSavedHistoryFileId = pendingFloatFileId;
        allSentencesBlocks = new ArrayList<>(pendingFloatBlocks); lastTimeMs = pendingFloatTimeMs; pendingFloatBlocks = new ArrayList<>(); pendingFloatFileId = null;
        String sync = sp.getString("sync_text", ""); if (!sync.isEmpty() && !sync.equals(inputText.getText().toString())) { boolean old = isRestoringHistory; isRestoringHistory = true; inputText.setText(sync); isRestoringHistory = old; }
        renderFinalBlocks(); btnCopy.setEnabled(true); btnCheck.setEnabled(true); btnCheck.setText("继续纠错"); btnSaveTxt.setEnabled(true); scrollView.post(() -> scrollView.fullScroll(View.FOCUS_UP));
    }

    @Override protected void onResume() {
        super.onResume(); String sync = sp.getString("sync_text", ""); if (!sync.isEmpty() && !sync.equals(inputText.getText().toString())) { isRestoringHistory = true; inputText.setText(sync); isRestoringHistory = false; }
        boolean fast = sp.getBoolean("is_fast_mode", false); if (fast != currentIsFast || rgMode.getCheckedRadioButtonId() == -1) { currentIsFast = fast; rgMode.check(fast ? R.id.rbFast : R.id.rbPro); loadSettings(fast); }
        if (hasNewFloatResult && isWaitingForFloatResult) onFloatResultReady();
    }

    @Override protected void onNewIntent(Intent intent) { super.onNewIntent(intent); setIntent(intent); handleIntent(intent); }

    private void handleIntent(Intent intent) {
        if (intent == null) return;
        if (intent.getBooleanExtra("FROM_FLOAT_JUMP", false)) { isWaitingForFloatResult = true; if (hasNewFloatResult) onFloatResultReady(); }
        if (Intent.ACTION_SEND.equals(intent.getAction()) && intent.getType() != null) {
            if ("text/plain".equals(intent.getType())) {
                String text = intent.getStringExtra(Intent.EXTRA_TEXT); if (text != null) checkAndPromptCleanup(this, text, cleaned -> { lastSavedHistoryFileId = null; inputText.setText(cleaned); sp.edit().putString("sync_text", cleaned).apply(); });
            } else if (intent.getType().startsWith("image/")) {
                android.net.Uri uri = intent.getParcelableExtra(Intent.EXTRA_STREAM); if (uri != null) { Toast.makeText(this, "正在处理导入图片，请稍候...", Toast.LENGTH_SHORT).show(); extractTextFromUriAsync(this, uri, new TextExtractCallback() {
                    @Override public void onStart() { progressBar.setVisibility(View.VISIBLE); progressBar.setProgress(0); }
                    @Override public void onProgress(int progress, int max) { progressBar.setMax(max); progressBar.setProgress(progress); }
                    @Override public void onExtracted(String text) { progressBar.setVisibility(View.INVISIBLE); if (text != null && !text.trim().isEmpty()) checkAndPromptCleanup(MainActivity.this, text, cleaned -> { lastSavedHistoryFileId = null; inputText.setText(cleaned); sp.edit().putString("sync_text", cleaned).apply(); saveHistory(cleaned, null); }); else { String detail = getLastExtractError(); Toast.makeText(MainActivity.this, detail.isEmpty() ? "无法读取图片文字" : "识图失败：" + detail, Toast.LENGTH_LONG).show(); } }
                }); }
            }
        } else if (intent.hasExtra("SYNC_TEXT")) {
            String text = intent.getStringExtra("SYNC_TEXT"); if (text != null && !text.isEmpty()) { boolean old = isRestoringHistory; isRestoringHistory = true; inputText.setText(text); isRestoringHistory = old; sp.edit().putString("sync_text", text).apply(); }
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 201) {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M && android.provider.Settings.canDrawOverlays(this)) startFloatingService(); else Toast.makeText(this, "悬浮窗权限未被授予，无法开启", Toast.LENGTH_SHORT).show();
            return;
        }
        if (requestCode == 102 && resultCode == RESULT_OK && data != null) { importSelectedFiles(data); return; }
        if (requestCode == 101 && resultCode == RESULT_OK && data != null && data.getData() != null) saveSelectedDocument(data.getData());
    }

    private void importSelectedFiles(Intent data) {
        List<android.net.Uri> uris = new ArrayList<>();
        if (data.getClipData() != null) { int count = data.getClipData().getItemCount(), limit = Math.min(count, 20); for (int i = 0; i < limit; i++) uris.add(data.getClipData().getItemAt(i).getUri()); if (count > 20) Toast.makeText(this, "最多支持选择20个文件，已截断前20个", Toast.LENGTH_SHORT).show(); }
        else if (data.getData() != null) uris.add(data.getData());
        if (uris.isEmpty()) return;
        Toast.makeText(this, "正在处理导入文件，请稍候...", Toast.LENGTH_SHORT).show(); progressBar.setVisibility(View.VISIBLE); progressBar.setProgress(0);
        AppExecutors.IO.execute(() -> {
            StringBuilder combined = new StringBuilder();
            for (int i = 0; i < uris.size(); i++) {
                int fileIndex = i; String text = extractTextFromUriSync(this, uris.get(i), new TextExtractCallback() {
                    @Override public void onStart() {}
                    @Override public void onProgress(int progress, int max) { int overall = fileIndex * 100 / uris.size() + progress * 100 / Math.max(1, max) / uris.size(); AppExecutors.MAIN.post(() -> progressBar.setProgress(overall)); }
                    @Override public void onExtracted(String text) {}
                });
                if (text != null) combined.append(text); if (i < uris.size() - 1) combined.append("\n\n---------------------------------\n\n");
            }
            String finalText = combined.toString(); AppExecutors.MAIN.post(() -> {
                progressBar.setVisibility(View.INVISIBLE);
                if (!finalText.trim().isEmpty()) checkAndPromptCleanup(this, finalText, cleaned -> { lastSavedHistoryFileId = null; inputText.setText(cleaned); sp.edit().putString("sync_text", cleaned).apply(); saveHistory(cleaned, null); Toast.makeText(this, "导入成功", Toast.LENGTH_SHORT).show(); });
                else { String detail = getLastExtractError(); Toast.makeText(this, detail.isEmpty() ? "无法读取文件内容或未识别到文字" : "导入失败：" + detail, Toast.LENGTH_LONG).show(); }
            });
        });
    }

    private void saveSelectedDocument(android.net.Uri uri) {
        final int format = saveFormat; final String text = pendingSaveText;
        AppExecutors.IO.execute(() -> {
            boolean success = false;
            try (OutputStream output = getContentResolver().openOutputStream(uri)) {
                if (output == null) return;
                if (format == 0 || format == 1) output.write(text.getBytes(StandardCharsets.UTF_8));
                else if (format == 2) writePdf(output, text);
                else if (format == 3) writeDocx(output, text);
                else writeImage(output, text, format == 4);
                success = true;
            } catch (Exception ignored) {}
            boolean saved = success;
            AppExecutors.MAIN.post(() -> Toast.makeText(this, saved ? "保存成功" : "保存过程出现错误", Toast.LENGTH_SHORT).show());
        });
    }

    private void writePdf(OutputStream output, String text) throws Exception {
        android.graphics.pdf.PdfDocument document = new android.graphics.pdf.PdfDocument(); android.text.TextPaint paint = new android.text.TextPaint(android.graphics.Paint.ANTI_ALIAS_FLAG); paint.setTextSize(14); paint.setColor(Color.BLACK);
        int pageWidth = 595, pageHeight = 842, margin = 24, contentWidth = pageWidth - margin * 2, contentHeight = pageHeight - margin * 2;
        android.text.StaticLayout full = new android.text.StaticLayout(text, paint, contentWidth, Layout.Alignment.ALIGN_NORMAL, 1.5f, 0, false);
        int firstLine = 0, pageNumber = 1;
        while (firstLine < full.getLineCount()) {
            int lastLine = firstLine;
            while (lastLine + 1 < full.getLineCount() && full.getLineBottom(lastLine + 1) - full.getLineTop(firstLine) <= contentHeight) lastLine++;
            int start = full.getLineStart(firstLine), end = full.getLineEnd(lastLine); CharSequence pageText = text.subSequence(start, end);
            android.text.StaticLayout pageLayout = new android.text.StaticLayout(pageText, paint, contentWidth, Layout.Alignment.ALIGN_NORMAL, 1.5f, 0, false);
            android.graphics.pdf.PdfDocument.Page page = document.startPage(new android.graphics.pdf.PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber++).create()); page.getCanvas().translate(margin, margin); pageLayout.draw(page.getCanvas()); document.finishPage(page); firstLine = lastLine + 1;
        }
        document.writeTo(output); document.close();
    }

    private void writeDocx(OutputStream output, String text) throws Exception {
        try (java.util.zip.ZipOutputStream zip = new java.util.zip.ZipOutputStream(output)) {
            zip.putNextEntry(new java.util.zip.ZipEntry("[Content_Types].xml")); zip.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/></Types>".getBytes(StandardCharsets.UTF_8)); zip.closeEntry();
            zip.putNextEntry(new java.util.zip.ZipEntry("_rels/.rels")); zip.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/></Relationships>".getBytes(StandardCharsets.UTF_8)); zip.closeEntry();
            zip.putNextEntry(new java.util.zip.ZipEntry("word/document.xml")); String safe = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"); StringBuilder xml = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?><w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:body>"); for (String paragraph : safe.split("\n", -1)) xml.append("<w:p><w:r><w:t xml:space=\"preserve\">").append(paragraph).append("</w:t></w:r></w:p>"); xml.append("</w:body></w:document>"); zip.write(xml.toString().getBytes(StandardCharsets.UTF_8)); zip.closeEntry();
        }
    }

    private void writeImage(OutputStream output, String text, boolean jpeg) {
        android.text.TextPaint paint = new android.text.TextPaint(android.graphics.Paint.ANTI_ALIAS_FLAG); paint.setTextSize(40); paint.setColor(Color.BLACK); String value = text.isEmpty() ? "无内容" : text;
        android.text.StaticLayout layout = new android.text.StaticLayout(value, paint, 1000, Layout.Alignment.ALIGN_NORMAL, 1.5f, 0, false); int height = Math.max(80, layout.getHeight() + 80);
        if (height > 30000) throw new IllegalArgumentException("文本过长，无法保存为单张图片，请改用 PDF 或 DOCX");
        Bitmap bitmap = Bitmap.createBitmap(1080, height, Bitmap.Config.ARGB_8888);
        try { android.graphics.Canvas canvas = new android.graphics.Canvas(bitmap); canvas.drawColor(Color.WHITE); canvas.translate(40, 40); layout.draw(canvas); bitmap.compress(jpeg ? Bitmap.CompressFormat.JPEG : Bitmap.CompressFormat.PNG, jpeg ? 90 : 100, output); }
        finally { bitmap.recycle(); }
    }

    private void cancelMainCheck() {
        isCheckingMain = false; inferenceGeneration++;
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        progressBar.setVisibility(View.INVISIBLE); btnCheck.setText("开始纠错"); btnCheck.setEnabled(true);
        outputText.setText("已取消纠错。"); btnSaveTxt.setEnabled(inputText.length() > 0);
    }

    private void doInference(boolean fastMode, float temperature) {
        String text = inputText.getText().toString(); if (text.isEmpty()) { isCheckingMain = false; btnCheck.setText("开始纠错"); return; }
        final long generation = ++inferenceGeneration;
        final String historyFileId = lastSavedHistoryFileId;
        final AtomicBoolean previewPending = new AtomicBoolean();
        btnCopy.setEnabled(false); btnSaveTxt.setEnabled(false);
        float thresholdDe = parseFloatSafe(editThreshDe1.getText().toString(), .76f), thresholdDi = parseFloatSafe(editThreshDe2.getText().toString(), .74f), thresholdDe3 = parseFloatSafe(editThreshDe3.getText().toString(), .78f);
        if (!fastMode) noteProCorrectionStart(this);
        AppExecutors.INFERENCE.execute(() -> {
            if (generation != inferenceGeneration || isDestroyed()) return;
            boolean proAcquired = false;
            try {
                AppExecutors.MAIN.post(() -> { if (generation != inferenceGeneration || isDestroyed()) return; getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); progressBar.setVisibility(View.VISIBLE); progressBar.setProgress(0); });
                if (!fastMode) {
                    proAcquired = acquireProEngine(this);
                    if (!proAcquired) throw new IllegalStateException("专业 RoFormerV2 模型加载失败：" + SecureAsset.lastErrorSummary());
                }
                StringBuilder liveErrors = new StringBuilder(), liveText = new StringBuilder(text.length() + 100); int[] processed = {0}, liveErrorCount = {0}, docIndex = {1}; boolean multiDocument = text.contains("---------------------------------"); boolean[] markerPending = {multiDocument};
                CorrectionCore.Result result = CorrectionCore.run(text, fastMode, temperature, thresholdDe, thresholdDi, thresholdDe3, new CorrectionCore.Listener() {
                    @Override public boolean isCancelled() { return !isCheckingMain || generation != inferenceGeneration || isFinishing() || isDestroyed(); }
                    @Override public void onError(String message, boolean minimumDisplay) {}
                    @Override public void onProgress(int current, int total, List<List<TextBlock>> completed, int errors, long elapsed) {
                        while (processed[0] < completed.size()) {
                            List<TextBlock> sentence = completed.get(processed[0]++);
                            appendLiveErrors(sentence, liveErrors, liveErrorCount);
                            for (TextBlock block : sentence) {
                                if (markerPending[0] && docIndex[0] == 1) { liveText.append("<font color='#757575'>［文档").append(docIndex[0]++).append("］</font><br>"); markerPending[0] = false; }
                                appendLiveHtmlText(liveText, block.current);
                                if (block.current.contains("---------------------------------")) liveText.append("<br><font color='#757575'>［文档").append(docIndex[0]++).append("］</font><br>");
                            }
                        }
                        if (!previewPending.compareAndSet(false, true)) return;
                        StringBuilder htmlBuilder = new StringBuilder(liveErrors.length() + liveText.length() + 256).append("<b>AI 正在审查中...</b><br>已耗时 ").append(String.format(Locale.getDefault(), "%.1f", elapsed / 1000.0)).append(" 秒<br>进度：").append(current).append(" / ").append(total).append("<br><br>");
                        if (liveErrors.length() > 0) htmlBuilder.append("<b><font color='#757575'>【发现错误】：</font></b><br>").append(liveErrors);
                        String html = htmlBuilder.append("<br><b><font color='#757575'>【全文预览】：</font></b><br>").append(liveText).toString();
                        Spanned preview = Html.fromHtml(html, Html.FROM_HTML_MODE_COMPACT);
                        final int displayedErrors = liveErrorCount[0];
                        AppExecutors.MAIN.post(() -> {
                            previewPending.set(false);
                            if (!isCheckingMain || generation != inferenceGeneration || isFinishing() || isDestroyed()) return; progressBar.setMax(total); progressBar.setProgress(current); outputText.setText(preview);
                            if (autoScrollEnabled) scrollView.post(() -> { if (generation != inferenceGeneration || isDestroyed()) return; if (displayedErrors > 0) { Layout layout = outputText.getLayout(); int offset = outputText.getText().toString().indexOf("【发现错误】："); if (layout != null && offset >= 0) scrollView.scrollTo(0, Math.max(0, layout.getLineTop(layout.getLineForOffset(offset)) - scrollView.getHeight() + 150)); } else scrollView.scrollTo(0, 0); });
                        });
                    }
                });
                if (result == null) {
                    AppExecutors.MAIN.post(() -> { if (generation != inferenceGeneration || isDestroyed()) return; outputText.setText("已取消纠错。"); btnCheck.setText("开始纠错"); btnCheck.setEnabled(true); progressBar.setVisibility(View.INVISIBLE); });
                    return;
                }
                if (generation != inferenceGeneration || isDestroyed()) return;
                HistoryStore.saveBlocks(this, historyFileId, result.blocks);
                AppExecutors.MAIN.post(() -> { if (generation != inferenceGeneration || isDestroyed()) return; isCheckingMain = false; btnCheck.setText("开始纠错"); allSentencesBlocks = result.blocks; lastTimeMs = result.elapsedMs; renderFinalBlocks(); btnCheck.setEnabled(true); btnCopy.setEnabled(true); btnSaveTxt.setEnabled(true); scrollView.post(() -> scrollView.fullScroll(View.FOCUS_UP)); });
            } catch (Exception exception) {
                String message = exception.getMessage(); AppExecutors.MAIN.post(() -> { if (generation != inferenceGeneration || isDestroyed()) return; isCheckingMain = false; btnCheck.setText("开始纠错"); outputText.setText("推理运行中断: " + message); btnCheck.setEnabled(true); btnSaveTxt.setEnabled(true); });
            } finally {
                if (proAcquired) releaseProEngine();
                AppExecutors.MAIN.post(() -> { if (generation != inferenceGeneration || isDestroyed()) return; getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); progressBar.setVisibility(View.INVISIBLE); });
            }
        });
    }

    private void appendLiveErrors(List<TextBlock> sentence, StringBuilder html, int[] errorCount) {
        boolean hasError = false;
        for (TextBlock block : sentence) if (block.isMutable && (!block.current.equals(block.original) || block.userModified || !block.exp.isEmpty())) { hasError = true; break; }
        if (!hasError) return;
        for (List<TextBlock> group : buildErrorGroups(sentence)) {
            List<TextBlock> errors = new ArrayList<>(); for (TextBlock block : group) if (block.isMutable && (!block.current.equals(block.original) || block.userModified || !block.exp.isEmpty())) errors.add(block); if (errors.isEmpty()) continue;
            html.append("<font color='#2196F3'><b>["); for (int i = 0; i < errors.size(); i++) { html.append(errorCount[0] + i + 1); if (i < errors.size() - 1) html.append(','); } html.append("]</b></font> ");
            for (TextBlock block : group) {
                String original = escapeHtmlQuick(block.original), current = escapeHtmlQuick(block.current);
                if (block.isMutable && (!block.current.equals(block.original) || block.userModified || !block.exp.isEmpty())) {
                    errorCount[0]++; String note = block.type == 1 ? " (置信度:" + String.format(Locale.getDefault(), "%.2f", block.conf) + ")" : (block.type == 4 ? " (自定义)" : ""); if (block.exp != null && !block.exp.isEmpty()) note += " (" + block.exp + ")"; String oldColor = block.type == 6 ? "#E53935" : "#9E9E9E";
                    if (block.current.equals(block.original)) html.append("<font color='#E53935'><b>").append(original).append("</b></font><font color='#9E9E9E'><small>").append(note).append("</small></font>");
                    else html.append("<font color='").append(oldColor).append("'><s>").append(original).append("</s></font> <font color='#E53935'><b>").append(current).append("</b></font><font color='#9E9E9E'><small>").append(note).append("</small></font>");
                } else html.append(original);
            }
            html.append("<br><br>");
        }
    }

    private List<List<TextBlock>> buildErrorGroups(List<TextBlock> sentence) {
        List<List<TextBlock>> clauses = new ArrayList<>(); List<TextBlock> clause = new ArrayList<>();
        for (TextBlock block : sentence) {
            if (block.isMutable) clause.add(block);
            else {
                String text = block.original; int start = 0;
                for (int i = 0; i < text.length(); i++) if (text.charAt(i) == '，' || text.charAt(i) == ',' || text.charAt(i) == '；' || text.charAt(i) == ';' || text.charAt(i) == '、' || text.charAt(i) == '\n') { String part = text.substring(start, i + 1); if (!part.isEmpty()) clause.add(new TextBlock(part, part, false, 0, 0)); clauses.add(clause); clause = new ArrayList<>(); start = i + 1; }
                if (start < text.length()) { String part = text.substring(start); clause.add(new TextBlock(part, part, false, 0, 0)); }
            }
        }
        if (!clause.isEmpty()) clauses.add(clause);
        List<List<TextBlock>> groups = new ArrayList<>(); List<TextBlock> current = new ArrayList<>();
        for (List<TextBlock> item : clauses) {
            boolean hasError = false; for (TextBlock block : item) if (block.isMutable && (!block.current.equals(block.original) || block.userModified || !block.exp.isEmpty())) { hasError = true; break; }
            if (hasError) current.addAll(item); else if (!current.isEmpty()) { groups.add(current); current = new ArrayList<>(); }
        }
        if (!current.isEmpty()) groups.add(current); return groups;
    }

    private void showEditDialog(TextBlock block) {
        if (isManuallyEditedOut) { Toast.makeText(this, "文本已手动编辑，无法使用还原。请长按进入便签模式修改。", Toast.LENGTH_LONG).show(); return; }
        if (block.type == 1) {
            String[] options = {"的", "地", "得", "还原为原字 (" + block.original + ")"}; new AlertDialog.Builder(this).setTitle("手动修改 (当前：" + block.current + ")").setItems(options, (dialog, which) -> { String choice = which == 0 ? "的" : which == 1 ? "地" : which == 2 ? "得" : block.original; block.userModified = !choice.equals(block.modelCorrected); block.current = choice; renderFinalBlocks(); HistoryStore.saveBlocks(this, lastSavedHistoryFileId, allSentencesBlocks); }).show();
        } else {
            String[] options = {"采用修改 (" + block.modelCorrected + ")", "还原 (" + block.original + ")"}; new AlertDialog.Builder(this).setTitle("手动修改 (当前：" + block.current + ")").setItems(options, (dialog, which) -> { String choice = which == 0 ? block.modelCorrected : block.original; block.userModified = !choice.equals(block.modelCorrected); block.current = choice; renderFinalBlocks(); HistoryStore.saveBlocks(this, lastSavedHistoryFileId, allSentencesBlocks); }).show();
        }
    }

    private void renderFinalBlocks() {
        currentClauseLinks.clear();
        int currentErrors = 0; for (List<TextBlock> sentence : allSentencesBlocks) for (TextBlock block : sentence) if (block.isMutable && (!block.current.equals(block.original) || !block.exp.isEmpty())) currentErrors++;
        Map<TextBlock, Integer> relativeOffsets = new HashMap<>(); Map<TextBlock, TargetSpan> editorTargets = new HashMap<>();
        SpannableStringBuilder fullMain = new SpannableStringBuilder(), fullEditor = new SpannableStringBuilder();
        boolean multiDocument = false; outer: for (List<TextBlock> sentence : allSentencesBlocks) for (TextBlock block : sentence) if (block.current.contains("---------------------------------")) { multiDocument = true; break outer; }
        int documentIndex = 1; boolean pendingMarker = multiDocument;
        for (List<TextBlock> sentence : allSentencesBlocks) {
            for (TextBlock block : sentence) {
                if (pendingMarker && documentIndex == 1) { appendDocumentMarker(fullMain, documentIndex); appendDocumentMarker(fullEditor, documentIndex); documentIndex++; pendingMarker = false; }
                boolean error = block.isMutable && (!block.current.equals(block.original) || !block.exp.isEmpty());
                int mainStart = fullMain.length(); fullMain.append(block.current); int[] mainRange = normalizedRange(mainStart, fullMain.length());
                if (error) relativeOffsets.put(block, mainRange[0]);
                if (block.isMutable) fullMain.setSpan(createEditSpan(block), mainRange[0], mainRange[1], mainRange[2]);

                int editorStart = fullEditor.length(); fullEditor.append(block.current); int[] editorRange = normalizedRange(editorStart, fullEditor.length());
                if (block.isMutable) {
                    if (error) { TargetSpan target = new TargetSpan(block.current); editorTargets.put(block, target); fullEditor.setSpan(target, editorRange[0], editorRange[1], editorRange[2]); }
                    if (!block.current.equals(block.original)) fullEditor.setSpan(new WavyUnderlineSpan(0xFF4CAF50), editorRange[0], editorRange[1], editorRange[2]);
                }
                if (block.current.contains("---------------------------------")) { appendDocumentMarker(fullMain, documentIndex); appendDocumentMarker(fullEditor, documentIndex); documentIndex++; }
            }
        }

        SpannableStringBuilder main = new SpannableStringBuilder(), editor = new SpannableStringBuilder(); int[] baseOffset = {0};
        if (currentErrors == 0) {
            String header = "检查完毕！未检测到错误。耗时 " + String.format(Locale.getDefault(), "%.2f", lastTimeMs / 1000.0) + " 秒。\n\n"; int start = main.length(); main.append(header); main.setSpan(new ForegroundColorSpan(0xFF4CAF50), start, main.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        } else {
            String header = "检查完毕！共更正 " + currentErrors + " 处。耗时 " + String.format(Locale.getDefault(), "%.2f", lastTimeMs / 1000.0) + " 秒。\n（点击序号可快速跳转）\n\n"; int start = main.length(); main.append(header); main.setSpan(new ForegroundColorSpan(0xFF757575), start, main.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            appendSectionHeader(main, "【纠错清单：】\n"); appendSectionHeader(editor, "【纠错清单：】\n");
            int errorIndex = 0;
            for (List<TextBlock> sentence : allSentencesBlocks) {
                for (List<TextBlock> group : buildErrorGroups(sentence)) {
                    List<TextBlock> errors = new ArrayList<>(); for (TextBlock block : group) if (block.isMutable && (!block.current.equals(block.original) || !block.exp.isEmpty())) errors.add(block); if (errors.isEmpty()) continue;
                    int markerStart = main.length(); appendNumbers(main, errorIndex, errors.size());
                    JumpSpan jump = new JumpSpan() {
                        @Override public int getTargetOffset(Spanned text) { for (TextBlock block : group) { Integer offset = relativeOffsets.get(block); if (offset != null && block.isMutable && (!block.current.equals(block.original) || !block.exp.isEmpty())) return baseOffset[0] + offset; } return -1; }
                        @Override public void onClick(View view) { jumpAndFlash((TextView) view, getTargetOffset((Spanned) ((TextView) view).getText()), scrollView); }
                        @Override public void updateDrawState(TextPaint paint) { paint.setColor(0xFF2196F3); paint.setUnderlineText(true); paint.setTypeface(android.graphics.Typeface.create("sans-serif-medium", 0)); }
                    };
                    main.setSpan(jump, markerStart, main.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    for (TextBlock block : group) {
                        if (block.isMutable && (!block.current.equals(block.original) || !block.exp.isEmpty())) { appendCorrection(main, block, true); errorIndex++; }
                        else main.append(block.current);
                    }
                    main.append('\n');

                    ClauseLink link = new ClauseLink(); int editorMarkerStart = editor.length(); appendNumbers(editor, errorIndex - errors.size(), errors.size()); int editorMarkerEnd = editor.length(); ListMarkerSpan marker = new ListMarkerSpan(); link.listMarkerSpan = marker;
                    editor.setSpan(marker, editorMarkerStart, editorMarkerEnd, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE); editor.setSpan(new ForegroundColorSpan(0xFF2196F3), editorMarkerStart, editorMarkerEnd, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE); editor.setSpan(new android.text.style.TypefaceSpan("sans-serif-medium"), editorMarkerStart, editorMarkerEnd, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    JumpSpan editorJump = new JumpSpan() {
                        @Override public int getTargetOffset(Spanned text) { return !link.isDead && link.targetOffset >= 0 && link.targetOffset <= text.length() ? link.targetOffset : -1; }
                        @Override public void onClick(View view) { TextView textView = (TextView) view; int target = getTargetOffset((Spanned) textView.getText()); if (target >= 0) jumpEditorToOffset(textView, target); }
                        @Override public void updateDrawState(TextPaint paint) { paint.setColor(0xFF2196F3); paint.setUnderlineText(true); paint.setTypeface(android.graphics.Typeface.create("sans-serif-medium", 0)); }
                    };
                    editor.setSpan(editorJump, editorMarkerStart, editorMarkerEnd, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                    for (TextBlock block : group) {
                        if (block.isMutable && (!block.current.equals(block.original) || !block.exp.isEmpty())) appendCorrection(editor, block, false); else editor.append(block.current);
                    }
                    editor.append('\n');
                    for (TextBlock block : errors) { TargetSpan target = editorTargets.get(block); if (target != null) link.targetSpans.add(target); }
                    currentClauseLinks.add(link);
                }
            }
            int separatorStart = main.length(); main.append("\n---------------------------------\n\n"); main.setSpan(new ForegroundColorSpan(0xFF757575), separatorStart, main.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            int editorSeparatorStart = editor.length(); editor.append("\n---------------------------------\n\n"); editor.setSpan(new ForegroundColorSpan(0xFF757575), editorSeparatorStart, editor.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }

        appendSectionHeader(main, currentErrors > 0 ? "【修正后的全文】\n" : "【原文】\n"); appendSectionHeader(editor, currentErrors > 0 ? "【修正后的全文】\n" : "【原文】\n");
        if (main.length() > 0) main.setSpan(new IgnoredInCopySpan(), 0, main.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        if (editor.length() > 0) editor.setSpan(new IgnoredInCopySpan(), 0, editor.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        baseOffset[0] = main.length(); main.append(fullMain); editor.append(fullEditor);
        for (ClauseLink link : currentClauseLinks) {
            link.targetOffset = -1;
            for (TargetSpan target : link.targetSpans) {
                int start = editor.getSpanStart(target);
                if (start >= 0) { link.targetOffset = start; break; }
            }
        }
        lastEditorSpannable = editor;
        outputText.setText(main); outputText.setMovementMethod(MyLinkMovementMethod.getInstance()); outputText.setHighlightColor(Color.TRANSPARENT);
    }

    private void appendDocumentMarker(SpannableStringBuilder builder, int index) {
        int start = builder.length(); builder.append("［文档").append(String.valueOf(index)).append("］\n"); builder.setSpan(new ForegroundColorSpan(0xFF757575), start, builder.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE); builder.setSpan(new IgnoredInCopySpan(), start, builder.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
    }

    private int[] normalizedRange(int start, int end) {
        if (start == end && start > 0) start--; return new int[]{start, end, start == end ? Spanned.SPAN_POINT_MARK : Spanned.SPAN_EXCLUSIVE_EXCLUSIVE};
    }

    private EditSpan createEditSpan(TextBlock block) {
        return new EditSpan() {
            @Override public void onClick(View view) { showEditDialog(block); }
            @Override public void updateDrawState(TextPaint paint) {
                paint.setUnderlineText(true);
                paint.setTypeface(android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL));
                if (!block.current.equals(block.original) || !block.exp.isEmpty()) paint.setColor(block.userModified && !block.current.equals(block.original) ? 0xFF4CAF50 : 0xFFE53935);
                else paint.setColor(0xFF2196F3);
            }
        };
    }

    private void appendSectionHeader(SpannableStringBuilder builder, String value) {
        int start = builder.length(); builder.append(value); builder.setSpan(new ForegroundColorSpan(0xFF757575), start, builder.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE); builder.setSpan(new android.text.style.TypefaceSpan("sans-serif-medium"), start, builder.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
    }

    private void appendNumbers(SpannableStringBuilder builder, int startIndex, int count) {
        builder.append('['); for (int i = 0; i < count; i++) { builder.append(String.valueOf(startIndex + i + 1)); if (i < count - 1) builder.append(','); } builder.append("] ");
    }

    private void appendCorrection(SpannableStringBuilder builder, TextBlock block, boolean clickable) {
        int newStart;
        if (block.current.equals(block.original)) { newStart = builder.length(); builder.append(block.original); }
        else {
            int oldStart = builder.length(); builder.append(block.original);
            if (block.type == 6) builder.setSpan(new ColoredStrikethroughSpan(0xFF9E9E9E, 0xFFE53935), oldStart, builder.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            else { builder.setSpan(new StrikethroughSpan(), oldStart, builder.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE); builder.setSpan(new ForegroundColorSpan(0xFF9E9E9E), oldStart, builder.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE); }
            builder.append(' '); newStart = builder.length(); builder.append(block.current);
        }
        int[] range = normalizedRange(newStart, builder.length());
        if (clickable) builder.setSpan(createEditSpan(block), range[0], range[1], range[2]);
        else { builder.setSpan(new ForegroundColorSpan(block.userModified && !block.current.equals(block.original) ? 0xFF4CAF50 : 0xFFE53935), range[0], range[1], range[2]); builder.setSpan(new android.text.style.TypefaceSpan("sans-serif-medium"), range[0], range[1], range[2]); }
        if (!block.userModified && block.type == 1) appendSmallNote(builder, "置信度: " + String.format(Locale.getDefault(), "%.2f", block.conf)); else if (!block.userModified && block.type == 4) appendSmallNote(builder, "自定义");
        if (!block.userModified && block.exp != null && !block.exp.isEmpty()) appendSmallNote(builder, block.exp);
    }

    private void appendSmallNote(SpannableStringBuilder builder, String note) {
        int start = builder.length(); builder.append('(').append(note).append(')'); builder.setSpan(new ForegroundColorSpan(0xFF9E9E9E), start, builder.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE); builder.setSpan(new android.text.style.RelativeSizeSpan(.85f), start, builder.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
    }

}
