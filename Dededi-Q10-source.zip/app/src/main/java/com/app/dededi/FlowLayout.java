package com.app.dededi;
import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;

public class FlowLayout extends ViewGroup {
    private int hGap = 20, vGap = 20;
    public FlowLayout(Context context) { super(context); }
    public FlowLayout(Context context, AttributeSet attrs) { super(context, attrs); }

    @Override protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int sizeWidth = MeasureSpec.getSize(widthMeasureSpec), modeWidth = MeasureSpec.getMode(widthMeasureSpec);
        int sizeHeight = MeasureSpec.getSize(heightMeasureSpec), modeHeight = MeasureSpec.getMode(heightMeasureSpec);
        int available = Math.max(0, sizeWidth - getPaddingLeft() - getPaddingRight());
        int measuredWidth = 0, measuredHeight = 0, lineWidth = 0, lineHeight = 0;
        for (int i = 0; i < getChildCount(); i++) {
            View child = getChildAt(i); if (child.getVisibility() == GONE) continue;
            measureChild(child, widthMeasureSpec, heightMeasureSpec);
            int childWidth = child.getMeasuredWidth(), childHeight = child.getMeasuredHeight();
            int required = lineWidth == 0 ? childWidth : lineWidth + hGap + childWidth;
            if (lineWidth > 0 && required > available) {
                measuredWidth = Math.max(measuredWidth, lineWidth); measuredHeight += lineHeight + vGap; lineWidth = childWidth; lineHeight = childHeight;
            } else {
                lineWidth = required; lineHeight = Math.max(lineHeight, childHeight);
            }
        }
        measuredWidth = Math.max(measuredWidth, lineWidth) + getPaddingLeft() + getPaddingRight();
        measuredHeight += lineHeight + getPaddingTop() + getPaddingBottom();
        setMeasuredDimension(modeWidth == MeasureSpec.EXACTLY ? sizeWidth : measuredWidth, modeHeight == MeasureSpec.EXACTLY ? sizeHeight : measuredHeight);
    }

    @Override protected void onLayout(boolean changed, int l, int t, int r, int b) {
        int available = getWidth() - getPaddingLeft() - getPaddingRight();
        int x = getPaddingLeft(), y = getPaddingTop(), lineWidth = 0, lineHeight = 0;
        for (int i = 0; i < getChildCount(); i++) {
            View child = getChildAt(i); if (child.getVisibility() == GONE) continue;
            int childWidth = child.getMeasuredWidth(), childHeight = child.getMeasuredHeight();
            int required = lineWidth == 0 ? childWidth : lineWidth + hGap + childWidth;
            if (lineWidth > 0 && required > available) { x = getPaddingLeft(); y += lineHeight + vGap; lineWidth = 0; lineHeight = 0; }
            if (lineWidth > 0) { x += hGap; lineWidth += hGap; }
            child.layout(x, y, x + childWidth, y + childHeight);
            x += childWidth; lineWidth += childWidth; lineHeight = Math.max(lineHeight, childHeight);
        }
    }
}
