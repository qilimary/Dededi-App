package com.app.dededi;
import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputFilter;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.LinkedHashSet;
import java.util.Set;

public class SymbolCleanActivity extends Activity {
    public static MainActivity.TextCleanCallback callback;

    @Override protected void onCreate(Bundle savedInstanceState) {
        overridePendingTransition(0, 0);
        super.onCreate(savedInstanceState);
        getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        String rawText = getIntent().getStringExtra("raw_text");
        if (rawText == null) rawText = "";
        boolean hasStar = getIntent().getBooleanExtra("star", false);
        boolean hasHash = getIntent().getBooleanExtra("hash", false);
        boolean hasDash = getIntent().getBooleanExtra("dash", false);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(35, 25, 35, 10);
        TextView title = new TextView(this);
        title.setText("提示：发现符号残留"); title.setTextSize(15f); title.setTextColor(0xFF000000); title.getPaint().setFakeBoldText(true); title.setPadding(0, 0, 0, 8);
        TextView message = new TextView(this);
        message.setText("注意到文本可能存在符号残留，是否清理？"); message.setTextSize(13f); message.setTextColor(0xFF333333); message.setPadding(0, 0, 0, 10);
        layout.addView(title); layout.addView(message);

        LinearLayout.LayoutParams cbParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cbParams.setMargins(0, -10, 0, -10);
        CheckBox cbStar = createCheckBox("去掉所有 * 号", hasStar);
        CheckBox cbHash = createCheckBox("去掉所有 # 号", hasHash);
        CheckBox cbDash = createCheckBox("去掉所有 - 号", hasDash);
        layout.addView(cbStar, cbParams); layout.addView(cbHash, cbParams); layout.addView(cbDash, cbParams);

        TextView customTitle = new TextView(this);
        customTitle.setText("去掉自定义标点 (最多4种)："); customTitle.setPadding(5, 5, 0, 5); customTitle.setTextColor(0xFF555555); customTitle.setTextSize(12f);
        layout.addView(customTitle);
        LinearLayout customLayout = new LinearLayout(this); customLayout.setOrientation(LinearLayout.HORIZONTAL);
        EditText[] customs = new EditText[4];
        for (int i = 0; i < customs.length; i++) {
            EditText edit = new EditText(this);
            edit.setId(1001 + i); edit.setFilters(new InputFilter[]{new InputFilter.LengthFilter(1)}); edit.setGravity(Gravity.CENTER); edit.setTextSize(14f); edit.setPadding(0, 0, 0, 0); edit.setScaleX(0.70f); edit.setScaleY(0.70f);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1); lp.setMargins(6, -10, 6, -10);
            edit.setLayoutParams(lp); customs[i] = edit; customLayout.addView(edit);
        }
        layout.addView(customLayout);

        String finalText = rawText;
        android.content.Context dialogContext = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Settings.canDrawOverlays(this))
                ? new ContextThemeWrapper(getApplicationContext(), android.R.style.Theme_Material_Light_Dialog_Alert)
                : new ContextThemeWrapper(this, android.R.style.Theme_Material_Light_Dialog_Alert);

        AlertDialog dialog = new AlertDialog.Builder(dialogContext)
                .setView(layout).setCancelable(false)
                .setPositiveButton("是 (清理)", (d, which) -> {
                    Set<String> symbols = new LinkedHashSet<>();
                    if (cbStar.isChecked()) symbols.add("*");
                    if (cbHash.isChecked()) symbols.add("#");
                    if (cbDash.isChecked()) symbols.add("-");
                    boolean duplicate = false;
                    for (EditText custom : customs) {
                        String value = custom.getText().toString();
                        if (!value.isEmpty() && !symbols.add(value)) duplicate = true;
                    }
                    if (duplicate) Toast.makeText(this, "提示：已勾选的符号无需重复输入", Toast.LENGTH_SHORT).show();
                    String result = finalText;
                    for (String symbol : symbols) {
                        result = result.replace(symbol, "");
                        if (">".equals(symbol)) result = result.replace("＞", "");
                        if ("<".equals(symbol)) result = result.replace("＜", "");
                    }
                    MainActivity.TextCleanCallback current = callback;
                    if (current != null) current.onCleaned(result);
                    d.dismiss();
                })
                .setNegativeButton("否 (不清理)", (d, which) -> {
                    MainActivity.TextCleanCallback current = callback;
                    if (current != null) current.onCleaned(finalText);
                    d.dismiss();
                }).create();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (Settings.canDrawOverlays(this)) dialog.getWindow().setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY);
        } else dialog.getWindow().setType(WindowManager.LayoutParams.TYPE_PHONE);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0xFFFFFFFF));
        dialog.setOnShowListener(d -> {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(0xFF4CAF50);
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(0xFF9E9E9E);
        });
        dialog.setOnDismissListener(d -> finish());
        dialog.show();
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(dialog.getWindow().getAttributes());
        lp.width = (int) (getResources().getDisplayMetrics().widthPixels * 0.80f);
        dialog.getWindow().setAttributes(lp);
    }

    private CheckBox createCheckBox(String text, boolean checked) {
        CheckBox box = new CheckBox(this); box.setText(text); box.setChecked(checked); box.setTextSize(14f); box.setTextColor(0xFF333333); box.setScaleX(0.75f); box.setScaleY(0.75f); box.setPivotX(0); return box;
    }

    @Override public void finish() {
        callback = null;
        MainActivity.isCleanDialogOpen = false;
        super.finish();
        overridePendingTransition(0, 0);
    }
}
