package com.app.dededi;

import android.content.Context;
import java.io.File;

final class NGramEngine {
    private static final long MODEL_BYTES = 146771061L;
    private static final Object LOCK = new Object();
    private static volatile boolean ready;
    private static volatile boolean failed;
    private NGramEngine() {}

    static boolean ensureReady(Context context) {
        if (ready) return true;
        if (failed) return false;
        synchronized (LOCK) {
            if (ready) return true;
            if (failed) return false;
            try {
                File dir = new File(context.getNoBackupFilesDir(), "q10");
                if (!dir.exists() && !dir.mkdirs()) throw new IllegalStateException("无法创建 Q10 目录");
                File model = new File(dir, "dededi_final_5gram_q10.klm.bin");
                if (!model.isFile() || model.length() != MODEL_BYTES) {
                    if (model.exists()) model.delete();
                    if (!SecureAsset.decryptToFile(context, "sys_lm_q10.dat", model) || model.length() != MODEL_BYTES)
                        throw new IllegalStateException("Q10 模型解密/长度校验失败");
                }
                if (!NativeNGram.loadModelNative(model.getAbsolutePath())) {
                    // One repair attempt protects against a stale/corrupted private copy.
                    model.delete();
                    if (!SecureAsset.decryptToFile(context, "sys_lm_q10.dat", model) || model.length() != MODEL_BYTES
                            || !NativeNGram.loadModelNative(model.getAbsolutePath()))
                        throw new IllegalStateException("KenLM Q10 加载失败");
                }
                ready = true;
                return true;
            } catch (Throwable error) {
                failed = true;
                SecureAsset.recordError("Q10 初始化失败", error);
                return false;
            }
        }
    }

    private static boolean lmWhitespace(int cp) {
        return cp == 0x20 || cp == 0x09 || cp == 0x0A || cp == 0x0D || cp == 0x0B || cp == 0x0C;
    }

    /**
     * Exact 5-gram local delta.  Four non-whitespace tokens on each side are sufficient:
     * older history cannot affect the changed token or any score that still depends on it.
     * Keeping the window here also avoids re-tokenizing an entire long sentence for every candidate.
     */
    static double delta(Context context, String text, int start, int sourceLength, String correction) {
        if (!ensureReady(context) || text == null || correction == null || start < 0 || sourceLength <= 0
                || start + sourceLength > text.length()) return Double.NaN;
        try {
            int left = start, seen = 0;
            while (left > 0 && seen < 4) {
                int cp = text.codePointBefore(left); left -= Character.charCount(cp);
                if (!lmWhitespace(cp)) seen++;
            }
            int sourceEnd = start + sourceLength, right = sourceEnd; seen = 0;
            while (right < text.length() && seen < 4) {
                int cp = text.codePointAt(right); right += Character.charCount(cp);
                if (!lmWhitespace(cp)) seen++;
            }
            String window = text.substring(left, right);
            return NativeNGram.deltaSpanNative(window, start - left, sourceLength, correction);
        } catch (Throwable error) {
            SecureAsset.recordError("Q10 打分失败", error); return Double.NaN;
        }
    }

    /** Built-in typo entries are vetoed by Q10. User-created custom replacements stay authoritative. */
    static boolean acceptDictionary(Context context, String text, int start, MainActivity.TypoMatch match) {
        if (match == null || match.source.equals(match.correction) || match.custom) return true;
        double d = delta(context, text, start, match.source.length(), match.correction);
        if (!Double.isFinite(d)) return false; // fail closed: low false-positive first
        // -1.0 is the calibrated equal-length reverse-veto threshold from the cross-domain test.
        // Length-changing entries were not calibrated there, so require non-degradation instead.
        return d >= (match.source.length() == match.correction.length() ? -1.0 : 0.0);
    }
}
