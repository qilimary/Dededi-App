package com.app.dededi;
final class NativeNGram {
    static { System.loadLibrary("dededi"); }
    private NativeNGram() {}
    static native boolean loadModelNative(String path);
    static native double deltaSpanNative(String text, int start, int sourceLength, String correction);
}
