package com.app.dededi;

import android.content.Context;
import android.content.res.AssetManager;
import java.io.ByteArrayOutputStream;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.util.Arrays;
import java.util.zip.GZIPInputStream;
import javax.crypto.AEADBadTagException;
import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

final class SecureAsset {
    private static final byte[] MAGIC = new byte[]{'D', 'D', 'A', '3'};
    private static final int VERSION = 1;
    private static final int TAG_SIZE = 16;
    private static final int IO_BUFFER = 64 * 1024;
    private static final int MAX_CHUNK = 4 * 1024 * 1024;
    private static volatile String lastError = "";
    private SecureAsset() {}

    static void recordError(String stage, Throwable error) {
        String detail = error == null ? "未知异常" : error.getClass().getSimpleName() + ": " + String.valueOf(error.getMessage());
        lastError = stage + "（" + detail + "）";
        if (error != null) error.printStackTrace();
    }

    static String lastErrorSummary() {
        String value = lastError;
        return value == null || value.isEmpty() ? "未获得详细错误" : value;
    }

    static String readUtf8(Context context, String assetName) {
        ByteArrayOutputStream output = new ByteArrayOutputStream(32 * 1024);
        try {
            decrypt(context, assetName, output);
            return output.toString("UTF-8");
        } catch (Throwable error) {
            recordError("读取 " + assetName + " 失败", error);
            return "";
        }
    }

    static boolean decryptToFile(Context context, String assetName, File target) {
        File temporary = new File(target.getAbsolutePath() + ".part");
        try (FileOutputStream file = new FileOutputStream(temporary);
             BufferedOutputStream output = new BufferedOutputStream(file, IO_BUFFER)) {
            decrypt(context, assetName, output); output.flush();
            file.getFD().sync();
        } catch (Throwable error) {
            recordError("解密 " + assetName + " 失败", error);
            temporary.delete();
            return false;
        }
        if (target.exists() && !target.delete()) { temporary.delete(); return false; }
        if (!temporary.renameTo(target)) { temporary.delete(); return false; }
        return true;
    }

    private static void decrypt(Context context, String assetName, OutputStream plainOutput) throws IOException, GeneralSecurityException {
        try (InputStream input = new BufferedInputStream(context.getAssets().open(assetName, AssetManager.ACCESS_STREAMING), IO_BUFFER);
             AuthenticatedChunks chunks = new AuthenticatedChunks(input, assetName);
             GZIPInputStream gzip = new GZIPInputStream(chunks, IO_BUFFER)) {
            byte[] buffer = new byte[IO_BUFFER];
            try {
                int first = gzip.read(), second = gzip.read();
                if (first >= 0) {
                    if ((chunks.flags & 1) != 0 && first == 0x44 && second == 0x45) { plainOutput.write(0x50); plainOutput.write(0x4B); }
                    else { plainOutput.write(first); if (second >= 0) plainOutput.write(second); }
                }
                int count;
                while ((count = gzip.read(buffer)) != -1) plainOutput.write(buffer, 0, count);
                // GZIP may stop before the encrypted asset ends, or swallow a trailer IO error.
                // Drain to the authenticated EOF and rethrow any latched error before committing.
                while (chunks.read(buffer) != -1) {}
            } finally { Arrays.fill(buffer, (byte)0); }
        }
    }

    private static final class AuthenticatedChunks extends InputStream {
        final InputStream input;
        final int flags, chunkSize, chunkCount;
        final long totalLength;
        byte[] key, encrypted, plain, nonce, aad;
        Cipher cipher;
        SecretKeySpec keySpec;
        long verified;
        int index, offset, limit;
        boolean ended, closed;
        IOException failure;
        AuthenticatedChunks(InputStream input, String assetName) throws IOException, GeneralSecurityException {
            this.input = input;
            byte[] magic = new byte[4]; readFully(input, magic);
            if (!Arrays.equals(MAGIC, magic)) throw new GeneralSecurityException("资源格式错误");
            int version = input.read(); flags = input.read();
            if (version != VERSION || flags < 0 || (flags & ~1) != 0) throw new GeneralSecurityException("资源版本错误");
            byte[] salt = new byte[16], prefix = new byte[8]; readFully(input, salt); readFully(input, prefix);
            chunkSize = readInt(input); totalLength = readLong(input); chunkCount = readInt(input);
            if (chunkSize < 4096 || chunkSize > MAX_CHUNK || totalLength <= 0 || chunkCount <= 0
                    || 1L + (totalLength - 1L) / chunkSize != chunkCount) throw new GeneralSecurityException("资源分块头异常");
            byte[] javaPart = null, token = null;
            try {
                ByteArrayOutputStream header = new ByteArrayOutputStream(64);
                header.write(MAGIC); header.write(version); header.write(flags); header.write(salt); header.write(prefix);
                writeInt(header, chunkSize); writeLong(header, totalLength); writeInt(header, chunkCount);
                header.write(assetName.getBytes(StandardCharsets.UTF_8));
                aad = Arrays.copyOf(header.toByteArray(), header.size() + 8);
                nonce = Arrays.copyOf(prefix, 12);
                javaPart = GeneratedSecuritySeed.revealPart(); token = GeneratedSecuritySeed.buildToken();
                key = NativeSecurity.deriveAssetKeyNative(javaPart, token, salt, assetName);
                if (key == null || key.length != 32) throw new GeneralSecurityException("安全环境校验失败");
                keySpec = new SecretKeySpec(key, "AES"); cipher = Cipher.getInstance("AES/GCM/NoPadding");
                encrypted = new byte[chunkSize + TAG_SIZE]; plain = new byte[chunkSize];
            } catch (IOException | GeneralSecurityException | RuntimeException error) { wipe(); throw error; }
            finally {
                if (javaPart != null) Arrays.fill(javaPart, (byte)0); if (token != null) Arrays.fill(token, (byte)0);
                Arrays.fill(salt, (byte)0); Arrays.fill(prefix, (byte)0);
            }
        }
        private boolean nextChunk() throws IOException {
            if (failure != null) throw failure;
            try { return nextChunkChecked(); } catch (IOException error) { failure = error; throw error; }
        }
        private boolean nextChunkChecked() throws IOException {
            if (closed) throw new IOException("资源流已关闭");
            if (ended) return false;
            if (index == chunkCount) {
                if (verified != totalLength || input.read() != -1) throw new IOException("资源尾部异常");
                ended = true; return false;
            }
            int length = readInt(input), expected = (int)Math.min((long)chunkSize, totalLength - verified);
            if (length != expected || length <= 0) throw new IOException("资源块长度异常");
            readFully(input, encrypted, length + TAG_SIZE);
            putInt(nonce, 8, index); putInt(aad, aad.length - 8, index); putInt(aad, aad.length - 4, length);
            try {
                cipher.init(Cipher.DECRYPT_MODE, keySpec, new GCMParameterSpec(128, nonce)); cipher.updateAAD(aad);
                Arrays.fill(plain, (byte)0);
                int decoded = cipher.doFinal(encrypted, 0, length + TAG_SIZE, plain, 0);
                if (decoded != length) throw new IOException("资源块解密长度异常");
                offset = 0; limit = decoded; verified += decoded; index++; return true;
            } catch (GeneralSecurityException error) { throw new IOException("资源完整性验证失败", error); }
            finally { Arrays.fill(encrypted, (byte)0); }
        }
        @Override public int read() throws IOException {
            if (failure != null) throw failure;
            if (offset == limit && !nextChunk()) return -1;
            return plain[offset++] & 0xFF;
        }
        @Override public int read(byte[] out, int start, int length) throws IOException {
            if (out == null) throw new NullPointerException();
            if (start < 0 || length < 0 || start > out.length - length) throw new IndexOutOfBoundsException();
            if (length == 0) return 0;
            if (failure != null) throw failure;
            if (offset == limit && !nextChunk()) return -1;
            int count = Math.min(length, limit - offset); System.arraycopy(plain, offset, out, start, count); offset += count; return count;
        }
        @Override public int available() { return closed ? 0 : limit - offset; }
        private void wipe() {
            for (byte[] bytes : new byte[][]{key, encrypted, plain, nonce, aad}) if (bytes != null) Arrays.fill(bytes, (byte)0);
            cipher = null; keySpec = null;
        }
        @Override public void close() throws IOException { if (closed) return; closed = true; wipe(); input.close(); }
    }

    private static void readFully(InputStream input, byte[] output, int length) throws IOException {
        int offset = 0;
        while (offset < length) {
            int count = input.read(output, offset, length - offset);
            if (count < 0) throw new IOException("资源数据不完整");
            if (count > 0) offset += count;
        }
    }

    private static int readInt(InputStream input) throws IOException {
        byte[] bytes = new byte[4]; readFully(input, bytes);
        return ((bytes[0] & 0xFF) << 24) | ((bytes[1] & 0xFF) << 16) | ((bytes[2] & 0xFF) << 8) | (bytes[3] & 0xFF);
    }

    private static long readLong(InputStream input) throws IOException {
        byte[] bytes = new byte[8]; readFully(input, bytes);
        long value = 0; for (byte item : bytes) value = (value << 8) | (item & 0xFFL); return value;
    }

    private static void writeInt(OutputStream output, int value) throws IOException {
        output.write((value >>> 24) & 0xFF); output.write((value >>> 16) & 0xFF); output.write((value >>> 8) & 0xFF); output.write(value & 0xFF);
    }

    private static void writeLong(OutputStream output, long value) throws IOException {
        for (int shift = 56; shift >= 0; shift -= 8) output.write((int)(value >>> shift) & 0xFF);
    }

    private static void putInt(byte[] output, int offset, int value) {
        output[offset] = (byte)(value >>> 24); output[offset + 1] = (byte)(value >>> 16); output[offset + 2] = (byte)(value >>> 8); output[offset + 3] = (byte)value;
    }

    private static void readFully(InputStream input, byte[] output) throws IOException {
        int offset = 0;
        while (offset < output.length) {
            int count = input.read(output, offset, output.length - offset);
            if (count < 0) throw new IOException("资源数据不完整");
            if (count == 0) continue;
            offset += count;
        }
    }
}
