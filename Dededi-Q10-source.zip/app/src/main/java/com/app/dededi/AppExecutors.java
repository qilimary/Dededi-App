package com.app.dededi;
import android.os.Handler;
import android.os.Looper;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

public final class AppExecutors {
    public static final Handler MAIN = new Handler(Looper.getMainLooper());
    public static final Object HISTORY_LOCK = new Object();
    public static final ExecutorService IO = pool(2, "dededi-io");
    public static final ExecutorService HISTORY = pool(1, "dededi-history");
    public static final ExecutorService INFERENCE = pool(1, "dededi-inference");
    private AppExecutors() {}
    private static ExecutorService pool(int size, String name) {
        ThreadPoolExecutor pool = new ThreadPoolExecutor(size, size, 30, TimeUnit.SECONDS, new LinkedBlockingQueue<>(), namedFactory(name));
        pool.allowCoreThreadTimeOut(true); return pool;
    }
    private static ThreadFactory namedFactory(String prefix) {
        AtomicInteger counter = new AtomicInteger(1);
        return runnable -> {
            Thread thread = new Thread(runnable, prefix + "-" + counter.getAndIncrement());
            thread.setPriority(Thread.NORM_PRIORITY - 1);
            return thread;
        };
    }
}
