package com.app.dededi;
import android.content.Context;
import android.content.SharedPreferences;
import android.text.Spannable;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public final class HistoryStore {
    public interface Callback { void onSaved(String fileId); }
    private HistoryStore() {}

    public static void save(Context context, SharedPreferences preferences, String text, String existingFileId, Callback callback) {
        if (text == null || text.trim().isEmpty()) return;
        Context appContext = context.getApplicationContext();
        AppExecutors.HISTORY.execute(() -> {
            String resolvedId = existingFileId;
            synchronized (AppExecutors.HISTORY_LOCK) {
                try {
                    JSONArray history = new JSONArray(preferences.getString("history_records", "[]"));
                    int hash = text.hashCode(), length = text.length();
                    if ((resolvedId == null || resolvedId.isEmpty()) && history.length() > 0) {
                        JSONObject latest = history.getJSONObject(0);
                        if (latest.optInt("textHash", Integer.MIN_VALUE) == hash && latest.optInt("textLength", length) == length) {
                            resolvedId = latest.optString("file", resolvedId);
                            String finalId = resolvedId;
                            if (callback != null) AppExecutors.MAIN.post(() -> callback.onSaved(finalId));
                            return;
                        }
                    }
                    if (resolvedId == null || resolvedId.isEmpty()) resolvedId = UUID.randomUUID().toString();
                    File directory = new File(appContext.getFilesDir(), "history");
                    if (!directory.exists() && !directory.mkdirs()) throw new IllegalStateException("无法创建历史目录");
                    writeUtf8Atomic(new File(directory, resolvedId + ".txt"), text);

                    JSONArray remaining = new JSONArray();
                    for (int i = 0; i < history.length(); i++) {
                        JSONObject object = history.getJSONObject(i);
                        if (!resolvedId.equals(object.optString("file", ""))) remaining.put(object);
                    }
                    JSONObject record = new JSONObject();
                    record.put("time", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date()));
                    record.put("textHash", hash); record.put("textLength", length);
                    record.put("preview", text.length() > 16 ? text.substring(0, 16).replace("\n", " ") + "..." : text.replace("\n", " "));
                    record.put("file", resolvedId);
                    JSONArray finalArray = new JSONArray(); finalArray.put(record);
                    int keep = Math.min(remaining.length(), 49);
                    for (int i = 0; i < keep; i++) finalArray.put(remaining.getJSONObject(i));
                    for (int i = 49; i < remaining.length(); i++) deleteFiles(directory, remaining.getJSONObject(i).optString("file", ""));
                    preferences.edit().putString("history_records", finalArray.toString()).apply();
                } catch (Exception ignored) {}
            }
            String finalId = resolvedId;
            if (callback != null) AppExecutors.MAIN.post(() -> callback.onSaved(finalId));
        });
    }

    public static void saveBlocks(Context context, String fileId, List<List<MainActivity.TextBlock>> blocks) {
        if (fileId == null || fileId.isEmpty() || blocks == null || blocks.isEmpty()) return;
        Context appContext = context.getApplicationContext();
        AppExecutors.HISTORY.execute(() -> {
            String json = MainActivity.serializeBlocks(blocks);
            synchronized (AppExecutors.HISTORY_LOCK) {
                try {
                    File directory = new File(appContext.getFilesDir(), "history");
                    if (!directory.exists() && !directory.mkdirs()) throw new IllegalStateException("无法创建历史目录");
                    writeUtf8Atomic(new File(directory, fileId + "_blocks.json"), json);

                    String currentText = readUtf8(new File(directory, fileId + ".txt"));
                    if (currentText.isEmpty()) return;

                    SharedPreferences preferences = appContext.getSharedPreferences("DedediConfig", Context.MODE_PRIVATE);
                    JSONArray history = new JSONArray(preferences.getString("history_records", "[]"));
                    JSONArray deduplicated = new JSONArray();
                    int currentHash = currentText.hashCode();
                    int currentLength = currentText.length();
                    boolean changed = false;

                    for (int i = 0; i < history.length(); i++) {
                        JSONObject record = history.getJSONObject(i);
                        String otherId = record.optString("file", "");
                        if (fileId.equals(otherId)) {
                            deduplicated.put(record);
                            continue;
                        }

                        boolean sameTextMetadata =
                                record.optInt("textHash", Integer.MIN_VALUE) == currentHash
                                        && record.optInt("textLength", -1) == currentLength;

                        if (sameTextMetadata && !otherId.isEmpty()) {
                            String otherText = readUtf8(new File(directory, otherId + ".txt"));
                            String otherBlocks = readUtf8(new File(directory, otherId + "_blocks.json"));
                            if (currentText.equals(otherText) && json.equals(otherBlocks)) {
                                deleteFiles(directory, otherId);
                                changed = true;
                                continue;
                            }
                        }
                        deduplicated.put(record);
                    }

                    if (changed) preferences.edit().putString("history_records", deduplicated.toString()).apply();
                } catch (Exception ignored) {}
            }
        });
    }

    public static void saveManual(Context context, String fileId, Spannable text) {
        if (fileId == null || fileId.isEmpty() || text == null) return;
        Context appContext = context.getApplicationContext();
        AppExecutors.HISTORY.execute(() -> {
            String json = MainActivity.serializeSpannable(text);
            try {
                File directory = new File(appContext.getFilesDir(), "history"); if (!directory.exists()) directory.mkdirs();
                writeUtf8Atomic(new File(directory, fileId + "_manual.json"), json);
            } catch (Exception ignored) {}
        });
    }

    public static String readUtf8(File file) {
        if (file == null || !file.exists()) return "";
        try (FileInputStream input = new FileInputStream(file); ByteArrayOutputStream output = new ByteArrayOutputStream((int) Math.min(file.length(), 1_048_576))) {
            byte[] buffer = new byte[8192]; int read;
            while ((read = input.read(buffer)) != -1) output.write(buffer, 0, read);
            return output.toString(StandardCharsets.UTF_8.name());
        } catch (Exception ignored) { return ""; }
    }

    public static void deleteRecord(Context context, String fileId) {
        if (fileId == null || fileId.isEmpty()) return;
        deleteFiles(new File(context.getFilesDir(), "history"), fileId);
    }

    public static void clear(Context context) {
        File directory = new File(context.getFilesDir(), "history");
        File[] files = directory.listFiles();
        if (files != null) for (File file : files) file.delete();
    }

    private static void deleteFiles(File directory, String fileId) {
        if (fileId == null || fileId.isEmpty()) return;
        new File(directory, fileId + ".txt").delete();
        new File(directory, fileId + "_blocks.json").delete();
        new File(directory, fileId + "_manual.json").delete();
    }

    private static void writeUtf8Atomic(File target, String content) throws Exception {
        File temporary = new File(target.getAbsolutePath() + ".tmp");
        try (FileOutputStream output = new FileOutputStream(temporary);
             java.io.BufferedWriter writer = new java.io.BufferedWriter(new java.io.OutputStreamWriter(output, StandardCharsets.UTF_8), 32768)) {
            writer.write(content); writer.flush(); output.getFD().sync();
        }
        if (target.exists() && !target.delete()) throw new IllegalStateException("无法替换旧文件");
        if (!temporary.renameTo(target)) throw new IllegalStateException("无法提交临时文件");
    }
}
