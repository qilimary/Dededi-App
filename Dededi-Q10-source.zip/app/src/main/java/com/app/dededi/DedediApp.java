package com.app.dededi;
import android.app.Application;
import android.content.Context;
import java.io.File;
public final class DedediApp extends Application {
    private static volatile Context appContext;
    @Override public void onCreate() {
        super.onCreate();
        appContext = getApplicationContext();
        clearRuntimePlainModels();
    }
    private void clearRuntimePlainModels() {
        // 清理上次异常退出时可能遗留的当前版临时明文模型。
        File dir = new File(getCacheDir(), "dededi_runtime_models");
        File[] files = dir.listFiles((d, name) -> (name.endsWith(".pte") || name.endsWith(".pte.part")));
        if (files != null) for (File file : files) if (!file.delete()) file.deleteOnExit();
    }
    static Context context() {
        Context value = appContext;
        if (value == null) throw new IllegalStateException("应用尚未初始化");
        return value;
    }
}
