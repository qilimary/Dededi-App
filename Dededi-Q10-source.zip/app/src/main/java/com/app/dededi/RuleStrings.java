package com.app.dededi;
import org.json.JSONArray;
final class RuleStrings {
    private static volatile String[] values;
    private static volatile boolean attempted;
    private RuleStrings() {}
    private static void ensureLoaded() {
        if (attempted) return;
        synchronized (RuleStrings.class) {
            if (attempted) return;
            attempted = true;
            try {
                String raw = SecureAsset.readUtf8(DedediApp.context(), "sys_rules.dat");
                if (raw.isEmpty()) return;
                JSONArray array = new JSONArray(raw);
                String[] loaded = new String[array.length()];
                for (int i = 0; i < loaded.length; i++) loaded[i] = array.getString(i);
                values = loaded;
            } catch (Throwable error) {
                SecureAsset.recordError("规则资源加载失败", error);
            }
        }
    }
    static boolean ready() { ensureLoaded(); return values != null; }
    static String s(int index) {
        ensureLoaded();
        String[] local = values;
        if (local == null) throw new IllegalStateException("规则资源不可用：" + SecureAsset.lastErrorSummary());
        if (index < 0 || index >= local.length) throw new IndexOutOfBoundsException("规则索引异常");
        return local[index];
    }
}
