package com.app.dededi;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.widget.Toast;
import androidx.core.content.ContextCompat;
import java.util.ArrayList;
import java.util.List;

public class FilePickerActivity extends Activity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Toast.makeText(this, "支持 txt、md、docx、pptx、pdf 及图片格式\n(最多支持上传20个)", Toast.LENGTH_LONG).show();
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"text/plain", "text/markdown", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application/vnd.openxmlformats-officedocument.presentationml.presentation", "application/pdf", "image/*"});
        startActivityForResult(intent, 103);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != 103 || resultCode != RESULT_OK || data == null) { finish(); return; }
        List<Uri> uris = new ArrayList<>();
        if (data.getClipData() != null) {
            int count = data.getClipData().getItemCount();
            for (int i = 0; i < Math.min(count, 20); i++) uris.add(data.getClipData().getItemAt(i).getUri());
        } else if (data.getData() != null) {
            uris.add(data.getData());
        }
        if (uris.isEmpty()) { finish(); return; }
        Toast.makeText(this, "正在处理导入文件，请稍候...", Toast.LENGTH_SHORT).show();
        AppExecutors.IO.execute(() -> {
            StringBuilder combined = new StringBuilder();
            for (int i = 0; i < uris.size(); i++) {
                String text = MainActivity.extractTextFromUriSync(this, uris.get(i), null);
                if (text != null) combined.append(text);
                if (i < uris.size() - 1) combined.append("\n\n---------------------------------\n\n");
            }
            String finalText = combined.toString();
            AppExecutors.MAIN.post(() -> {
                if (!finalText.trim().isEmpty()) {
                    Intent serviceIntent = new Intent(this, FloatingService.class);
                    serviceIntent.putExtra("IMPORTED_TEXT", finalText);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) ContextCompat.startForegroundService(this, serviceIntent);
                    else startService(serviceIntent);
                } else {
                    String detail = MainActivity.getLastExtractError(); Toast.makeText(this, detail.isEmpty() ? "无法读取文件内容或内容为空" : "导入失败：" + detail, Toast.LENGTH_LONG).show();
                }
                finish();
            });
        });
    }
}
