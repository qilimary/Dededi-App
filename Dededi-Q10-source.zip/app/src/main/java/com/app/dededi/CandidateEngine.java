package com.app.dededi;

import android.content.Context;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.BufferedInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.GZIPInputStream;

/**
 * Q10 two-stage character candidates.  Low-FP default = tested Stage-D-conservative + ambiguity guard:
 * primary static Top-12 T>=2.5/M>=0.75; empirical fallback count1 T>=3.5/M>=1.25,
 * count>=2 T>=3.25/M>=1.0.  Empirical may act only when it is best across ALL candidates.
 * 爆/暴 is deliberately left to the precise lexicon/rules because the generic LM layer over-corrected a valid semantic use in trap testing.
 */
final class CandidateEngine {
    static final class Decision {
        final int index; final char source, target; final double delta, margin; final boolean empirical; final int evidence;
        Decision(int index, char source, char target, double delta, double margin, boolean empirical, int evidence) {
            this.index=index; this.source=source; this.target=target; this.delta=delta; this.margin=margin; this.empirical=empirical; this.evidence=evidence;
        }
    }
    private static final class Candidate {
        final char target; final boolean empirical; final int count;
        Candidate(char target, boolean empirical, int count) { this.target=target;this.empirical=empirical;this.count=count; }
    }
    private static final class Entry {
        final Candidate[] primary, empirical;
        Entry(Candidate[] primary, Candidate[] empirical) { this.primary=primary;this.empirical=empirical; }
    }
    private static final class Scored {
        final Candidate candidate; final double delta;
        Scored(Candidate candidate, double delta) { this.candidate=candidate;this.delta=delta; }
    }
    private static final Object LOCK = new Object();
    private static volatile CandidateEngine instance;
    private final Map<Character, Entry> table;
    private final Map<Character, String[]> protectionByFirst;
    private CandidateEngine(Map<Character, Entry> table, Map<Character, String[]> protectionByFirst) {
        this.table=table;this.protectionByFirst=protectionByFirst;
    }

    static CandidateEngine get(Context context) {
        CandidateEngine local=instance; if (local!=null) return local;
        synchronized (LOCK) {
            local=instance; if (local!=null) return local;
            try { instance=local=load(context); }
            catch (Throwable error) { SecureAsset.recordError("两阶段候选资源加载失败", error); return null; }
            return local;
        }
    }

    private static CandidateEngine load(Context context) throws Exception {
        Map<Character, Entry> map=new HashMap<>(8192);
        try (DataInputStream in=new DataInputStream(new BufferedInputStream(context.getAssets().open("dededi_candidates_v2.bin"),64*1024))) {
            byte[] magic=new byte[4];in.readFully(magic);
            if (magic[0]!='D'||magic[1]!='D'||magic[2]!='C'||magic[3]!='2') throw new IllegalStateException("候选资源版本错误");
            int n=in.readInt(); if(n<5000||n>10000) throw new IllegalStateException("候选源字数量异常:"+n);
            for(int i=0;i<n;i++) {
                int src=in.readInt(), ns=in.readUnsignedByte(), ne=in.readUnsignedByte();
                if(src>Character.MAX_VALUE||ns>24||ne>24) throw new IllegalStateException("候选资源损坏");
                Candidate[] ps=new Candidate[ns], es=new Candidate[ne];
                for(int j=0;j<ns;j++) {
                    int t=in.readInt(); in.readUnsignedShort();in.readUnsignedShort();in.readUnsignedShort();in.readUnsignedByte();
                    ps[j]=new Candidate((char)t,false,0);
                }
                for(int j=0;j<ne;j++) es[j]=new Candidate((char)in.readInt(),true,in.readUnsignedShort());
                map.put((char)src,new Entry(ps,es));
            }
            if(in.read()!=-1) throw new IllegalStateException("候选资源存在尾部异常数据");
        }
        Map<Character,List<String>> grouped=new HashMap<>();
        try (BufferedReader br=new BufferedReader(new InputStreamReader(new GZIPInputStream(context.getAssets().open("dededi_protected_terms_v2.txt.gz"),64*1024),StandardCharsets.UTF_8),64*1024)) {
            String line; while((line=br.readLine())!=null) { String term=line.trim(); if(term.length()<2||term.charAt(0)=='#')continue; grouped.computeIfAbsent(term.charAt(0),k->new ArrayList<>()).add(term); }
        }
        Map<Character,String[]> protect=new HashMap<>(grouped.size()*2);
        for(Map.Entry<Character,List<String>> e:grouped.entrySet()) {
            e.getValue().sort((a,b)->Integer.compare(b.length(),a.length())); protect.put(e.getKey(),e.getValue().toArray(new String[0]));
        }
        return new CandidateEngine(Collections.unmodifiableMap(map),Collections.unmodifiableMap(protect));
    }

    private boolean[] protectionMask(String text) {
        boolean[] mask=new boolean[text.length()];
        for(int i=0;i<text.length();i++) {
            String[] terms=protectionByFirst.get(text.charAt(i)); if(terms==null)continue;
            for(String term:terms) if(i+term.length()<=text.length()&&text.regionMatches(i,term,0,term.length())) Arrays.fill(mask,i,i+term.length(),true);
        }
        return mask;
    }

    List<Decision> scan(Context context,String text,boolean[] eligible) { return scanInternal(context,text,eligible,false); }

    /**
     * Conservative second pass used only next to an already accepted Q10 edit.
     * It deliberately disables empirical fallback and raises the primary thresholds; this lets
     * adjacent multi-error strings (e.g. 计蒜鸡 -> 计算鸡 -> 计算机) settle without turning the
     * entire sentence into an iterative autocorrect loop.
     */
    List<Decision> scanCascade(Context context,String text,boolean[] eligible) { return scanInternal(context,text,eligible,true); }

    private List<Decision> scanInternal(Context context,String text,boolean[] eligible,boolean cascade) {
        if(text==null||text.isEmpty()||eligible==null||eligible.length!=text.length())return Collections.emptyList();
        boolean[] protectedMask=protectionMask(text); List<Decision> out=new ArrayList<>();
        for(int i=0;i<text.length();i++) {
            if(!eligible[i]||protectedMask[i]||Character.isSurrogate(text.charAt(i)))continue;
            Entry entry=table.get(text.charAt(i)); if(entry==null)continue;
            Decision d=evaluate(context,text,i,entry,cascade); if(d!=null)out.add(d);
        }
        return out;
    }

    private Decision evaluate(Context context,String text,int index,Entry entry,boolean cascade) {
        final char src=text.charAt(index); List<Scored> primary=new ArrayList<>(entry.primary.length); List<Scored> all=new ArrayList<>(entry.primary.length+entry.empirical.length);
        for(Candidate c:entry.primary) {
            if(blocked(src,c.target))continue; double d=NGramEngine.delta(context,text,index,1,String.valueOf(c.target)); if(!Double.isFinite(d))return null;
            Scored x=new Scored(c,d);primary.add(x);all.add(x);
        }
        Comparator<Scored> cmp=(a,b)->{int v=Double.compare(b.delta,a.delta);return v!=0?v:Character.compare(b.candidate.target,a.candidate.target);};
        primary.sort(cmp);
        if(!primary.isEmpty()) {
            Scored best=primary.get(0); double second=primary.size()>1?primary.get(1).delta:0.0; double margin=best.delta-second;
            double primaryT=cascade?3.5:2.5, primaryM=cascade?1.0:0.75;
            if(best.delta>=primaryT&&margin>=primaryM&&!ambiguityConflict(best.candidate.target,primary)) return new Decision(index,src,best.candidate.target,best.delta,margin,false,0);
        }
        // A cascade pass is intentionally primary-only: no empirical expansion after another edit.
        if(cascade)return null;
        // Only evaluate empirical fallback if the primary stage did not AUTO.
        for(Candidate c:entry.empirical) {
            if(blocked(src,c.target))continue; double d=NGramEngine.delta(context,text,index,1,String.valueOf(c.target)); if(!Double.isFinite(d))return null;
            all.add(new Scored(c,d));
        }
        if(all.isEmpty())return null; all.sort(cmp); Scored best=all.get(0);
        if(!best.candidate.empirical)return null; // empirical must be best overall
        double second=all.size()>1?all.get(1).delta:0.0, margin=best.delta-second;
        double t=best.candidate.count>=2?3.25:3.5, m=best.candidate.count>=2?1.0:1.25;
        if(best.delta>=t&&margin>=m&&!ambiguityConflict(best.candidate.target,all)) return new Decision(index,src,best.candidate.target,best.delta,margin,true,best.candidate.count);
        return null;
    }

    private static boolean blocked(char a,char b) {
        return sameGroup(a,b,"的地得")||sameGroup(a,b,"他她它牠祂")||sameGroup(a,b,"你您")||sameGroup(a,b,"爆暴");
    }
    private static boolean sameGroup(char a,char b,String group) { return a!=b&&group.indexOf(a)>=0&&group.indexOf(b)>=0; }
    private static int ambiguityGroup(char c) {
        String[] groups={"哪那","和或","做作","吗么","于与","以已","需须","在再"};
        for(int i=0;i<groups.length;i++)if(groups[i].indexOf(c)>=0)return i; return -1;
    }
    private static boolean ambiguityConflict(char best,List<Scored> pool) {
        int g=ambiguityGroup(best); if(g<0)return false; int count=0;
        for(Scored x:pool)if(ambiguityGroup(x.candidate.target)==g&&++count>=2)return true; return false;
    }
}
