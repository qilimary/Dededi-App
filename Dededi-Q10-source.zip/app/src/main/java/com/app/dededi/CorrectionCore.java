package com.app.dededi;
import org.pytorch.executorch.EValue;
import org.pytorch.executorch.Tensor;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ThreadLocalRandom;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class CorrectionCore {
    private static final String[] LABELS = {"的", "地", "得"};
    private static final int MAX_SEQUENCE_LENGTH = 300;
    private CorrectionCore() {}

    public interface Listener {
        boolean isCancelled();
        void onProgress(int current, int total, List<List<MainActivity.TextBlock>> completed, int errorCount, long elapsedMs);
        void onError(String message, boolean needsMinimumDisplay);
    }

    public static final class Result {
        public final List<List<MainActivity.TextBlock>> blocks;
        public final String cleanText;
        public final int errorCount;
        public final long elapsedMs;
        Result(List<List<MainActivity.TextBlock>> blocks, String cleanText, int errorCount, long elapsedMs) {
            this.blocks = blocks; this.cleanText = cleanText; this.errorCount = errorCount; this.elapsedMs = elapsedMs;
        }
    }

    private static final class GrammarHit {
        final MainActivity.GramRule rule;
        final int end;
        final String group1;
        final String group2;
        final String group3;

        GrammarHit(MainActivity.GramRule rule, int end, String group1, String group2, String group3) {
            this.rule = rule;
            this.end = end;
            this.group1 = group1;
            this.group2 = group2;
            this.group3 = group3;
        }
    }

    private static GrammarHit[] collectGrammarHits(String sentence, boolean fastMode) {
        GrammarHit[] hits = new GrammarHit[sentence.length()];
        for (MainActivity.GramRule rule : MainActivity.gramRules) {
            if (fastMode && rule.professionalOnly) continue;
            Matcher matcher = rule.pattern.matcher(sentence).useTransparentBounds(true);
            int searchStart = 0;
            while (searchStart < sentence.length()) {
                matcher.region(searchStart, sentence.length());
                if (!matcher.find()) break;
                int matchStart = matcher.start();
                if (hits[matchStart] == null) {
                    hits[matchStart] = new GrammarHit(
                            rule,
                            matcher.end(),
                            matcher.group(1),
                            matcher.group(2),
                            matcher.group(3)
                    );
                }
                searchStart = matchStart + 1;
            }
        }
        return hits;
    }

    public static Result run(String text, boolean fastMode, float temperature, float thresholdDe, float thresholdDi, float thresholdDe3, Listener listener) throws Exception {
        MainActivity.ensureTypoMapLoaded(DedediApp.context());
        MainActivity.ensureRulesLoaded();
        final MainActivity.TypoIndex dictionary = MainActivity.currentTypoIndex();
        long startTime = android.os.SystemClock.elapsedRealtime();
        List<String> sentences = splitText(text);
        List<List<MainActivity.TextBlock>> allBlocks = new ArrayList<>(sentences.size());
        StringBuilder fullCleanText = new StringBuilder(text.length());
        int errorCount = 0;
        long lastProgressTime = 0;

        for (int sentenceIndex = 0; sentenceIndex < sentences.size(); sentenceIndex++) {
            if (listener != null && listener.isCancelled()) return null;
            String sentence = sentences.get(sentenceIndex);
            if (sentence.isEmpty()) continue;

            GrammarHit[] grammarHits = collectGrammarHits(sentence, fastMode);
            List<MainActivity.TextBlock> intermediate = new ArrayList<>(Math.max(16, sentence.length() / 4));
            StringBuilder plain = new StringBuilder();
            int cursor = 0;
            while (cursor < sentence.length()) {
                if (listener != null && listener.isCancelled()) return null;

                MainActivity.TypoMatch typoMatch = dictionary.find(sentence, cursor);
                if (typoMatch != null && !NGramEngine.acceptDictionary(DedediApp.context(), sentence, cursor, typoMatch)) typoMatch = null;
                if (typoMatch != null) {
                    flushPlain(intermediate, plain);
                    boolean real = !typoMatch.source.equals(typoMatch.correction);
                    int type = typoMatch.custom ? 4 : 2;
                    intermediate.add(new MainActivity.TextBlock(typoMatch.source, typoMatch.correction, real, 1.0f, type));
                    if (real) {
                        errorCount++;
                        if (listener != null) listener.onError("发现错误：" + typoMatch.source + " → " + typoMatch.correction + " | 共 " + errorCount + " 处", true);
                    }
                    cursor += typoMatch.source.length();
                    continue;
                }

                GrammarHit grammarHit = grammarHits[cursor];
                if (grammarHit != null) {
                    flushPlain(intermediate, plain);
                    String group1 = grammarHit.group1;
                    String group2 = grammarHit.group2;
                    String group3 = grammarHit.group3;
                    String[] selected = grammarHit.rule.options[ThreadLocalRandom.current().nextInt(grammarHit.rule.options.length)];
                    String replacement1 = selected[0] != null ? selected[0] : group1;
                    String replacement3 = selected.length > 1 && selected[1] != null ? selected[1] : group3;
                    // Numeric normalization can consume the same quantifier first (e.g. 2个电脑).
                    // Carry over the already collected, guarded computer rule without a second scan.
                    if ("个".equals(group3) && "个".equals(replacement3) && grammarHit.end > 0) {
                        GrammarHit computer = grammarHits[grammarHit.end - 1];
                        if (computer != null && "个".equals(computer.group1) && computer.group2.isEmpty()
                                && "电脑".equals(computer.group3) && "台".equals(computer.rule.options[0][0])) replacement3 = "台";
                    }
                    String explanation = selected.length > 2 && selected[2] != null ? selected[2] : "";
                    boolean group1Error = !group1.equals(replacement1) || (!explanation.isEmpty() && selected[0] != null);
                    boolean group3Error = !group3.equals(replacement3) || (!explanation.isEmpty() && selected.length > 1 && selected[1] != null);

                    if (group1Error) {
                        MainActivity.TextBlock block = new MainActivity.TextBlock(group1, replacement1, true, 1.0f, 6);
                        block.exp = explanation;
                        intermediate.add(block);
                        errorCount++;
                        if (listener != null) listener.onError("发现错误：" + group1 + " → " + (replacement1.isEmpty() ? "(删除)" : replacement1) + " | 共 " + errorCount + " 处", true);
                    } else appendNormalText(intermediate, group1);

                    appendNormalText(intermediate, group2);

                    if (group3Error) {
                        MainActivity.TextBlock block = new MainActivity.TextBlock(group3, replacement3, true, 1.0f, 6);
                        block.exp = explanation;
                        intermediate.add(block);
                        errorCount++;
                        if (listener != null) listener.onError("发现错误：" + group3 + " → " + (replacement3.isEmpty() ? "(删除)" : replacement3) + " | 共 " + errorCount + " 处", true);
                    } else appendNormalText(intermediate, group3);

                    cursor = grammarHit.end;
                    continue;
                }

                if (cursor > 0 && cursor + 1 < sentence.length()) {
                    char number = sentence.charAt(cursor - 1), quantifier = sentence.charAt(cursor), noun = sentence.charAt(cursor + 1);
                    if (MainActivity.KNOWN_QUANTS.indexOf(quantifier) >= 0 && MainActivity.NUMS.indexOf(number) >= 0) {
                        MainActivity.QuantifierRule rule = MainActivity.quantRules.get(noun);
                        if (rule != null && rule.allowedQuants.indexOf(quantifier) < 0) {
                            char next = cursor + 2 < sentence.length() ? sentence.charAt(cursor + 2) : '\0';
                            if (MainActivity.isSafeCharAfterNoun(next)) {
                                flushPlain(intermediate, plain);
                                intermediate.add(new MainActivity.TextBlock(String.valueOf(quantifier), rule.primaryQuant, true, 1.0f, 3));
                                errorCount++;
                                if (listener != null) listener.onError("发现错误：" + number + quantifier + noun + " → " + number + rule.primaryQuant + noun + " | 共 " + errorCount + " 处", true);
                                cursor++;
                                continue;
                            }
                        }
                    }
                }

                char current = sentence.charAt(cursor++);
                if (isTarget(current)) {
                    flushPlain(intermediate, plain);
                    String value = String.valueOf(current);
                    intermediate.add(new MainActivity.TextBlock(value, value, false, 0f, 0));
                } else plain.append(current);
            }
            flushPlain(intermediate, plain);

            // Generic unknown-typo pass: only untouched blocks; precise dictionary/rules always keep priority.
            CandidateEngine candidateEngine = fastMode ? null : CandidateEngine.get(DedediApp.context());
            if (candidateEngine != null && !intermediate.isEmpty()) {
                StringBuilder q10Builder = new StringBuilder(sentence.length());
                int q10Length = 0;
                for (MainActivity.TextBlock block : intermediate) { q10Builder.append(block.current); q10Length += block.current.length(); }
                String q10Text = q10Builder.toString();
                boolean[] eligible = new boolean[q10Length];
                int qpos = 0;
                for (MainActivity.TextBlock block : intermediate) {
                    int len = block.current.length();
                    if (block.type == 0) Arrays.fill(eligible, qpos, qpos + len, true);
                    qpos += len;
                }
                List<CandidateEngine.Decision> genericChanges = candidateEngine.scan(DedediApp.context(), q10Text, eligible);
                if (!genericChanges.isEmpty()) {
                    CandidateEngine.Decision[] byIndex = new CandidateEngine.Decision[q10Text.length()];
                    for (CandidateEngine.Decision d : genericChanges) if (d.index >= 0 && d.index < byIndex.length) byIndex[d.index] = d;
                    List<MainActivity.TextBlock> rebuilt = new ArrayList<>(intermediate.size() + genericChanges.size() * 2);
                    int global = 0;
                    for (MainActivity.TextBlock block : intermediate) {
                        if (block.type != 0) { rebuilt.add(block); global += block.current.length(); continue; }
                        String value = block.current; int run = 0;
                        for (int j = 0; j < value.length(); j++) {
                            CandidateEngine.Decision d = byIndex[global + j];
                            if (d == null) continue;
                            if (j > run) appendNormalText(rebuilt, value.substring(run, j));
                            MainActivity.TextBlock changed = new MainActivity.TextBlock(String.valueOf(d.source), String.valueOf(d.target), true, 1.0f, 7);
                            changed.exp = d.empirical ? "Q10两阶段经验候选" : "Q10主候选";
                            rebuilt.add(changed); errorCount++;
                            if (listener != null) listener.onError("发现错误：" + d.source + " → " + d.target + " | 共 " + errorCount + " 处", true);
                            run = j + 1;
                        }
                        if (run < value.length()) appendNormalText(rebuilt, value.substring(run));
                        global += value.length();
                    }
                    intermediate = rebuilt;

                    // One conservative local cascade pass.  Only untouched characters within two
                    // positions of an accepted Q10 edit are reconsidered, with stricter primary-only
                    // thresholds inside CandidateEngine.  This fixes adjacent multi-typos such as
                    // “计蒜鸡” -> “计算鸡” -> “计算机” without repeatedly rescanning the whole sentence.
                    boolean[] cascadeZone = new boolean[q10Text.length()];
                    for (CandidateEngine.Decision d : genericChanges) {
                        int from = Math.max(0, d.index - 2), to = Math.min(cascadeZone.length, d.index + 3);
                        Arrays.fill(cascadeZone, from, to, true);
                    }
                    StringBuilder cascadeBuilder = new StringBuilder(q10Text.length());
                    for (MainActivity.TextBlock block : intermediate) cascadeBuilder.append(block.current);
                    String cascadeText = cascadeBuilder.toString();
                    if (cascadeText.length() == cascadeZone.length) {
                        boolean[] cascadeEligible = new boolean[cascadeText.length()];
                        int cpos = 0;
                        for (MainActivity.TextBlock block : intermediate) {
                            int len = block.current.length();
                            if (block.type == 0) {
                                for (int j = 0; j < len; j++) if (cascadeZone[cpos + j]) cascadeEligible[cpos + j] = true;
                            }
                            cpos += len;
                        }
                        List<CandidateEngine.Decision> cascadeChanges = candidateEngine.scanCascade(DedediApp.context(), cascadeText, cascadeEligible);
                        if (!cascadeChanges.isEmpty()) {
                            CandidateEngine.Decision[] cascadeByIndex = new CandidateEngine.Decision[cascadeText.length()];
                            for (CandidateEngine.Decision d : cascadeChanges)
                                if (d.index >= 0 && d.index < cascadeByIndex.length) cascadeByIndex[d.index] = d;
                            List<MainActivity.TextBlock> cascadeRebuilt = new ArrayList<>(intermediate.size() + cascadeChanges.size() * 2);
                            int cglobal = 0;
                            for (MainActivity.TextBlock block : intermediate) {
                                if (block.type != 0) { cascadeRebuilt.add(block); cglobal += block.current.length(); continue; }
                                String value = block.current; int run = 0;
                                for (int j = 0; j < value.length(); j++) {
                                    CandidateEngine.Decision d = cascadeByIndex[cglobal + j];
                                    if (d == null) continue;
                                    if (j > run) appendNormalText(cascadeRebuilt, value.substring(run, j));
                                    MainActivity.TextBlock changed = new MainActivity.TextBlock(String.valueOf(d.source), String.valueOf(d.target), true, 1.0f, 7);
                                    changed.exp = "Q10邻近二次确认";
                                    cascadeRebuilt.add(changed); errorCount++;
                                    if (listener != null) listener.onError("发现错误：" + d.source + " → " + d.target + " | 共 " + errorCount + " 处", true);
                                    run = j + 1;
                                }
                                if (run < value.length()) appendNormalText(cascadeRebuilt, value.substring(run));
                                cglobal += value.length();
                            }
                            intermediate = cascadeRebuilt;
                        }
                    }
                }
            }

            boolean candidateTarget = false;
            if (!fastMode) for (MainActivity.TextBlock block : intermediate) {
                if (block.type == 0 && block.current.length() == 1 && isTarget(block.current.charAt(0))) { candidateTarget = true; break; }
            }
            if (!fastMode && candidateTarget) {
            StringBuilder inferBuilder = new StringBuilder(sentence.length());
            for (MainActivity.TextBlock block : intermediate) inferBuilder.append(block.current);
            String inferText = inferBuilder.toString();
            MainActivity.TextBlock[] map = new MainActivity.TextBlock[inferText.length()];
            boolean[] ignored = new boolean[inferText.length()];
            int position = 0;
            for (MainActivity.TextBlock block : intermediate) {
                int length = block.current.length();
                Arrays.fill(map, position, position + length, block);
                if (block.type != 0) Arrays.fill(ignored, position, position + length, true);
                position += length;
            }
            markIgnoreWords(inferText, ignored);
            markProtectedTargets(inferText, ignored);

            boolean hasTarget = false;
            for (int i = 0; i < inferText.length(); i++) if (!ignored[i] && isTarget(inferText.charAt(i))) { hasTarget = true; break; }
            if (!fastMode && hasTarget) {
                if (!MainActivity.isTemperatureValid(temperature)) {
                    throw new IllegalArgumentException("温度参数必须在 0.5～2.0 之间");
                }
                int exactLength = inferText.length() + 2;
                long[] ids = new long[exactLength], masks = new long[exactLength], types = new long[exactLength];
                ids[0] = MainActivity.clsId;
                masks[0] = 1L;
                for (int i = 0; i < inferText.length(); i++) {
                    char character = inferText.charAt(i);
                    ids[i + 1] = !ignored[i] && isTarget(character)
                            ? MainActivity.maskId
                            : MainActivity.proCharIds[character];
                    masks[i + 1] = 1L;
                }
                ids[exactLength - 1] = MainActivity.sepId;
                masks[exactLength - 1] = 1L;
                EValue[] output = MainActivity.proModule.forward(
                        EValue.from(Tensor.fromBlob(ids, new long[]{1, exactLength})),
                        EValue.from(Tensor.fromBlob(masks, new long[]{1, exactLength})),
                        EValue.from(Tensor.fromBlob(types, new long[]{1, exactLength}))
                );
                if (output == null || output.length == 0 || output[0] == null) {
                    throw new IllegalStateException("ExecuTorch RoFormerV2 未返回有效输出");
                }
                // 按 ExecuTorch Android 1.4.x Java API 读取 Tensor 输出。
                final float[] scores;
                try {
                    scores = output[0].toTensor().getDataAsFloatArray();
                } catch (RuntimeException e) {
                    throw new IllegalStateException("ExecuTorch RoFormerV2 输出不是可读取的 Tensor", e);
                }
                if (scores.length != exactLength * 3) {
                    throw new IllegalStateException("RoFormerV2 输出形状异常：期望 " + exactLength + "×3，实际元素数 " + scores.length);
                }

                float[] probability = new float[3];
                for (int i = 0; i < inferText.length(); i++) {
                    char character = inferText.charAt(i);
                    if (ignored[i] || !isTarget(character)) continue;
                    int base = (i + 1) * 3;
                    stableSoftmax(scores[base], scores[base + 1], scores[base + 2], temperature, probability);
                    int maxIndex = probability[1] > probability[0] ? 1 : 0;
                    if (probability[2] > probability[maxIndex]) maxIndex = 2;
                    float maxProbability = probability[maxIndex];
                    float threshold = maxIndex == 1 ? thresholdDi : (maxIndex == 2 ? thresholdDe3 : thresholdDe);
                    String prediction = LABELS[maxIndex];
                    if (!prediction.equals(String.valueOf(character)) && maxProbability >= threshold) {
                        MainActivity.TextBlock block = map[i];
                        block.current = prediction; block.modelCorrected = prediction; block.isMutable = true; block.conf = maxProbability; block.type = 1;
                        errorCount++;
                        if (listener != null) listener.onError("发现错误：" + character + " → " + prediction + " (置信度:" + String.format(Locale.getDefault(), "%.2f", maxProbability) + ") | 共 " + errorCount + " 处", false);
                    }
                }
            }

            }

            List<MainActivity.TextBlock> finalSentence = MainActivity.mergeNormalBlocks(intermediate);
            for (MainActivity.TextBlock block : finalSentence) fullCleanText.append(block.current);
            allBlocks.add(finalSentence);
            long now = android.os.SystemClock.elapsedRealtime();
            if (listener != null && (now - lastProgressTime >= progressInterval(text.length()) || sentenceIndex == sentences.size() - 1)) {
                lastProgressTime = now;
                listener.onProgress(sentenceIndex + 1, sentences.size(), allBlocks, errorCount, now - startTime);
            }
        }
        long elapsed = android.os.SystemClock.elapsedRealtime() - startTime;
        return new Result(allBlocks, fullCleanText.toString(), errorCount, elapsed);
    }

    private static int progressInterval(int length) { return length > 100000 ? 1200 : (length > 30000 ? 700 : 350); }
    private static boolean isTarget(char c) { return c == '的' || c == '地' || c == '得'; }
    private static void flushPlain(List<MainActivity.TextBlock> blocks, StringBuilder plain) {
        if (plain.length() == 0) return;
        String value = plain.toString(); blocks.add(new MainActivity.TextBlock(value, value, false, 0f, 0)); plain.setLength(0);
    }
    private static void appendNormalText(List<MainActivity.TextBlock> blocks, String text) {
        int runStart = 0;
        for (int i = 0; i < text.length(); i++) {
            if (!isTarget(text.charAt(i))) continue;
            if (i > runStart) { String run = text.substring(runStart, i); blocks.add(new MainActivity.TextBlock(run, run, false, 0f, 0)); }
            String target = String.valueOf(text.charAt(i)); blocks.add(new MainActivity.TextBlock(target, target, false, 0f, 0)); runStart = i + 1;
        }
        if (runStart < text.length()) { String run = text.substring(runStart); blocks.add(new MainActivity.TextBlock(run, run, false, 0f, 0)); }
    }
    private static void markIgnoreWords(String text, boolean[] ignored) {
        for (String word : MainActivity.IGNORE_WORDS) {
            int index = text.indexOf(word);
            while (index >= 0) {
                Arrays.fill(ignored, index, Math.min(ignored.length, index + word.length()), true);
                index = text.indexOf(word, index + 1);
            }
        }
    }
    private static void markProtectedTargets(String text, boolean[] ignored) {
        for (Pattern pattern : MainActivity.protectedTargetPatterns) {
            Matcher matcher = pattern.matcher(text);
            while (matcher.find()) {
                int index = matcher.start(1);
                if (index >= 0 && index < ignored.length && isTarget(text.charAt(index))) ignored[index] = true;
            }
        }
    }
    private static void stableSoftmax(float a, float b, float c, float temperature, float[] output) {
        float inverse = 1f / temperature;
        float sa = a * inverse, sb = b * inverse, sc = c * inverse;
        float max = Math.max(sa, Math.max(sb, sc));
        float ea = (float) Math.exp(sa - max), eb = (float) Math.exp(sb - max), ec = (float) Math.exp(sc - max);
        float sum = ea + eb + ec;
        if (!Float.isFinite(sum) || sum <= 0f) { output[0] = output[1] = output[2] = 1f / 3f; }
        else { output[0] = ea / sum; output[1] = eb / sum; output[2] = ec / sum; }
    }
    public static List<String> splitText(String text) {
        List<String> firstPass = new ArrayList<>();
        StringBuilder current = new StringBuilder();
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i); current.append(c);
            if (c == '。' || c == '！' || c == '？' || c == '!' || c == '?' || c == '\n') { firstPass.add(current.toString()); current.setLength(0); }
        }
        if (current.length() > 0) firstPass.add(current.toString());
        List<String> result = new ArrayList<>(firstPass.size());
        for (String segment : firstPass) {
            if (segment.length() <= MAX_SEQUENCE_LENGTH) { result.add(segment); continue; }
            StringBuilder pending = new StringBuilder();
            for (int i = 0; i < segment.length(); i++) {
                pending.append(segment.charAt(i));
                if (pending.length() < MAX_SEQUENCE_LENGTH) continue;
                int split = -1;
                for (int j = pending.length() - 1; j >= Math.max(0, pending.length() - 60); j--) {
                    char c = pending.charAt(j); if (c == '，' || c == ',' || c == '；' || c == ';' || c == '、') { split = j; break; }
                }
                if (split > 0) {
                    result.add(pending.substring(0, split + 1));
                    String remainder = pending.substring(split + 1); pending.setLength(0); pending.append(remainder);
                } else { result.add(pending.toString()); pending.setLength(0); }
            }
            if (pending.length() > 0) result.add(pending.toString());
        }
        return result;
    }
}
