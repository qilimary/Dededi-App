package com.app.dededi;
final class NativeSecurity {
    static { System.loadLibrary("dededi"); }
    private NativeSecurity() {}
    static native byte[] deriveAssetKeyNative(byte[] javaPart, byte[] buildToken, byte[] salt, String assetName);
}
