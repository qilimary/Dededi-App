-keep class org.pytorch.** { *; }
-keep class com.facebook.jni.** { *; }
-keep class com.app.dededi.NativeNGram { *; }
-keepclasseswithmembers class * { native <methods>; }
-keep class com.app.dededi.NativeSecurity { *; }

# 仅保留 ML Kit OCR 所需的反射/原生入口。
-keep class com.google.mlkit.vision.text.** { *; }
-keep class com.google.mlkit.vision.common.** { *; }
-keep class com.google.mlkit.common.sdkinternal.** { *; }
-keep class com.google.android.gms.internal.mlkit_vision_text_common.** { *; }
-keep class com.google.android.gms.internal.mlkit_vision_text_bundled_common.** { *; }
-keepclasseswithmembernames class com.google.mlkit.** { native <methods>; }
-keepclasseswithmembernames class com.google.android.gms.internal.mlkit_vision_text_** { native <methods>; }
-dontwarn com.google.mlkit.**
-dontwarn com.google.android.gms.internal.mlkit_vision_text_**
-dontwarn org.pytorch.**
