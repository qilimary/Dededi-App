import json
from pathlib import Path
vocab_path = Path("roformer_v2_executorch/vocab.txt")
tokens = vocab_path.read_text(encoding="utf-8").splitlines()
if not tokens:
    raise RuntimeError("vocab.txt 为空")
vocab = {token: index for index, token in enumerate(tokens)}
Path("roformer_vocab.json").write_text(json.dumps(vocab, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
print(f"模型与词表已准备完成：{len(tokens)} 个 token")
