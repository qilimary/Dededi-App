import gzip
import hmac
import hashlib
import json
import secrets
import shutil
import tempfile
from pathlib import Path
from Crypto.Cipher import AES

MAGIC = b'DDA3'
VERSION = 1
DOMAIN = b'DEDEDI-ASSET-V2\x00'
CHUNK = 512 * 1024
GENERATED = Path('generated_security')
GENERATED.mkdir(exist_ok=True)

master = secrets.token_bytes(32)
part_a = secrets.token_bytes(32)
part_b = secrets.token_bytes(32)
part_c = bytes(master[i] ^ part_a[i] ^ part_b[i] for i in range(32))
build_token = secrets.token_bytes(16)
Path('.ci').mkdir(exist_ok=True)
Path('.ci/security_material.json').write_text(json.dumps({'master': master.hex(), 'token': build_token.hex()}, separators=(',', ':')), encoding='utf-8')

def rol8(v: int, shift: int) -> int:
    shift &= 7
    return ((v << shift) | (v >> (8 - shift))) & 0xFF if shift else v

def encode_part(part: bytes, variant: int):
    masks = secrets.token_bytes(32)
    encoded = []
    for i, value in enumerate(part):
        shift = ((i * (variant + 2) + variant) % 7) + 1
        mixed = value ^ masks[i] ^ ((i * (31 + variant * 7) + 17 * variant) & 0xFF)
        encoded.append(rol8(mixed, shift))
    return bytes(encoded), masks

def cpp_array(data: bytes) -> str:
    return ','.join(f'0x{x:02X}' for x in data)

def java_array(data: bytes) -> str:
    return ','.join(f'(byte)0x{x:02X}' for x in data)

def write_cpp_share(path: Path, function_name: str, part: bytes, variant: int) -> None:
    encoded, masks = encode_part(part, variant)
    path.write_text(f'''#include <cstdint>\n\nnamespace {{\nconstexpr uint8_t ENCODED[32] = {{{cpp_array(encoded)}}};\nconstexpr uint8_t MASKS[32] = {{{cpp_array(masks)}}};\ninline uint8_t ror8(uint8_t value, unsigned shift) {{ shift &= 7U; return shift ? static_cast<uint8_t>((value >> shift) | (value << (8U - shift))) : value; }}\n}}\n\nextern "C" void {function_name}(uint8_t out[32]) {{\n    for (unsigned i = 0; i < 32; ++i) {{\n        unsigned shift = ((i * {variant + 2}U + {variant}U) % 7U) + 1U;\n        out[i] = static_cast<uint8_t>(ror8(ENCODED[i], shift) ^ MASKS[i] ^ ((i * {31 + variant * 7}U + {17 * variant}U) & 0xFFU));\n    }}\n}}\n''', encoding='utf-8')

write_cpp_share(GENERATED / 'key-part-a.cpp', 'dedediFillKeyPartA', part_a, 1)
write_cpp_share(GENERATED / 'key-part-b.cpp', 'dedediFillKeyPartB', part_b, 2)

encoded_c, masks_c = encode_part(part_c, 3)
(GENERATED / 'GeneratedSecuritySeed.java').write_text(f'''package com.app.dededi;\n\nfinal class GeneratedSecuritySeed {{\n    private static final byte[] ENCODED = new byte[]{{{java_array(encoded_c)}}};\n    private static final byte[] MASKS = new byte[]{{{java_array(masks_c)}}};\n    private static final byte[] TOKEN = new byte[]{{{java_array(build_token)}}};\n    private GeneratedSecuritySeed() {{}}\n    private static int ror8(int value, int shift) {{ shift &= 7; return shift == 0 ? value & 0xFF : ((value >>> shift) | (value << (8 - shift))) & 0xFF; }}\n    static byte[] revealPart() {{\n        byte[] out = new byte[32];\n        for (int i = 0; i < out.length; i++) {{\n            int shift = ((i * 5 + 3) % 7) + 1;\n            out[i] = (byte)(ror8(ENCODED[i] & 0xFF, shift) ^ (MASKS[i] & 0xFF) ^ ((i * 52 + 51) & 0xFF));\n        }}\n        return out;\n    }}\n    static byte[] buildToken() {{ return TOKEN.clone(); }}\n}}\n''', encoding='utf-8')

def derive_key(salt: bytes, asset_name: str) -> bytes:
    message = DOMAIN + build_token + salt + asset_name.encode('utf-8')
    return hmac.new(master, message, hashlib.sha256).digest()

def gzip_source(source: Path, level: int, patch_zip_header: bool) -> Path:
    fd, name = tempfile.mkstemp(prefix='dededi_', suffix='.gz')
    import os
    os.close(fd)
    target = Path(name)
    try:
        with source.open('rb') as src, target.open('wb') as raw_out:
            with gzip.GzipFile(fileobj=raw_out, mode='wb', compresslevel=level, mtime=0) as gz:
                first = src.read(2)
                if patch_zip_header and first == b'PK':
                    gz.write(b'DE')
                else:
                    gz.write(first)
                shutil.copyfileobj(src, gz, length=CHUNK)
        return target
    except Exception:
        target.unlink(missing_ok=True)
        raise

def encrypt_asset(file_in: str, file_out: str, level: int, patch_zip_header: bool) -> None:
    source = Path(file_in)
    if not source.exists():
        print(f'跳过不存在的文件: {file_in}')
        return
    salt = secrets.token_bytes(16)
    nonce_prefix = secrets.token_bytes(8)
    flags = 1 if patch_zip_header else 0
    asset_name = Path(file_out).name
    key = derive_key(salt, asset_name)
    compressed = gzip_source(source, level, patch_zip_header)
    try:
        total_length = compressed.stat().st_size
        chunk_count = (total_length + CHUNK - 1) // CHUNK
        header = (MAGIC + bytes((VERSION, flags)) + salt + nonce_prefix
                  + CHUNK.to_bytes(4, 'big')
                  + total_length.to_bytes(8, 'big')
                  + chunk_count.to_bytes(4, 'big'))
        aad_base = header + asset_name.encode('utf-8')
        with compressed.open('rb') as src, Path(file_out).open('wb') as dst:
            dst.write(header)
            for index in range(chunk_count):
                plain = src.read(CHUNK)
                if not plain:
                    raise RuntimeError('压缩资源长度异常')
                length_bytes = len(plain).to_bytes(4, 'big')
                nonce = nonce_prefix + index.to_bytes(4, 'big')
                cipher = AES.new(key, AES.MODE_GCM, nonce=nonce, mac_len=16)
                cipher.update(aad_base + index.to_bytes(4, 'big') + length_bytes)
                encrypted, tag = cipher.encrypt_and_digest(plain)
                dst.write(length_bytes)
                dst.write(encrypted)
                dst.write(tag)
            if src.read(1):
                raise RuntimeError('压缩资源分块计数异常')
        if Path(file_out).stat().st_size <= 70:
            raise RuntimeError(f'{file_out} 加密结果异常')
    finally:
        compressed.unlink(missing_ok=True)

print('正在使用 AES-256-GCM 加固 RoFormerV2、Q10、词表和规则文件...')
encrypt_asset('roformer_mobile.pte', 'sys_core_p.dat', 1, False)
encrypt_asset('dededi_final_5gram_q10.klm.bin', 'sys_lm_q10.dat', 1, False)
encrypt_asset('错别字.txt', 'sys_typo.dat', 9, False)
encrypt_asset('roformer_vocab.json', 'sys_vocab_p.dat', 9, False)
print('AES-256-GCM 加固完成；每次构建均使用全新主密钥、盐和 Nonce。')
