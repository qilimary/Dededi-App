import gzip
import hashlib
import hmac
import json
import re
import secrets
from pathlib import Path
from Crypto.Cipher import AES

source_path = Path('app/src/main/java/com/app/dededi/MainActivity.java')
source = source_path.read_text(encoding='utf-8')
anchor = source.index('public static final List<GramRule> gramRules')
start = source.index('    public static synchronized void ensureRulesLoaded()', anchor)
end = source.index('    public static final String NUMS', start)
region = source[start:end]
literal_pattern = re.compile(r'"(?:\\.|[^"\\])*"')
strings = []
indices = {}

def replace_literal(match):
    token = match.group(0)
    value = json.loads(token)
    index = indices.get(value)
    if index is None:
        index = len(strings)
        indices[value] = index
        strings.append(value)
    return f'RuleStrings.s({index})'

protected_region = literal_pattern.sub(replace_literal, region)
source_path.write_text(source[:start] + protected_region + source[end:], encoding='utf-8')

material = json.loads(Path('.ci/security_material.json').read_text(encoding='utf-8'))
master = bytes.fromhex(material['master'])
token = bytes.fromhex(material['token'])
asset_name = 'sys_rules.dat'
salt = secrets.token_bytes(16)
nonce_prefix = secrets.token_bytes(8)
magic = b'DDA3'
version = 1
flags = 0
chunk_size = 512 * 1024
domain = b'DEDEDI-ASSET-V2\x00'
key = hmac.new(master, domain + token + salt + asset_name.encode('utf-8'), hashlib.sha256).digest()
raw = json.dumps(strings, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
compressed = gzip.compress(raw, compresslevel=9, mtime=0)
total_length = len(compressed)
chunk_count = (total_length + chunk_size - 1) // chunk_size
header = (magic + bytes((version, flags)) + salt + nonce_prefix
          + chunk_size.to_bytes(4, 'big')
          + total_length.to_bytes(8, 'big')
          + chunk_count.to_bytes(4, 'big'))
aad_base = header + asset_name.encode('utf-8')
target = Path('app/src/main/assets') / asset_name
with target.open('wb') as dst:
    dst.write(header)
    for index in range(chunk_count):
        plain = compressed[index * chunk_size:(index + 1) * chunk_size]
        length_bytes = len(plain).to_bytes(4, 'big')
        nonce = nonce_prefix + index.to_bytes(4, 'big')
        cipher = AES.new(key, AES.MODE_GCM, nonce=nonce, mac_len=16)
        cipher.update(aad_base + index.to_bytes(4, 'big') + length_bytes)
        encrypted, tag = cipher.encrypt_and_digest(plain)
        dst.write(length_bytes); dst.write(encrypted); dst.write(tag)
if len(strings) < 20 or target.stat().st_size < 120:
    raise RuntimeError('规则加固结果异常')
print(f'已将 {len(strings)} 个规则/白名单字符串移出 DEX，并写入 AES-GCM 资源。')
